﻿//---------------------------------------------------------------------------------
// Microsoft (R) .NET Services
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------


namespace Microsoft.Samples.ServiceBus
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    public class SampleData
    {
        [DataMember]
        public int Counter { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public DateTime Timestamp { get; set; }
    }
}
