//---------------------------------------------------------------------------------
// Microsoft (R) .NET Services SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.Samples.ServiceBus
{
    using System;
    using Microsoft.ServiceBus;
    using System.Collections.Generic;
    using System.ServiceModel.Channels;

    public class QueueClient<T> where T : class
    {
        QueueClient innerClient;

        internal QueueClient(Microsoft.ServiceBus.QueueClient untypedClient)
        {
            this.innerClient = untypedClient;
        }

        public void DeleteLockedMessage(QueueMessage<T> message)
        {
            if (message.IsUnlocked)
            {
                throw new InvalidOperationException("Message is already unlocked");
            }
            innerClient.DeleteLockedMessage(message.Message);
            message.SetUnlocked();
        }

        public void DeleteQueue()
        {
            innerClient.DeleteQueue();
        }

        public DateTime GetExpiration()
        {
            return innerClient.GetExpiration();
        }

        public QueuePolicy GetPolicy()
        {
            return innerClient.GetPolicy();
        }

        public QueueMessage<T> PeekLock()
        {
            return new QueueMessage<T>(this, innerClient.PeekLock(), true);
        }

        public QueueMessage<T> PeekLock(TimeSpan timeout)
        {
            return new QueueMessage<T>(this, innerClient.PeekLock(timeout), true);
        }

        public IEnumerable<QueueMessage<T>> PeekLockMultiple(int maxMessages)
        {
            List<QueueMessage<T>> queuedMessages = new List<QueueMessage<T>>();

            foreach (Message message in innerClient.PeekLockMultiple(maxMessages))
            {
                queuedMessages.Add(new QueueMessage<T>(this, message, true));
            }

            return queuedMessages;
        }

        public IEnumerable<QueueMessage<T>> PeekLockMultiple(int maxMessages, TimeSpan timeout)
        {
            List<QueueMessage<T>> queuedMessages = new List<QueueMessage<T>>();

            foreach (Message message in innerClient.PeekLockMultiple(maxMessages, timeout))
            {
                queuedMessages.Add(new QueueMessage<T>(this, message, true));
            }

            return queuedMessages;
        }

        public void Purge()
        {
            innerClient.Purge();
        }

        public void ReleaseLock(QueueMessage<T> message)
        {
            if (message.IsUnlocked)
            {
                throw new InvalidOperationException("Message is already unlocked");
            }
            innerClient.ReleaseLock(message.Message);
            message.SetUnlocked();
        }

        public DateTime Renew(TimeSpan requestedExpiration)
        {
            return innerClient.Renew(requestedExpiration);
        }

        public QueueMessage<T> Retrieve()
        {
            return new QueueMessage<T>(this, innerClient.Retrieve(), false);
        }

        public QueueMessage<T> Retrieve(TimeSpan timeout)
        {
            return new QueueMessage<T>(this, innerClient.Retrieve(timeout), false);
        }

        public IEnumerable<QueueMessage<T>> RetrieveMultiple(int maxMessages)
        {
            List<QueueMessage<T>> queuedMessages = new List<QueueMessage<T>>();

            foreach (Message message in innerClient.RetrieveMultiple(maxMessages))
            {
                queuedMessages.Add(new QueueMessage<T>(this, message, false));
            }

            return queuedMessages;
        }

        public IEnumerable<QueueMessage<T>> RetrieveMultiple(int maxMessages, TimeSpan timeout)
        {
            List<QueueMessage<T>> queuedMessages = new List<QueueMessage<T>>();

            foreach (Message message in innerClient.RetrieveMultiple(maxMessages, timeout))
            {
                queuedMessages.Add(new QueueMessage<T>(this, message, false));
            }

            return queuedMessages;
        }

        public void Send(T data)
        {
            Send(data, String.Empty);
        }

        public void Send(T data, string action)
        {
            innerClient.Send(Message.CreateMessage(MessageVersion.Soap12WSAddressing10, action, data), TimeSpan.MaxValue);
        }

        public RouterSubscriptionClient SubscribeToRouter(RouterClient routerClient, TimeSpan requestedTimeout)
        {
            return innerClient.SubscribeToRouter(routerClient, requestedTimeout);
        }
    }
}
