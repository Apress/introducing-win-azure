﻿//----------------------------------------------------------------------------------
//
// Copyright (c) 2009, SoftnetSolutions. All rights reserved.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
//
//Author : Henry Li
//henry@softnetsolution.net
//192 NE 74th Ave, Hillsboro, OR 97124
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    using SoftnetSolutions.Shape;

    [DataContract]
    public class PostData
    {
        [DataMember]
        public string Message;

        [DataMember]
        public SHAPE_TYPE shape;
    }
}
