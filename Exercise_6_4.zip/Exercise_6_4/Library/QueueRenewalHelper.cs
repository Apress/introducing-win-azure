﻿//---------------------------------------------------------------------------------
// Microsoft (R) .NET Services
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.Samples.ServiceBus
{
    using System;
    using System.Timers;
    using Microsoft.ServiceBus;
    using System.ServiceModel;

    public class QueueRenewalHelper<T> : IDisposable where T : class
    {
        QueueClient<T> queueClient;
        Timer queueRenewalTimer;

        public QueueRenewalHelper(QueueClient<T> queueClient)
        {
            this.queueClient = queueClient;
            this.queueRenewalTimer = new Timer((queueClient.GetPolicy().ExpirationInstant - DateTime.UtcNow).Subtract(TimeSpan.FromMinutes(2)).Milliseconds);
            this.queueRenewalTimer.Elapsed += new ElapsedEventHandler(this.TimerElapsedCallback);
            this.queueRenewalTimer.AutoReset = false;
            this.queueRenewalTimer.Start();
        }

        private void TimerElapsedCallback(object source, ElapsedEventArgs e)
        {
            this.queueClient.Renew(TimeSpan.FromHours(1));
            this.queueRenewalTimer.Interval = (this.queueClient.GetPolicy().ExpirationInstant - DateTime.UtcNow).Subtract(TimeSpan.FromMinutes(2)).TotalMilliseconds;
            this.queueRenewalTimer.Start();
        }

        public void Dispose()
        {
            this.queueRenewalTimer.Stop();
        }

        static public QueueClient<T> GetOrCreateQueue<T>(TransportClientEndpointBehavior userNamePasswordServiceBusCredential, Uri queueUri, ref QueuePolicy queuePolicy) where T : class
        {
            QueueClient<T> client;

            try
            {
                client = QueueManagementClient<T>.GetQueue(userNamePasswordServiceBusCredential, queueUri);
                queuePolicy = client.GetPolicy();
                return client;
            }
            catch (EndpointNotFoundException)
            {
                // Not found; absorb and make a new queue below. 
                // Other exceptions get bubbled up.
            }
            client = QueueManagementClient<T>.CreateQueue(userNamePasswordServiceBusCredential, queueUri, queuePolicy);
            queuePolicy = client.GetPolicy();
            return client;
        }
    }
}
