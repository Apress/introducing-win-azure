//---------------------------------------------------------------------------------
// Microsoft (R) .NET Services SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.Samples.ServiceBus
{
    using System;
    using Microsoft.ServiceBus;
    using System.ServiceModel.Channels;
 
    public class QueueMessage<T> where T : class
    {
        QueueClient<T> queueClient;
        Message message;
        T typedValue;
        bool isPeekLocked;
        bool isUnlocked;

        internal QueueMessage(QueueClient<T> client, Message message, bool isPeekLocked)
        {
            this.message = message;
            this.typedValue = message.GetBody<T>();
            this.isPeekLocked = isPeekLocked;
            this.isUnlocked = false;
        }

        internal QueueMessage(QueueMessage<T> queueMessage)
        {
            this.message = queueMessage.message;
            this.typedValue = queueMessage.typedValue;
            this.queueClient = queueMessage.queueClient;
            this.isPeekLocked = queueMessage.isPeekLocked;
            this.isUnlocked = queueMessage.isUnlocked;
        }

        internal QueueClient<T> Client
        {
            get
            {
                return this.queueClient;
            }
        }

        internal Message Message
        {
            get
            {
                return this.message;
            }
        }

        internal bool IsUnlocked
        {
            get
            {
                return this.isUnlocked;
            }
        }

        public T Value
        {
            get
            {
                return this.typedValue;
            }
        }

        public string Action
        {
            get
            {
                return this.message.Headers.Action;
            }
        }

        
        internal void SetUnlocked()
        {
            this.isUnlocked = true;
        }

        public static implicit operator T(QueueMessage<T> queueMessage)
        {
            if (queueMessage != null)
            {
                return queueMessage.Value;
            }
            else
            {
                return null;
            }
        }
    }
}
