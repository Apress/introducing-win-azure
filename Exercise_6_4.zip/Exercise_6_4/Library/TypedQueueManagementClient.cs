﻿//---------------------------------------------------------------------------------
// Microsoft (R) .NET Services SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.Samples.ServiceBus
{
    using System;
    using Microsoft.ServiceBus;

    public static class QueueManagementClient<T> where T : class
    {
        public static QueueClient<T> CreateQueue(TransportClientEndpointBehavior credentials, Uri queueUri, QueuePolicy policy)
        {
            return new QueueClient<T>(QueueManagementClient.CreateQueue(credentials,queueUri, policy));
        }

        public static QueueClient<T> GetQueue(TransportClientEndpointBehavior credentials, Uri queueUri)
        {
            return new QueueClient<T>(QueueManagementClient.GetQueue(credentials, queueUri));
        }

        public static void DeleteQueue(TransportClientEndpointBehavior credential, Uri queueUri)
        {
            QueueManagementClient.DeleteQueue(credential, queueUri);
        }

        public static QueuePolicy GetQueuePolicy(TransportClientEndpointBehavior credential, Uri queueUri)
        {
            return QueueManagementClient.GetQueuePolicy(credential, queueUri);
        }

        public static DateTime RenewQueue(TransportClientEndpointBehavior credential, Uri queueUri, TimeSpan requestedExpiration)
        {
            return QueueManagementClient.RenewQueue(credential, queueUri, requestedExpiration);
        }
    }
}
