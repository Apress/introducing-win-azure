using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace SoftnetSolutions.Shape
{
	using SoftnetSolutions.Shape;
	/// <summary>
	/// Summary description for Circle.
	/// </summary>
	public class Ellipse : Shape, IShape
	{
		public Ellipse(Panel drawArea) : base(drawArea)
		{
		}
		
		override public void Draw()
		{
			int with = base._RandomWith;
			int heigh = base._RandomHeight;
			int radiusX = with / 2;
			int radiusY = heigh / 2;

			base._Reset();
			base._graphics.DrawEllipse( base._RandomColorPen,
										with - radiusX,//convert to bounding rectangle
										heigh - radiusY,//convert to bounding rectangle
										radiusX,
										radiusY);
		}
	}
}
