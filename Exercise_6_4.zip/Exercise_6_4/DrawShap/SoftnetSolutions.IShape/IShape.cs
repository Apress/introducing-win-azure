using System;
using System.Drawing;

namespace SoftnetSolutions.Shape
{
    public enum SHAPE_TYPE { CIRCLE, ELLIPSE, SQUER, RECTANGLE, NOT_SUPPORTED_TYPE };
    /// <summary>
	/// Summary description for Class1.
	/// </summary>
	public interface IShape
	{
		void Draw();
		Bitmap Map{ get; }
	}
}
