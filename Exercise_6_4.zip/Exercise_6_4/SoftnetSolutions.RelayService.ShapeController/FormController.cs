﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using Microsoft.ServiceBus;

namespace SoftnetSolutions.RelayService.ShapeController
{
    using SoftnetSolutions.RelayService.ServiceContract;
    using SoftnetSolutions.Shape;
    using SoftnetSolutions.Shape.Draw;
    using SoftnetSolutions.ServiceBus.QueueFacade;
    using Microsoft.Samples.ServiceBus;

    public partial class FormController : Form
    {
        private QueueClientFactory<PostData> _queueClientFactory = null;

        public FormController()
        {
            InitializeComponent();
            _queueClientFactory = new QueueClientFactory<PostData>();
        }

        private void btnCircle_Click(object sender, EventArgs e)
        {
            PostData shapeData = new PostData();
            shapeData.shape = SHAPE_TYPE.CIRCLE;
            _PostMessage(SHAPE_TYPE.CIRCLE);
        }

        private void btnRectangle_Click(object sender, EventArgs e)
        {
            PostData shapeData = new PostData();
            shapeData.shape = SHAPE_TYPE.RECTANGLE;
            _PostMessage(SHAPE_TYPE.RECTANGLE);
        }

        private void btnSqure_Click(object sender, EventArgs e)
        {
            PostData shapeData = new PostData();
            shapeData.shape = SHAPE_TYPE.SQUER;
            _PostMessage(SHAPE_TYPE.SQUER);
        }

        private void btnEcllipse_Click(object sender, EventArgs e)
        {
            PostData shapeData = new PostData();
            shapeData.shape = SHAPE_TYPE.ELLIPSE;
            _PostMessage(SHAPE_TYPE.ELLIPSE);
        }

        private void hybridConnectionStatus_ConnectionStateChanged(object sender, HybridConnectionStateChangedArgs args)
        {
            System.Diagnostics.Trace.WriteLine(string.Format("---Connection has bee switch from relay to direct connection ---{0}", Environment.NewLine));
        }

        private void _PostMessage(SHAPE_TYPE shapeType)
        {
            if (null != _queueClientFactory)
            {
                PostData postData = new PostData();
                postData.shape = shapeType;
                postData.Message = string.Format("[{0}]:Controller send <{1}> to queue", DateTime.Now.ToString(), postData.shape);
                (_queueClientFactory.QueueClient as QueueClient<PostData>).Send(postData);
            }
        }
    }
}
