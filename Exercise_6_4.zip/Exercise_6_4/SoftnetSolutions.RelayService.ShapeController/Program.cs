﻿using System;
using System.ServiceModel;
using Microsoft.ServiceBus;
using System.Text;
using System.Configuration;
using System.Windows.Forms;
using System.Threading;

namespace SoftnetSolutions.RelayService.ShapeController
{
    using SoftnetSolutions.RelayService.ServiceContract;
    //using SoftnetSolutions.Shape.Draw;

    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            FormController controller = new FormController();
            Application.Run(controller);
        }
    }
}
