﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.IO;
using System.Xml;

namespace SoftnetSolutions.AzureSolutionCredential
{
    public partial class AzureSolutionCredential 
    {
        public AzureSolutionCredential(string solutionNmae)
        {
            SolutionName = solutionNmae;
            _RetreiveXmlData();
        }

        public string SolutionName { get; set; }
        public string Password { get; set; }
        public string Subject { get; set; }
        public string Endpoint { get; set; }

        private void _RetreiveXmlData()
        {
            string embeddedXmlFileFullName = "SoftnetSolutions.AzureSolutionCredential.AzureSolutionCredential.xml";

            Assembly assembly = this.GetType().Assembly;
            Stream xmlStream = assembly.GetManifestResourceStream(embeddedXmlFileFullName);
            StreamReader sr = new StreamReader(xmlStream);
            
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(sr.ReadToEnd());
            System.Diagnostics.Trace.WriteLine(string.Format("---xml = <{0}>", xmlDoc.OuterXml));

            string xpathFormat = @"/*[local-name()='CredentialInfoRoot']/*[local-name()='SolutionCredential'][@SolutionName='{0}']/*[local-name()='{1}']";

            string xPath = string.Format(xpathFormat, SolutionName, "Password");
            Password = xmlDoc.SelectSingleNode(xPath).InnerText;
            xPath = string.Format(xpathFormat, SolutionName, "Subject");
            Subject = xmlDoc.SelectSingleNode(xPath).InnerText;
            xPath = string.Format(xpathFormat, SolutionName, "Endpoint");
            Endpoint = xmlDoc.SelectSingleNode(xPath).InnerText;
            System.Diagnostics.Trace.WriteLine(string.Format("---Password = <{0}>", Password));
        }
    }
}
