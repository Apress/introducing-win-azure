﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace SoftnetSolutions.AOP.AzurePasswordAspect
{
    using NUnit.Framework;
    [Serializable]
    public class Target
    {
        [AzureSolutionCredential("SoftnetSolutionsServiceBus")]
        public void DummyMethod()
        {
            Assembly asm = Assembly.GetCallingAssembly();// GetExecutingAssembly();
            Type type = asm.GetType();

            MethodInfo[] methodInfos = type.GetMethods();
            MethodInfo methodInfo = methodInfos.FirstOrDefault(x => x.Name == "get_Password");
            MemberInfo[] memberInfos = type.GetMembers();
            MemberInfo memberInfo = memberInfos.FirstOrDefault(x => x.Name == "get_Password");

        }
    }

    [TestFixture]
    public class Unitest
    {
        [Test]
        public void AzureSolutionCredentialInfoTest()
        {
            Target target = new Target();
            target.DummyMethod();
        }
    }
}
