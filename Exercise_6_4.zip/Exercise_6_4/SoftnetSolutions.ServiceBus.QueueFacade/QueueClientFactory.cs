﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Description;
using System.Text;
using System.ServiceModel.Channels;
using System.Configuration;

namespace SoftnetSolutions.ServiceBus.QueueFacade
{
    using Microsoft.Samples.ServiceBus;
    using SoftnetSolutions.AzureSolutionCredential;
    using CSharpBuildingBlocks.EventsHelper;    

    public class QueueClientFactory<T> where T: class
    {
        protected System.Timers.Timer _timer = null;
        protected QueueClientFactory<T> _queueClientFactory = null;
        protected QueueMessage<T> _queueMessage = null;
        protected QueueMessage<T> _lastQueueMessage = null;
        protected event EventNotificationHandler _dataUpdateEvent = null;

        public QueueClient<T> QueueClient { get; set; }
        public QueueClientFactory()
        {
            _Initialization();
            _StartQueuePollingTimer();
        }

        public event EventNotificationHandler DataUpdateEvent
        {
            add 
            {
                _dataUpdateEvent += value;
                _StartQueuePollingTimer();
            }
            remove { _dataUpdateEvent -= value; }
        }

        private void _StartQueuePollingTimer()
        {
            _timer = new System.Timers.Timer(1000);
            _timer.Elapsed += new System.Timers.ElapsedEventHandler(PollingQueueData);
            _timer.AutoReset = true;

            _timer.Enabled = true;

            _timer.Start();
        }

        private void _Initialization()
        {
            string solutionName = ConfigurationManager.AppSettings["Solution"];
            string queueName = ConfigurationManager.AppSettings["QueueName"];

            AzureSolutionCredential azureSolutionCredential = new AzureSolutionCredential(solutionName);
            Uri queueUri = ServiceBusEnvironment.CreateServiceUri("sb", solutionName, string.Format("/{0}/", queueName));
            
            TransportClientEndpointBehavior userNamePasswordServiceBusCredential = new TransportClientEndpointBehavior();
            userNamePasswordServiceBusCredential.CredentialType = TransportClientCredentialType.UserNamePassword;
            userNamePasswordServiceBusCredential.Credentials.UserName.UserName = solutionName;
            userNamePasswordServiceBusCredential.Credentials.UserName.Password = azureSolutionCredential.Password;
            
            QueuePolicy queuePolicy = new QueuePolicy();
            queuePolicy.ExpirationInstant = DateTime.UtcNow + TimeSpan.FromHours(1);
            QueueClient = QueueRenewalHelper<T>.GetOrCreateQueue<T>(userNamePasswordServiceBusCredential, queueUri, ref queuePolicy);
        }

        protected void PollingQueueData(object source, System.Timers.ElapsedEventArgs e)
        {
            if (null != QueueClient)
            {
                try
                {
                    _queueMessage = QueueClient.Retrieve();
                }
                catch { }
                if (null != _queueMessage)
                {
                    T queueData = _queueMessage.Value as T;

                    if (queueData is IComparable)
                    {
                        if (null == _lastQueueMessage
                            || (queueData as IComparable).CompareTo(_lastQueueMessage.Value) != 0)
                        {
                            _lastQueueMessage = _queueMessage;
                            if (null != _dataUpdateEvent)
                            {
                                _dataUpdateEvent(this, new QueueDataUpdateArgs<T>(_queueMessage.Value));
                            }
                        }
                    }
                    else
                    {
                        throw new ArgumentException("the data object must implemente IComparable interface!", queueData.GetType().Name);
                    }
                }
            }
        }
    }
}
