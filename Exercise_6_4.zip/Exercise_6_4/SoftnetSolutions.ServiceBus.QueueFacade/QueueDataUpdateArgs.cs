﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftnetSolutions.ServiceBus.QueueFacade
{
    using CSharpBuildingBlocks.EventsHelper;

    public class QueueDataUpdateArgs<T> :EventHelperArgs 
    {
        public T QueueData { get; set; }
        public QueueDataUpdateArgs() { }
        public QueueDataUpdateArgs(T queueData)
        {
            QueueData = queueData;
        }

        public override string ToString()
        {
            return string.Empty;
        }
    }
}
