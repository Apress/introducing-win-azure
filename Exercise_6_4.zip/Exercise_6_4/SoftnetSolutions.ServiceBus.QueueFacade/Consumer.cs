﻿using System;
using System.ServiceModel;
using Microsoft.ServiceBus;
using System.Text;
using System.ServiceModel.Channels;
using System.Configuration;

namespace SoftnetSolutions.ServiceBus.QueueFacade
{
    using SoftnetSolutions.AzureSolutionCredential;
    using Microsoft.Samples.ServiceBus;

    public class Consumer<T> where T : class
    {
        public QueueClient<T> QueueClient { get; set; }

        private void _Initialization()
        {
            string solutionName = ConfigurationManager.AppSettings["Solution"];
            string queueName = ConfigurationManager.AppSettings["QueueName"];
            
            AzureSolutionCredential azureSolutionCredential = new AzureSolutionCredential(solutionName);
            Uri queueUri = ServiceBusEnvironment.CreateServiceUri("sb", solutionName, string.Format("/{0}/", queueName));
            
            TransportClientEndpointBehavior userNamePasswordServiceBusCredential = new TransportClientEndpointBehavior();
            userNamePasswordServiceBusCredential.CredentialType = TransportClientCredentialType.UserNamePassword;
            userNamePasswordServiceBusCredential.Credentials.UserName.UserName = solutionName;
            userNamePasswordServiceBusCredential.Credentials.UserName.Password = azureSolutionCredential.Password;

            
            QueuePolicy queuePolicy = new QueuePolicy();
            queuePolicy.ExpirationInstant = DateTime.UtcNow + TimeSpan.FromHours(1);
            QueueClient = QueueRenewalHelper<T>.GetOrCreateQueue<T>(userNamePasswordServiceBusCredential, queueUri, ref queuePolicy);

            using (QueueRenewalHelper<T> queueRenewalHelper = new QueueRenewalHelper<T>(QueueClient))
            {
                for (; ; )
                {
                    QueueMessage<T> message = QueueClient.Retrieve();
                    if (message.Action == "End")
                    {
                        break;
                    }
                    //Console.WriteLine("Message #{0} sent {1} with '{2}'", message.Value.Counter, message.Value.Timestamp, message.Value.Message);
                }
            }
        }
    }
}
