//---------------------------------------------------------------------------------
// Microsoft (R) .NET Services SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.Samples.ServiceBus
{
    using System;
    using System.ServiceModel;
    using Microsoft.ServiceBus;
    using System.Text;
    using System.ServiceModel.Channels;

    using SoftnetSolutions.AzureSolutionCredential;

    class Program
    {
        static void Main(string[] args)
        {
            string solutionName = "SoftnetSolutionsServiceBus";
            AzureSolutionCredential azureSolutionCredential = new AzureSolutionCredential(solutionName);

            // create the service URI based on the solution name
            Uri queueUri = ServiceBusEnvironment.CreateServiceUri("sb", solutionName, "/MyTypedQueue/");
            
            // create the credentials object for the endpoint
            TransportClientEndpointBehavior userNamePasswordServiceBusCredential = new TransportClientEndpointBehavior();
            userNamePasswordServiceBusCredential.CredentialType = TransportClientCredentialType.UserNamePassword;
            userNamePasswordServiceBusCredential.Credentials.UserName.UserName = solutionName;
            userNamePasswordServiceBusCredential.Credentials.UserName.Password = azureSolutionCredential.Password;// solutionPassword;

            // create a new queue policy with an expiration of 1 hour
            QueuePolicy queuePolicy = new QueuePolicy();
            queuePolicy.ExpirationInstant = DateTime.UtcNow + TimeSpan.FromHours(1);
            
            // get the existing queue or create a new queue if it doesn't exist.
            QueueClient<SampleData> queueClient = GetOrCreateQueue<SampleData>(userNamePasswordServiceBusCredential, queueUri, ref queuePolicy);

            Console.WriteLine("Enter text to put into a queue message. Press [enter] to exit.");
            
            int counter = 0;
            string input = Console.ReadLine();
            while (input != String.Empty)
            {
                try
                {
                    SampleData data = new SampleData();
                    data.Message = input;
                    data.Timestamp = DateTime.UtcNow;
                    data.Counter = ++counter;
                    queueClient.Send(data);

                    Console.WriteLine("Sent: {0}", data.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: " + e.Message);
                }
                input = Console.ReadLine();
            }

            queueClient.Send(null, "End");

            // exit and leave the queue around for the consumer.
        }

        static QueueClient<T> GetOrCreateQueue<T>(TransportClientEndpointBehavior userNamePasswordServiceBusCredential, Uri queueUri, ref QueuePolicy queuePolicy) where T : class
        {
            QueueClient<T> client;

            try
            {
                client = QueueManagementClient<T>.GetQueue(userNamePasswordServiceBusCredential, queueUri);
                queuePolicy = client.GetPolicy();
                return client;
            }
            catch (EndpointNotFoundException)
            {
                // Not found; absorb and make a new queue below. 
                // Other exceptions get bubbled up.
            }
            client = QueueManagementClient<T>.CreateQueue(userNamePasswordServiceBusCredential, queueUri, queuePolicy);
            queuePolicy = client.GetPolicy();
            return client;
        }

        #region SDK Utilities
        static string ReadPassword()
        {
            StringBuilder sbPassword = new StringBuilder();

            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key == ConsoleKey.Backspace)
                {
                    if (sbPassword.Length != 0)
                    {
                        sbPassword.Remove(sbPassword.Length - 1, 1);
                        Console.Write("\b \b");     // erase last char
                    }
                }
                else if (info.KeyChar >= ' ')           // no control chars
                {
                    sbPassword.Append(info.KeyChar);
                    Console.Write("*");
                }
                info = Console.ReadKey(true);
            }

            Console.WriteLine();

            return sbPassword.ToString();
        }
        #endregion
    }
}
