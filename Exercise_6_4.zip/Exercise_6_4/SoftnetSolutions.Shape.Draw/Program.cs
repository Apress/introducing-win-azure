﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.ServiceModel;
using Microsoft.ServiceBus.Description;
using System.Configuration;
using System.Windows.Forms;

namespace SoftnetSolutions.RelayService.PublishChannel
{
    using Microsoft.ServiceBus;
    using SoftnetSolutions.Shape;
    using CSharpBuildingBlocks.EventsHelper;
    using SoftnetSolutions.Shape.Draw;

    class Program
    {
        private Program(string[] args)
        {
        }

        [STAThread]
        static void Main(string[] args)
        {
            Program programInstance = new Program(args);
            programInstance.Run();
        }

        private void Run()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormDrawShape());
        }
    }
}
