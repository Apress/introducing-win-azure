﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Configuration;
using System.IO;

namespace TableServices_WorkerRole
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.Diagnostics;
    using Microsoft.WindowsAzure.StorageClient;
    using Microsoft.WindowsAzure.ServiceRuntime;

    public class WorkerRole : RoleEntryPoint
    {
        //public static string BaseAddressUri = ConfigurationManager.AppSettings["TableStorageEndpoint"];
        //public static string AccountSharedKey = ConfigurationManager.AppSettings["AccountSharedKey"];
        //public static string AccountName = ConfigurationManager.AppSettings["AccountName"];
        public static StorageCredentialsAccountAndKey Credentails = null;

        public const string XML_PAYLOAD_QUEUE_NAME = "createxmlmessagequeue";
        public const string XML_CONTAINER_NAME = "xmlpayload";

        //private Stream CreateXmlStreamBlob(byte[] byteData)
        //{
        //    return new MemoryStream(byteData);
        //}

        public override void Run()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();
            CloudQueue queue = queueClient.GetQueueReference(XML_PAYLOAD_QUEUE_NAME);

            //Credentails = new StorageCredentialsAccountAndKey(AccountName, AccountSharedKey);
            //string queueAddress = string.Format(@"http://{0}.queue.core.windows.net/{1}", AccountName, XML_PAYLOAD_QUEUE_NAME);
            //CloudQueue queueStorage = new CloudQueue(queueAddress, Credentails);//CloudQueue.Create(StorageAccountInfo.GetDefaultQueueStorageAccountFromConfiguration());
            //CloudQueueMessage messaQequeue = queueStorage.GetMessage();// queueStorage.GetMessage(XML_PAYLOAD_QUEUE_NAME);

            //bool containerAndQueueCreated = false;
            //while (!containerAndQueueCreated)
            //{
            //    try
            //    {
            //        queueStorage.CreateIfNotExist();// queue.CreateQueue();
            //        containerAndQueueCreated = true;
            //    }
            //    catch (WebException e)
            //    {
            //        if (e.Status == WebExceptionStatus.ConnectFailure)
            //        {
            //            System.Diagnostics.Trace.WriteLine("Error", string.Format("Connect failure! The most likely reason is that the local " +
            //                "Development Storage tool is not running or your storage account configuration is incorrect. " +
            //                "Message: '{0}'", e.Message));
            //            System.Threading.Thread.Sleep(5000);
            //        }
            //        else
            //        {
            //            throw;
            //        }
            //    }
            //}

            //while (true)
            //{
            //    try
            //    {
            //        CloudQueueMessage msg = queueStorage.GetMessage();// queue.GetMessage();
            //        if (msg != null)
            //        {
            //            string path = msg.ToString();// msg.ContentAsString();

            //            System.Diagnostics.Trace.WriteLine("Information", string.Format("Done with '{0}'", path));
            //        }
            //        else
            //        {
            //            Thread.Sleep(1000);
            //        }
            //    }
            //    catch (StorageException e)
            //    {
            //        System.Diagnostics.Trace.WriteLine("Error", string.Format("Exception when processing queue item. Message: '{0}'", e.Message));
            //    }
            //}

            while (true)
            {
                Thread.Sleep(10000);

                if (queue.Exists())
                {
                    var msg = queue.GetMessage();

                    if (msg != null)
                    {
                        Trace.TraceInformation(string.Format("Message '{0}' processed.", msg.AsString));
                        queue.DeleteMessage(msg);
                    }
                }
            }
        }

        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections 
            ServicePointManager.DefaultConnectionLimit = 12;

            DiagnosticMonitor.Start("DiagnosticsConnectionString");

            // For information on handling configuration changes
            // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.
            RoleEnvironment.Changing += RoleEnvironmentChanging;

            #region Setup CloudStorageAccount Configuration Setting Publisher

            // This code sets up a handler to update CloudStorageAccount instances when their corresponding
            // configuration settings change in the service configuration file.
            CloudStorageAccount.SetConfigurationSettingPublisher((configName, configSetter) =>
            {
                // Provide the configSetter with the initial value
                configSetter(RoleEnvironment.GetConfigurationSettingValue(configName));

                RoleEnvironment.Changed += (sender, arg) =>
                {
                    if (arg.Changes.OfType<RoleEnvironmentConfigurationSettingChange>()
                        .Any((change) => (change.ConfigurationSettingName == configName)))
                    {
                        // The corresponding configuration setting has changed, propagate the value
                        if (!configSetter(RoleEnvironment.GetConfigurationSettingValue(configName)))
                        {
                            // In this case, the change to the storage account credentials in the
                            // service configuration is significant enough that the role needs to be
                            // recycled in order to use the latest settings. (for example, the 
                            // endpoint has changed)
                            RoleEnvironment.RequestRecycle();
                        }
                    }
                };
            });
            #endregion

            return base.OnStart();
        }

        private void RoleEnvironmentChanging(object sender, RoleEnvironmentChangingEventArgs e)
        {
            // If a configuration setting is changing
            if (e.Changes.Any(change => change is RoleEnvironmentConfigurationSettingChange))
            {
                // Set e.Cancel to true to restart this role instance
                e.Cancel = true;
            }
        }
    }
}
