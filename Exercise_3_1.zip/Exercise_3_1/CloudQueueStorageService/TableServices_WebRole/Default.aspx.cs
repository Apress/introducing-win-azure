﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;
using System.Text;
using System.IO;
using System.Configuration;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;

namespace TableServices_WebRole
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using Microsoft.WindowsAzure.ServiceRuntime;
    using TableServices_WorkerRole;
    using TableServices_WebRole.CloudTableStorageDataService;
    using TableServices_WebRole.CloudTableStrorageDataEntity;
    using TableServices_WebRole.CloudTableStorageDataContext;

    public partial class Default : System.Web.UI.Page
    {
        const int UPDATE_TIMEOUT_SEC = 5;
        private static CloudBlobClient _blobStorage = null;
        private static CloudBlobContainer _blobContainer = null;
        private static CloudQueueClient _queueStorage = null;
        private static CloudQueue _queue = null;

        private static bool _initialized = false;
        private static object _syncObj = new Object();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsCallback)
            {
                this._Initialization();
            }
            else
            {
            }
        }

        public void PutIntoQueue(Address address)
        {
            string xmlString = null;

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            settings.Encoding = System.Text.Encoding.UTF8;
            XmlSerializer x = new System.Xml.Serialization.XmlSerializer(typeof(Address));
            using (MemoryStream ms = new MemoryStream())
            {
                XmlWriter xw = XmlWriter.Create(ms, settings);
                x.Serialize(xw, address);
                xmlString = new UTF8Encoding().GetString(ms.ToArray());
            }
            //queue.PutMessage(new Message(xmlString));
            if (null != _queue)
            {
                _queue.AddMessage(new CloudQueueMessage(xmlString));
            }
        }

        //public string GetItemFromMessage(Message msg)
        //{
        //    string xmlString = string.Empty;
        //    if (msg == null || msg.ContentAsBytes() == null)
        //    {
        //        throw new ArgumentNullException("msg");
        //    }
        //    xmlString = BitConverter.ToString(msg.ContentAsBytes());
        //    return xmlString;
        //}

        protected void btnAddAddress_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                if(!_initialized)
                {
                    this._Initialization();
                }

                CloudBlob blob = _blobContainer.GetBlobReference(WorkerRole.XML_CONTAINER_NAME);
                blob.Properties.ContentType = "text/xml";
                blob.UploadFromStream(_ComposeStream());

                if (null != _queue)
                {
                    _queue.CreateIfNotExist();
                    _queue.AddMessage(new CloudQueueMessage(_ComposeXmlString()));
                }
            }
        }

        protected void Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                CloudQueueMessage message = _queue.GetMessage(new TimeSpan(0, 0, UPDATE_TIMEOUT_SEC));
                if (message != null)
                {
                    btnDelete.Enabled = true;

                    LabelMessage.Text = Server.HtmlEncode(message.AsString);
                }
                else
                {
                    btnDelete.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.Write(string.Format("--- {0}:exception caught, {1}", this.ToString(), ex.Message));
            }
        }

        private Stream _ComposeStream()
        {
            Address address = new Address(txtAddress1.Text.Trim(),
                                         txtAddress2.Text.Trim(),
                                         txtCity.Text.Trim(),
                                         (State)combState.SelectedIndex,
                                         txtZip.Text.Trim(),
                                         txtCounty.Text.Trim(),
                                         txtCountry.Text.Trim(),
                                         string.Empty);

            XmlSerializer serializer = new XmlSerializer(address.GetType());
            StringBuilder sb = new StringBuilder();
            StringWriter writer = new StringWriter(sb);

            serializer.Serialize(writer, address);
            byte[] buffer = UTF8Encoding.UTF8.GetBytes(writer.GetStringBuilder().ToString());

            MemoryStream memoryStream = new MemoryStream(buffer);

            return memoryStream;
        }

        private string _ComposeXmlString()
        {
            Address address = new Address(txtAddress1.Text.Trim(),
                                         txtAddress2.Text.Trim(),
                                         txtCity.Text.Trim(),
                                         (State)combState.SelectedIndex,
                                         txtZip.Text.Trim(),
                                         txtCounty.Text.Trim(),
                                         txtCountry.Text.Trim(),
                                         string.Empty);

            XmlSerializer serializer = new XmlSerializer(address.GetType());
            StringBuilder sb = new StringBuilder();
            StringWriter writer = new StringWriter(sb);

            serializer.Serialize(writer, address);

            return writer.GetStringBuilder().ToString();
        }

        private void _Initialization()
        {
            if (_initialized)
            {
                return;
            }

            lock (_syncObj)
            {
                try
                {
                    CloudStorageAccount storageAccount = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
                    _queueStorage = storageAccount.CreateCloudQueueClient();
                    _queue = _queueStorage.GetQueueReference(WorkerRole.XML_PAYLOAD_QUEUE_NAME);
                    _queue.CreateIfNotExist();

                    _blobStorage = storageAccount.CreateCloudBlobClient();
                    _blobContainer = _blobStorage.GetContainerReference(WorkerRole.XML_CONTAINER_NAME);//RoleEnvironment.GetConfigurationSettingValue("ContainerName"));
                    _blobContainer.CreateIfNotExist();
                    var permissions = _blobContainer.GetPermissions();
                    permissions.PublicAccess = BlobContainerPublicAccessType.Container;
                    _blobContainer.SetPermissions(permissions);

                }
                catch (WebException)
                {
                    // display a nice error message if the local development storage tool is not running or if there is 
                    // an error in the account configuration that causes this exception
                    throw new WebException("The Windows Azure storage services cannot be contacted " +
                         "via the current account configuration or the local development storage tool is not running. " +
                         "Please start the development storage tool if you run the service locally!");
                }

                _initialized = true;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            if (null != _queue)
            {
                CloudQueueMessage message = _queue.GetMessage(new TimeSpan(0, 0, UPDATE_TIMEOUT_SEC));
                _queue.DeleteMessage(message);

            }
        }


        //protected void Page_PreRender(object sender, EventArgs e)
        //{
        //    AzureForDotNetDeveloperQueueView.DataSource = from o
        //                                                  in GetXmlPayloadContainer().ListBlobs(string.Format("{0}/", WorkerRole.XML_BLOB_QUEUE_NAME), false)
        //                                                  select new { Url = ((BlobProperties)o).Uri };
        //    AzureForDotNetDeveloperQueueView.DataBind();
        //}
    }
}
