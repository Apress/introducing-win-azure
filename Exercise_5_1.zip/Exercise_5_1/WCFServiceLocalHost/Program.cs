using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Description;
using System.Text;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{
    using AzureForDotNetDeveloper.DotNetService.ServiceBus.WCFServiceLibrary;

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(string.Format("--- WCF Service local host --- {0}--- Please enter your Azure Solution Name:{0}", Environment.NewLine));
            string solutionName = Console.ReadLine();
            Console.Write(string.Format("--- Solution Password: {0}", Environment.NewLine));
            string solutionPassword = AccountFederationService.ProcessPassword();

            Uri address = new Uri(String.Format("sb://{0}/services/{1}/AuthenticationService/", ServiceBusEnvironment.DefaultIdentityHostName, solutionName));
            TransportClientEndpointBehavior userNamePasswordServiceBusCredential = new TransportClientEndpointBehavior();
            userNamePasswordServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret;// UserNamePassword;
            userNamePasswordServiceBusCredential.Credentials.SharedSecret.IssuerName = solutionName;// UserName.UserName = solutionName;
            userNamePasswordServiceBusCredential.Credentials.SharedSecret.IssuerSecret = solutionPassword;// UserName.Password = solutionPassword;

            ServiceHost host = new ServiceHost(typeof(AccountFederationService), address);

            //add the Service Bus credentials to all endpoints specified in configuration
            foreach (ServiceEndpoint endpoint in host.Description.Endpoints)
            {
                endpoint.Behaviors.Add(userNamePasswordServiceBusCredential);
            }
            
            host.Open();

            Console.WriteLine(string.Format("--- Authentication successed from .Net access service.{1}Service address: {1}{0}{1}",  address, Environment.NewLine));
            Console.WriteLine(string.Format("--- Ready to receive message...{0} Press <Enter> to terminate server ---", Environment.NewLine));
            Console.ReadLine();

            host.Close();
        }
    }
}