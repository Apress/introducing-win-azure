using System;
using System.ServiceModel;
using Microsoft.ServiceBus;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{
    using AzureForDotNetDeveloper.DotNetService.ServiceBus.WCFServiceLibrary;

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(string.Format("--- Test Client--- {0}--- Please enter your Azure Solution Name:{0} ", Environment.NewLine));
            string solutionName = Console.ReadLine();
            Console.Write(string.Format("--- Solution Password: {0}", Environment.NewLine));
            string solutionPassword = AccountFederationService.ProcessPassword();

            // create the service URI based on the solution name
            Uri serviceUri = new Uri(String.Format("sb://{0}/services/{1}/AuthenticationService/", ServiceBusEnvironment.DefaultIdentityHostName, solutionName));
            TransportClientEndpointBehavior userNamePasswordServiceBusCredential = new TransportClientEndpointBehavior();
            userNamePasswordServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret;// UserNamePassword;
            userNamePasswordServiceBusCredential.Credentials.SharedSecret.IssuerName = solutionName;// UserName.UserName = solutionName;
            userNamePasswordServiceBusCredential.Credentials.SharedSecret.IssuerSecret = solutionPassword;// UserName.Password = solutionPassword;

            //create the channel factory loading the configuration
            ChannelFactory<IAccountFederationClientChannel> channelFactory = new ChannelFactory<IAccountFederationClientChannel>("RelayEndpoint", new EndpointAddress(serviceUri));

            //apply the Service Bus credentials
            channelFactory.Endpoint.Behaviors.Add(userNamePasswordServiceBusCredential);

            // create and open the client channel
            IAccountFederationClientChannel channel = channelFactory.CreateChannel();
            channel.Open();
          

            Console.WriteLine(string.Format("--- Plese type meessage to ping service:{0}", Environment.NewLine));
            string inputMessage = Console.ReadLine();
            while (inputMessage != String.Empty)
            {
                try
                {
                    Console.WriteLine("--- Recieve response from Server: {0}", channel.PingServer(inputMessage));
                }
                catch (Exception e)
                {
                    Console.WriteLine(string.Format("--- Test Client:Program, exceptin caught :{0}", e.Message));
                }
                inputMessage = Console.ReadLine();
            }

            channel.Close();
            channelFactory.Close();
        }

    }
}
