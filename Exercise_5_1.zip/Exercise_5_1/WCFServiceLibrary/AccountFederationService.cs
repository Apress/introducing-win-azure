﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Diagnostics;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus.WCFServiceLibrary
{
    [ServiceBehavior(Name = "AccountFederationService", Namespace = "http://SoftnetSolutions.com/ServiceModel/Relay/")]
    public class AccountFederationService : IAccountFederationService
    {
        public string PingServer(string message)
        {
            string results = string.Format("---{0}:PingServer, message received from client : {1}{2}",
                                           this.ToString(),
                                           Environment.NewLine,
                                           message);
            Console.WriteLine(results);
            Trace.WriteLine(results);
            return message;
        }

        #region Console Utilities

        static public string ProcessPassword()
        {
            StringBuilder password = new StringBuilder();

            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key == ConsoleKey.Backspace)
                {
                    if (password.Length != 0)
                    {
                        password.Remove(password.Length - 1, 1);
                        Console.Write("\b \b");
                    }
                }
                else if (info.KeyChar >= ' ') 
                {
                    password.Append(info.KeyChar);
                    Console.Write("*");
                }
                info = Console.ReadKey(true);
            }

            Console.WriteLine();
            Console.Write(string.Format("--- Please set back and wait your account beend authenticated from .Net access service {0}{0}...{0}", Environment.NewLine));

            return password.ToString();
        }

        #endregion
    }
}
