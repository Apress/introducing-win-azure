﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus.WCFServiceLibrary
{
    [ServiceContract(Name = "IAccountFederationService", Namespace = "http://SoftnetSolutions.com/ServiceModel/Relay/")]
    public interface IAccountFederationService
    {
        [OperationContract]
        string PingServer(string message);
    }
}
