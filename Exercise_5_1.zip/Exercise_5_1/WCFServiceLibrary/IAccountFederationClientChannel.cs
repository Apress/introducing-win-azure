﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus.WCFServiceLibrary
{
    public interface IAccountFederationClientChannel : IAccountFederationService, IClientChannel { }
}
