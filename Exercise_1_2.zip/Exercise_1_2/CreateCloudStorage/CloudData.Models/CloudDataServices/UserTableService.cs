﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace CreateDataStorage.Models.CloudDataServices
{
    using Microsoft.WindowsAzure.StorageClient;
    using CreateDataStorage.Models.CloudData;

    public class UserTableService : DataTableService, IHasDependcyTableService
    {
        public UserTableService()
        {
            _Table = ConfigurationManager.AppSettings["UserTable"];
        }

        public bool UpdateDependencyTable(TableServiceEntity entity)
        {
            bool success = false;

            try
            {
                PersonTableService personTableService = new PersonTableService();
                var person = (from p in _userDataContext.PersonTable where p.RowKey == (entity as Person).InternalID select p).Single<Person>();
                if (null != person)
                {
                    personTableService.DataContext().DeleteObject(person);
                }

                personTableService.Insert(entity);
                personTableService.DataContext().SaveChanges();
                success = true;
            }
            catch { }

            return success;
        }
    }
}
