﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace CreateDataStorage.Models.CloudDataServices
{
    using Microsoft.WindowsAzure.StorageClient;
    using CreateDataStorage.Models.CloudData;

    public class PersonTableService : DataTableService, IHasDependcyTableService
    {
        public PersonTableService()
        {
            _Table = ConfigurationManager.AppSettings["PersonTable"];
        }

        public bool UpdateDependencyTable(TableServiceEntity entity)
        {
            bool success = false;

            try
            {
                AddressTableService addressService = new AddressTableService();
                var address = (from a in _userDataContext.AddressTable where a.RowKey == (entity as Address).InternalID select a).Single<Address>();
                if (null != address)
                {
                    addressService.DataContext().DeleteObject(address);
                }

                addressService.Insert(entity);
                addressService.DataContext().SaveChanges();
                success = true;
            }
            catch { }

            return success;
        }

    }
}
