﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

using Microsoft.WindowsAzure.StorageClient;

namespace CreateDataStorage.Models.CloudData
{
    public class Person : TableServiceEntity
    {
        private Guid _id;
        private Address _address = null;

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleInitial { get; set; }
        public string Sufix { get; set; }

        public Person(Guid id)
            : base(ConfigurationManager.AppSettings["PartitionKey"], id.ToString())
        {
            _id = id;
        }

        public Person(string firstName,
                      string lastName,
                      string middleInitial,
                      string sufix,
                      Guid id)
            : this(id)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        public Person(string firstName,
                      string lastName,
                      string middleInitial,
                      string sufix,
                      Address address,
                      Guid id)
            : this(firstName,
                 lastName,
                 middleInitial,
                 sufix,
                 id)
        {
            _address = address;
        }

        public string InternalID { get { return base.RowKey; } }

        public Address GetAddress() { return _address; }
        public void SetAddress(Address address) { _address = address; }
    }
}