﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using Microsoft.WindowsAzure.StorageClient;

namespace CreateDataStorage.Models.CloudData
{
    public class User : TableServiceEntity
    {
        private Person _person = null;
        public string Password { get; set; }
        public string InternalID { get { return base.RowKey; } }

        public User()
            : base(ConfigurationManager.AppSettings["PartitionKey"], Guid.NewGuid().ToString())
        { 
        }

        public User(string password):this()
        {
            Password = password;
        }

        public User(object person, string password)
            : this(password)
        {
            _person = person as Person;
        }

        public Person GetPerson() { return _person; }
        public void SetPerson(Person person) { _person = person; }
    }
}
