﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace TableServices_WebRole.CloudTableStorageDataContext
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStrorageDataEntity;

    public class AddressTableContext : TableContext
    {
        internal AddressTableContext(string baseAddress, StorageCredentials credentials)
            : base(baseAddress, credentials)
        {
            TableName = ConfigurationManager.AppSettings["AddressTable"];
        }

        public IQueryable<Address> AddressTable
        {
            get { return CreateQuery<Address>(TableName); }
        }

    }
}
