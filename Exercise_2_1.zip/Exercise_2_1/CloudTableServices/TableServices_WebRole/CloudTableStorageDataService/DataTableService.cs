﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TableServices_WebRole.CloudTableStorageDataService
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStorageDataContext;

    abstract public class DataTableService
    {
        protected TableContext _dataTableContext = null;

        public DataTableService()
        {
        }

        public TableContext TabeContext() { return _dataTableContext; }
    }
}
