﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Data.Services.Client;

namespace TableServices_WebRole
{
    using TableServices_WebRole.CloudTableStorageDataService;
    using TableServices_WebRole.CloudTableStrorageDataEntity;
    using TableServices_WebRole.CloudTableStorageDataContext;

    public partial class WebForm1 : System.Web.UI.Page
    {
        private AddressTableService _addressTableServicve = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsCallback)
            {
                _addressTableServicve = new AddressTableService();
            }
            else
            {
                _DataBinding();
            }
        }

        protected void btnAddAddress_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                _DataBinding();
            }

        }

        private void _DataBinding()
        {
            AddressView.DataBind();
        }
    }
}
