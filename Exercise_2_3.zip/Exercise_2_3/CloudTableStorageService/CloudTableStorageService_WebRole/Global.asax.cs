﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Configuration;

namespace TableServices_WebRole
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using Microsoft.WindowsAzure.ServiceRuntime;
    using TableServices_WebRole.CloudTableStorageDataContext;
    using TableServices_WebRole.CloudTableStorageDataService;
    using TableServices_WebRole.CloudTableStrorageDataEntity;

    public class Global : System.Web.HttpApplication
    {
        public static AddressTableContext AddressTableContext = null;
        public static PersonTableContext PersonTableContext = null;
        public static UserTableContext UserTableContext = null;

        protected void Application_Start(object sender, EventArgs e)
        {

        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            HttpApplication app = (HttpApplication)sender;
            HttpContext context = app.Context;

            // Attempt to peform first request initialization
            FirstRequestInitialization.Initialize(context);
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }

    internal class FirstRequestInitialization
    {
        private static bool s_InitializedAlready = false;
        private static Object s_lock = new Object();


        // Initialize only on the first request
        public static void Initialize(HttpContext context)
        {
            if (s_InitializedAlready)
            {
                return;
            }

            lock (s_lock)
            {
                if (s_InitializedAlready)
                {
                    return;
                }

                ApplicationStartUponFirstRequest(context);
                s_InitializedAlready = true;
            }
        }

        private static void ApplicationStartUponFirstRequest(HttpContext context)
        {
            // This is where you put initialization logic for the site.
            // RoleManager is properly initialized at this point.

            // Create the tables on first request to improve performance adn avoid to call
            // CreateTablesFromModel() multiple times.

            // Get the settings from the Service Configuration file
            CloudStorageAccount account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            CloudTableClient.CreateTablesFromModel(typeof(AddressTableContext),
                                                   account.TableEndpoint.AbsoluteUri,
                                                   account.Credentials);
            Global.AddressTableContext = new AddressTableContext(account.TableEndpoint.ToString(), account.Credentials);
            Global.PersonTableContext = new PersonTableContext(account.TableEndpoint.ToString(), account.Credentials);
            Global.UserTableContext = new UserTableContext(account.TableEndpoint.ToString(), account.Credentials);
        }
    }
}