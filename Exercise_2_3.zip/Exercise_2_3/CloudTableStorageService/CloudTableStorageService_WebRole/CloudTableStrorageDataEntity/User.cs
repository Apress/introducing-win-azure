﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TableServices_WebRole.CloudTableStrorageDataEntity
{
    using Microsoft.WindowsAzure.StorageClient;

    public class User : CloudTableStorageEntity
    {
        private Person _person = null;
        public string Password { get; set; }

        public User()
            : base(Guid.NewGuid().ToString(), Guid.NewGuid().ToString())
        {
        }

        public User(string partitionKey, string rowKey)
            : base(partitionKey, rowKey)
        { 
        }

        public User(string password)
            : this()
        {
            Password = password;
        }

        public User(object person, string password)
            : this(password)
        {
            _person = person as Person;
        }

        override public ICloudEntity GetDepencyEntity() { return _person; }
        override public void SetDependencyEntity(ICloudEntity entity) { _person = entity as Person; }

        override protected void _Initialization()
        {
            base._depencencyEntityTypeList.Add(new Person());
        }
    }
}
