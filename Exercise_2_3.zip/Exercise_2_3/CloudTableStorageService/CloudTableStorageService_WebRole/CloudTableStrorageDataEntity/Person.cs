﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TableServices_WebRole.CloudTableStrorageDataEntity
{
    using Microsoft.WindowsAzure.StorageClient;

    public class Person : CloudTableStorageEntity
    {
        private Address _address = null;

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleInitial { get; set; }
        public string Sufix { get; set; }

        public Person()
            :this(Guid.NewGuid().ToString(), Guid.NewGuid().ToString())
        {
        }
        public Person(string partitionKey, string rowKey)
            : base(partitionKey, rowKey)
        { 
        }

        public Person(string partitionKey)
            : this(partitionKey, Guid.NewGuid().ToString())
        {
        }

        public Person(string firstName,
                      string lastName,
                      string middleInitial,
                      string sufix,
                      string parentRowKey)
            : this(parentRowKey)
        {
            FirstName = firstName;
            LastName = lastName;
            MiddleInitial = middleInitial;
            Sufix = sufix;
        }

        public Person(string firstName,
                      string lastName,
                      string middleInitial,
                      string sufix,
                      Address address,
                      string parentRowKey)
            : this(firstName,
                 lastName,
                 middleInitial,
                 sufix,
                 parentRowKey)
        {
            FirstName = firstName;
            LastName = lastName;
            MiddleInitial = middleInitial;
            Sufix = sufix;
            _address = address;
        }

        override public ICloudEntity GetDepencyEntity() { return _address; }
        override public void SetDependencyEntity(ICloudEntity entity) { _address = entity as Address; }

        override protected void _Initialization()
        {
            base._depencencyEntityTypeList.Add(new Address());
        }
    }
}
