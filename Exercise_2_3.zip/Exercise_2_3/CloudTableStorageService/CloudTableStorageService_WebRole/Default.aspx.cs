﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TableServices_WebRole
{
    using TableServices_WebRole.CloudTableStorageDataService;
    using TableServices_WebRole.CloudTableStrorageDataEntity;

    public partial class Default : System.Web.UI.Page
    {
        private UserTableService _userTableServicve = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsCallback)
            {
                _userTableServicve = new UserTableService();
            }
            else
            {
                _DataBinding();
            }
        }

        protected void btnAddAddress_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                _InsertUser();

                _DataBinding();
            }

        }

        private void _InsertUser()
        {
            User user = new User();
            user.Password = txtPassword.Text.Trim();

            Person person = new Person(txtFirstName.Text.Trim(),
                                       txtLastName.Text.Trim(),
                                       txtMiddelInitial.Text.Trim(),
                                       txtSufix.Text.Trim(),
                                       user.GetRowKey());

            user.SetDependencyEntity(person);
  
            Address address = new Address(txtAddress1.Text.Trim(),
                                          txtAddress2.Text.Trim(),
                                          txtCity.Text.Trim(),
                                          (State)combState.SelectedIndex,
                                          txtZip.Text.Trim(),
                                          txtCounty.Text.Trim(),
                                          txtCountry.Text.Trim(),
                                          person.GetRowKey());

            person.SetDependencyEntity(address);

            _userTableServicve.Insert(user as User);

        }

        private void _DataBinding()
        {
            AddressView.DataBind();
            PersonView.DataBind();
            UserView.DataBind();
        }

        protected void UserView_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string rowKey = ((GridView)e.CommandSource).SelectedPersistedDataKey.Value.ToString();
            User user = new User(string.Empty, rowKey);
            _userTableServicve.Delete(user);

            _DataBinding();
        }
     }
}
