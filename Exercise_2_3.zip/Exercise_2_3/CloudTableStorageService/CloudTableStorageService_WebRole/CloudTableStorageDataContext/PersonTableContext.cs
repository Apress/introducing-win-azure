﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace TableServices_WebRole.CloudTableStorageDataContext
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStrorageDataEntity;

    public class PersonTableContext : TableContext
    {
        public PersonTableContext(string baseAddress, StorageCredentials credentials)
            : base(baseAddress, credentials)
        {
            TableName = ConfigurationManager.AppSettings["PersonTable"];
        }

        public IQueryable<Person> PersonTable
        {
            get { return CreateQuery<Person>(TableName); }
        }

        override public ICloudEntity QueryEntitiesByPartionKey(string partitionKey)
        {
            //return PersonTable.Where(p => p.PartitionKey == partitionKey) as ICloudEntity;
            ICloudEntity entity = null;

            foreach (Person person in PersonTable)
            {
                if (person.PartitionKey == partitionKey)
                {
                    entity = person;
                    break;
                }
            }

            return entity;
        }

        override public ICloudEntity QueryEntitiesByRowKey(string rowKey)
        {
            //return PersonTable.Where(p => p.RowKey == rowKey) as ICloudEntity;
            ICloudEntity entity = null;

            foreach (Person person in PersonTable)
            {
                if (person.RowKey == rowKey)
                {
                    entity = person;
                    break;
                }
            }

            return entity;
        }
    }
}
