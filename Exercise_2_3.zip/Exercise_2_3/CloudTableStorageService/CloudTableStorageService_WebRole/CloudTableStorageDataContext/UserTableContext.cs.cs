﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace TableServices_WebRole.CloudTableStorageDataContext
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStrorageDataEntity;

    public class UserTableContext : TableContext
    {
        public UserTableContext(string baseAddress, StorageCredentials credentials)
            : base(baseAddress, credentials)
        {
            TableName = ConfigurationManager.AppSettings["UserTable"];
        }

        public IQueryable<User> UserTable
        {
            get { return CreateQuery<User>(TableName); }
        }

        override public ICloudEntity QueryEntitiesByPartionKey(string rowKey)
        {
            ICloudEntity entity = null;

            foreach (User user in UserTable)
            {
                if (user.PartitionKey == rowKey)
                {
                    entity = user;
                    break;
                }
            }

            return entity;
        }

        override public ICloudEntity QueryEntitiesByRowKey(string rowKey)
        {
//            return UserTable.Where(u => u.GetRowKey() == rowKey) as ICloudEntity;
            ICloudEntity entitie = null;

            foreach (User user in UserTable)
            {
                if (user.RowKey == rowKey)
                {
                    entitie = user;
                    break;
                }
            }

            return entitie;
        }
    }
}
