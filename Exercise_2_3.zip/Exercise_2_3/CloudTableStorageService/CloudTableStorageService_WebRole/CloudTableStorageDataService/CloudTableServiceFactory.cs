﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;

namespace TableServices_WebRole.CloudTableStorageDataService
{
    using TableServices_WebRole.CloudTableStrorageDataEntity;
    public class CloudTableServiceFactory
    {
        public CloudTableServiceFactory()
        {
        }

        public ICloudTableStorageService FactoryCloudTableService(ICloudEntity entity)
        {
            ICloudTableStorageService cloudTableStorageService = null;

            try
            {
                Assembly assembly = Assembly.GetExecutingAssembly();
                string typeName = string.Format("{0}.{1}TableService", this.GetType().Namespace, entity.GetType().Name);
                cloudTableStorageService = Activator.CreateInstance(assembly.GetType(typeName), new object[] { }) as ICloudTableStorageService;
            }
            catch (Exception ex)
            {
            }

            return cloudTableStorageService;
        }
    }
}
