﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Services.Client;
using System.Configuration;

namespace TableServices_WebRole.CloudTableStorageDataService
{
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStrorageDataEntity;
    using TableServices_WebRole.CloudTableStorageDataContext;

    public class UserTableService : DataTableService, ICloudTableStorageService
    {
        public UserTableService()
        {
            _dataTableContext = Global.UserTableContext;
            _dataTableContext.RetryPolicy = RetryPolicies.Retry(Convert.ToInt32(ConfigurationManager.AppSettings["Retry"]), TimeSpan.FromSeconds(1));
        }

        public IEnumerable<User> Select()
        {
            if (null == _dataTableContext || null == (_dataTableContext as UserTableContext))
            {
                return null;
            }

            var results = from a in (_dataTableContext as UserTableContext).UserTable
                          select a;

            if (0 == (results as DataServiceQuery<User>).ToArray<User>().Count<User>())
            {
                return null;
            }

            CloudTableQuery<User> query = new CloudTableQuery<User>(results as DataServiceQuery<User>);
            IEnumerable<User> queryResults = query.Execute();
            return queryResults;
        }

        public bool Delete(User entity)
        {
            return base.Delete(entity);
        }
    }
}
