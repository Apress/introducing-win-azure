﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Services.Client;
using System.Configuration;

namespace TableServices_WebRole.CloudTableStorageDataService
{
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStrorageDataEntity;
    using TableServices_WebRole.CloudTableStorageDataContext;

    public class PersonTableService: DataTableService
    {
        public PersonTableService()
        {
            _dataTableContext = Global.PersonTableContext;
            _dataTableContext.RetryPolicy = RetryPolicies.Retry(Convert.ToInt32(ConfigurationManager.AppSettings["Retry"]), TimeSpan.FromSeconds(1));
        }

        public IEnumerable<Person> Select()
        {
            if (null == _dataTableContext || null == (_dataTableContext as PersonTableContext))
            {
                return null;
            }

            var results = from a in (_dataTableContext as PersonTableContext).PersonTable
                          select a;

            if (0 == (results as DataServiceQuery<Person>).ToArray<Person>().Count<Person>())
            {
                return null;
            }

            CloudTableQuery<Person> query = new CloudTableQuery<Person>(results as DataServiceQuery<Person>);
            IEnumerable<Person> queryResults = query.Execute();
            return queryResults;
        }

        public bool Delete(Person entity)
        {
            return base.Delete(entity);
        }
    }
}
