using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace SoftnetSolutions.Shape
{
	using SoftnetSolutions.Shape;
	/// <summary>
	/// Summary description for Circle.
	/// </summary>
	public class Circle : Shape, IShape
	{
		public Circle(Panel drawArea) : base(drawArea)
		{
		}
		
		override public void Draw()
		{
			int with = base._RandomWith;
			int heigh = base._RandomHeight;
			int radius = with / 2;

			base._Reset();
			base._graphics.DrawEllipse( base._RandomColorPen,
										with - radius,//convert to bounding rectangle
										heigh - radius,//convert to bounding rectangle
										radius,
										radius);
		}
	}
}
