using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace SoftnetSolutions.Shape
{
    abstract public class Shape : IShape
    {
        const PixelFormat PIXELFORMAT = PixelFormat.Format24bppRgb;
        protected Bitmap _bitmap = null;
        protected Random _random = null;
        protected Graphics _graphics = null;
        protected int _shapeWith = 0;
        protected int _shapeHeight = 0;
        protected int _drawAreaWith = 0;
        protected int _drawAreaHeight = 0;


        public Shape(Panel drawArea)
        {
            if (null == drawArea
                || drawArea.Width <= 0
                || drawArea.Height <= 0)
            {
                throw new ArgumentException("The draw area must be specified and invalid", drawArea.ToString());
            }

            _random = new Random((int)DateTime.Now.Ticks);
            _bitmap = new Bitmap(drawArea.ClientRectangle.Width,
                                 drawArea.ClientRectangle.Height,
                                 PIXELFORMAT);
            _graphics = Graphics.FromImage(_bitmap);
            _drawAreaWith = drawArea.Width;
            _drawAreaHeight = drawArea.Height;
        }

        #region Property

        public Bitmap Map
        {
            get { return _bitmap; }
        }

        public int ShageWith
        {
            get { return _shapeWith; }
        }

        public int ShapeHeight
        {
            get { return _shapeHeight; }
        }

        protected int _RandomWith
        {
            get
            {
                _shapeWith = _random.Next(0, _drawAreaWith);
                return _shapeWith;
            }
        }

        protected int _RandomHeight
        {
            get
            {
                _shapeHeight = _random.Next(0, _drawAreaHeight);
                return _shapeHeight;
            }
        }

        protected Pen _RandomColorPen
        {
            get
            {
                return new Pen(Color.FromArgb(_random.Next(0, 255),
                    _random.Next(0, 255),
                    _random.Next(0, 255)));
            }
        }

        #endregion

        #region Protected Method

        protected void _Reset()
        {
            if (null != _bitmap)
            {
                Graphics.FromImage(this._bitmap).Clear(Color.Black);
            }
        }

        #endregion

        abstract public void Draw();
    }
}
