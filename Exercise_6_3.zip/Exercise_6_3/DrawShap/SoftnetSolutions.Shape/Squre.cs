using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace SoftnetSolutions.Shape
{
	using SoftnetSolutions.Shape;
	/// <summary>
	/// Summary description for Squre.
	/// </summary>
	public class Squre: Shape, IShape
	{
		public Squre(Panel drawArea) : base(drawArea)
		{
		}
			
		override public void Draw()
		{
			int with = base._RandomWith / 2;
			base._Reset();
			base._graphics.DrawRectangle(base._RandomColorPen,
										 with,
										 with,
										 with,
										 with );
		}
	}
}
