using System;
using System.ServiceModel;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    [ServiceContract(Name = "IPublishEventService", 
        Namespace = "http://SoftnetSolutions.RelayService/")]
    public interface IPublishEventService
    {
        [OperationContract(IsOneWay = true)]
        void PostMessage(PostData postData);

        [OperationContract(IsOneWay = true)]
        void OnShapeSelectChanged(PostData shapeData);
    }

    public interface IPublishEventServiceChannel : IPublishEventService, IClientChannel { }
}
