﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using Microsoft.ServiceBus;
using System.Text;
using System.Configuration;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    public class RelayPublishServiceHost<T> where T:class
    {
        public ServiceHost Host { get; set; }

        public RelayPublishServiceHost(T serviceImpl)
        {
            string subject = ConfigurationManager.AppSettings["Topic"];
            string solutionName = ConfigurationManager.AppSettings["Solution"];
            string password = ConfigurationManager.AppSettings["password"];

            TransportClientEndpointBehavior relayCredentials = new TransportClientEndpointBehavior();
            relayCredentials.CredentialType = TransportClientCredentialType.UserNamePassword;
            relayCredentials.Credentials.UserName.UserName = solutionName;
            relayCredentials.Credentials.UserName.Password = password;

            Uri address = ServiceBusEnvironment.CreateServiceUri("sb",
                solutionName,
                subject);

            Host = new ServiceHost(serviceImpl, address);
            Host.Description.Endpoints[0].Behaviors.Add(relayCredentials);
            Host.Open();
        }
    }
}
