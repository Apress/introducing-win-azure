using System;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    using SoftnetSolutions.Shape;

    [ServiceBehavior(Name = "PublishEventService",
        Namespace = "http://SoftnetSolutions.RelayService/",
        InstanceContextMode = InstanceContextMode.Single)]
    public class PublishEventService : IPublishEventService
    {
        public void PostMessage(PostData postData)
        {
            Console.WriteLine(string.Format("---Host received message: <{0}>", postData.Message));
        }

        public void OnShapeSelectChanged(PostData shapeData)
        {
            if (null != shapeData)
            {
                System.Diagnostics.Trace.WriteLine(string.Format("---Host received OnShapeSelectChanged: <{0}>", shapeData.shape.ToString()));
            }
        }
    }
}
