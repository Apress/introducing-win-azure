﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    using SoftnetSolutions.Shape;

    [DataContract]
    public class PostData
    {
        [DataMember]
        public string Message;

        [DataMember]
        public SHAPE_TYPE shape;
    }
}
