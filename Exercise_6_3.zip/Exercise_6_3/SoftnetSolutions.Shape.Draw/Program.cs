﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.ServiceModel;
using Microsoft.ServiceBus.Description;
using System.Configuration;
using System.Windows.Forms;

namespace SoftnetSolutions.RelayService.PublishChannel
{
    using Microsoft.ServiceBus;
    using SoftnetSolutions.Shape;
    using SoftnetSolutions.RelayService.ServiceContract;
    using CSharpBuildingBlocks.EventsHelper;
    using SoftnetSolutions.Shape.Draw;

    class Program
    {
        private Program(string[] args)
        {
        }

        [STAThread]
        static void Main(string[] args)
        {
            Program programInstance = new Program(args);
            programInstance.Run();
        }

        private void Run()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (DialogResult.Cancel == MessageBox.Show("Please start the demo from ShapeController.", "Notification", MessageBoxButtons.OKCancel))
            {

                IPublishEventService form = new FormDrawShape();
                RelayPublishServiceHost<IPublishEventService> host = new RelayPublishServiceHost<IPublishEventService>(form);

                Application.Run(form as FormDrawShape);
            }
        }
    }
}
