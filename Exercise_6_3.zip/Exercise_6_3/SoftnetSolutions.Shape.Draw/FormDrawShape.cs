﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.ServiceModel;
using Microsoft.ServiceBus.Description;
using System.Reflection;
using System.Threading;
using System.Diagnostics;

namespace SoftnetSolutions.Shape.Draw
{
    using Microsoft.ServiceBus;
    using SoftnetSolutions.Shape;
    using CSharpBuildingBlocks.EventsHelper;
    using SoftnetSolutions.RelayService.ServiceContract;

    [ServiceBehavior(Name = "PublishEventService",
        Namespace = "http://SoftnetSolutions.RelayService/",
        InstanceContextMode = InstanceContextMode.Single)]
    public partial class FormDrawShape : Form, IPublishEventService
    {
        private string[] SHAPE_NAME = new string[] { "Circle", "Ellipse", "Squre", "Rectangle" };
        private IShape _shape = null;
        private SHAPE_TYPE _shapeType = SHAPE_TYPE.NOT_SUPPORTED_TYPE;
        private string _ReceivedMessage { get; set; }

        public FormDrawShape()
        {
            InitializeComponent();

            radioBtnCircle_CheckedChanged(this, null);
            btnStart_Click(this, null);
        }

        #region IPublishEventService implementation

        public void OnShapeSelectChanged(PostData postData)
        {
            if (null != postData)
            {
                switch (postData.shape)
                {
                    case SHAPE_TYPE.CIRCLE:
                        radioBtnCircle_CheckedChanged(this, null);
                        radioBtnCircle.Checked = true;
                        break;
                    case SHAPE_TYPE.ELLIPSE:
                        radioBtnEllipse_CheckedChanged(this, null);
                        radioBtnEllipse.Checked = true;
                        break;
                    case SHAPE_TYPE.RECTANGLE:
                        radioBtnRectangle_CheckedChanged(this, null);
                        break;
                    case SHAPE_TYPE.SQUER:
                        radioBtnSqure_CheckedChanged(this, null);
                        radioBtnSqure.Checked = true;
                        break;
                    default:
                        break;
                }
            }
        }

        public void PostMessage(PostData postData)
        {
            _ReceivedMessage = postData.Message;
        }

        #endregion

        private void timer1_Tick(object sender, System.EventArgs e)
        {
            if (null != _shape)
            {
                _shape.Draw();

                drawingPanel.Invalidate();
                drawingPanel.Update();
            }
            toolStripStatusLabel.Text = _ReceivedMessage;
        }

        private void btnStart_Click(object sender, System.EventArgs e)
        {
            this.timer1.Enabled = true;
            btnStart.Enabled = false;
            btnStop.Enabled = true;
        }

        private void btnStop_Click(object sender, System.EventArgs e)
        {
            this.timer1.Enabled = false;
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        private void drawingPanel_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            if (null == _shape)
            {
                return;
            }

            drawingPanel.BackgroundImage = this._shape.Map;
        }

        private void radioBtnCircle_CheckedChanged(object sender, System.EventArgs e)
        {
            _shapeType = SHAPE_TYPE.CIRCLE;
            _shape = this._ClassFactory();
        }

        private void radioBtnEllipse_CheckedChanged(object sender, System.EventArgs e)
        {
            _shapeType = SHAPE_TYPE.ELLIPSE;
            _shape = this._ClassFactory();
        }

        private void radioBtnSqure_CheckedChanged(object sender, System.EventArgs e)
        {
            _shapeType = SHAPE_TYPE.SQUER;
            _shape = this._ClassFactory();
        }

        private void radioBtnRectangle_CheckedChanged(object sender, System.EventArgs e)
        {
            _shapeType = SHAPE_TYPE.RECTANGLE;
            _shape = this._ClassFactory();
        }

        private IShape _ClassFactory()
        {
            string assemblyName = "SoftnetSolutions.Shape";
            string className = string.Format("{0}.{1}",
                                               assemblyName,
                                               SHAPE_NAME[(int)this._shapeType]);
            Assembly assembly = Assembly.Load(assemblyName);
            Type classType = assembly.GetType(className);
            IShape shapeClass = (IShape)Activator.CreateInstance(classType, new object[] { this.drawingPanel });

            return shapeClass;
        }
    }
}
