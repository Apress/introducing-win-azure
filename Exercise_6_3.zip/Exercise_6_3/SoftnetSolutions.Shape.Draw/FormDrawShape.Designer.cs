﻿namespace SoftnetSolutions.Shape.Draw
{
    partial class FormDrawShape
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDrawShape));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.drawingPanel = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioBtnRectangle = new System.Windows.Forms.RadioButton();
            this.radioBtnEllipse = new System.Windows.Forms.RadioButton();
            this.radioBtnSqure = new System.Windows.Forms.RadioButton();
            this.radioBtnCircle = new System.Windows.Forms.RadioButton();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // drawingPanel
            // 
            this.drawingPanel.BackColor = System.Drawing.Color.Black;
            this.drawingPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.drawingPanel.Location = new System.Drawing.Point(4, 1);
            this.drawingPanel.Name = "drawingPanel";
            this.drawingPanel.Size = new System.Drawing.Size(345, 232);
            this.drawingPanel.TabIndex = 4;
            this.drawingPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.drawingPanel_Paint);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioBtnRectangle);
            this.groupBox1.Controls.Add(this.radioBtnEllipse);
            this.groupBox1.Controls.Add(this.radioBtnSqure);
            this.groupBox1.Controls.Add(this.radioBtnCircle);
            this.groupBox1.Controls.Add(this.btnStart);
            this.groupBox1.Controls.Add(this.btnStop);
            this.groupBox1.Location = new System.Drawing.Point(4, 239);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(345, 80);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // radioBtnRectangle
            // 
            this.radioBtnRectangle.Location = new System.Drawing.Point(119, 46);
            this.radioBtnRectangle.Name = "radioBtnRectangle";
            this.radioBtnRectangle.Size = new System.Drawing.Size(84, 16);
            this.radioBtnRectangle.TabIndex = 5;
            this.radioBtnRectangle.Text = "Rectangle";
            this.radioBtnRectangle.Click += new System.EventHandler(this.radioBtnRectangle_CheckedChanged);
            // 
            // radioBtnEllipse
            // 
            this.radioBtnEllipse.Location = new System.Drawing.Point(35, 46);
            this.radioBtnEllipse.Name = "radioBtnEllipse";
            this.radioBtnEllipse.Size = new System.Drawing.Size(56, 16);
            this.radioBtnEllipse.TabIndex = 4;
            this.radioBtnEllipse.Text = "Ellipse";
            this.radioBtnEllipse.Click += new System.EventHandler(this.radioBtnEllipse_CheckedChanged);
            // 
            // radioBtnSqure
            // 
            this.radioBtnSqure.Location = new System.Drawing.Point(119, 22);
            this.radioBtnSqure.Name = "radioBtnSqure";
            this.radioBtnSqure.Size = new System.Drawing.Size(56, 16);
            this.radioBtnSqure.TabIndex = 3;
            this.radioBtnSqure.Text = "Squre";
            this.radioBtnSqure.Click += new System.EventHandler(this.radioBtnSqure_CheckedChanged);
            // 
            // radioBtnCircle
            // 
            this.radioBtnCircle.Location = new System.Drawing.Point(35, 22);
            this.radioBtnCircle.Name = "radioBtnCircle";
            this.radioBtnCircle.Size = new System.Drawing.Size(56, 16);
            this.radioBtnCircle.TabIndex = 2;
            this.radioBtnCircle.Text = "Circle";
            this.radioBtnCircle.Click += new System.EventHandler(this.radioBtnCircle_CheckedChanged);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(242, 16);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(67, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "St&art";
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Location = new System.Drawing.Point(242, 44);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(68, 23);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "St&op";
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 332);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(349, 22);
            this.statusStrip1.TabIndex = 7;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.BackColor = System.Drawing.Color.DimGray;
            this.toolStripStatusLabel.ForeColor = System.Drawing.Color.Yellow;
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(334, 17);
            this.toolStripStatusLabel.Spring = true;
            this.toolStripStatusLabel.Text = "Ready";
            this.toolStripStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FormDrawShape
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 354);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.drawingPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormDrawShape";
            this.Text = "Draw Shapes";
            this.groupBox1.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel drawingPanel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioBtnRectangle;
        private System.Windows.Forms.RadioButton radioBtnEllipse;
        private System.Windows.Forms.RadioButton radioBtnSqure;
        private System.Windows.Forms.RadioButton radioBtnCircle;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;


    }
}

