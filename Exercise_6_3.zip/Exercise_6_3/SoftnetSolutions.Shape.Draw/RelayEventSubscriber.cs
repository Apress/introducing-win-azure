﻿using System;
using System.ServiceModel;
using System.Windows.Forms;

namespace SoftnetSolutions.RelayService.PublishChannel//SoftnetSolutions.Shape.Draw
{
    //using SoftnetSolutions.RelayService.PublishChannel;
    using SoftnetSolutions.Shape.Draw;
    //[ServiceBehavior(Namespace = "http://SoftnetSolutions.RelayService/",
    //                InstanceContextMode = InstanceContextMode.Single)]
    public class RelayEventSubscriber : ClientBase<IPublishEventService>, IPublishEventService
    {
        //FormDrawShape _subscriber = Application.OpenForms[0] as FormDrawShape;

        public void OnShapeSelectChanged(PostData postData)
        {
            //_subscriber.OnShapeSelectChanged(postData);
        }

        public void PostMessage(PostData postData)
        {
            //_subscriber.PostMessage(postData);
        }

        public void OnSubscrib(PostData shapeData)
        {
        }
    }
}
