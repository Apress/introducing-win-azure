﻿namespace SoftnetSolutions.RelayService.ShapeController
{
    partial class FormController
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                _hybridPublishService.ClientChannel.Dispose();
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormController));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnEcllipse = new System.Windows.Forms.Button();
            this.btnRectangle = new System.Windows.Forms.Button();
            this.btnSqure = new System.Windows.Forms.Button();
            this.btnCircle = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.textBoxConnectinStatus = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnEcllipse);
            this.groupBox1.Controls.Add(this.btnRectangle);
            this.groupBox1.Controls.Add(this.btnSqure);
            this.groupBox1.Controls.Add(this.btnCircle);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(111, 233);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // btnEcllipse
            // 
            this.btnEcllipse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEcllipse.Image = ((System.Drawing.Image)(resources.GetObject("btnEcllipse.Image")));
            this.btnEcllipse.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEcllipse.Location = new System.Drawing.Point(9, 181);
            this.btnEcllipse.Name = "btnEcllipse";
            this.btnEcllipse.Size = new System.Drawing.Size(93, 41);
            this.btnEcllipse.TabIndex = 3;
            this.btnEcllipse.Text = "&Ecllipse";
            this.btnEcllipse.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEcllipse.UseVisualStyleBackColor = true;
            this.btnEcllipse.Click += new System.EventHandler(this.btnEcllipse_Click);
            // 
            // btnRectangle
            // 
            this.btnRectangle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRectangle.Image = ((System.Drawing.Image)(resources.GetObject("btnRectangle.Image")));
            this.btnRectangle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRectangle.Location = new System.Drawing.Point(9, 75);
            this.btnRectangle.Name = "btnRectangle";
            this.btnRectangle.Size = new System.Drawing.Size(93, 41);
            this.btnRectangle.TabIndex = 2;
            this.btnRectangle.Text = "&Rect";
            this.btnRectangle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRectangle.UseVisualStyleBackColor = true;
            this.btnRectangle.Click += new System.EventHandler(this.btnRectangle_Click);
            // 
            // btnSqure
            // 
            this.btnSqure.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSqure.Image = ((System.Drawing.Image)(resources.GetObject("btnSqure.Image")));
            this.btnSqure.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSqure.Location = new System.Drawing.Point(9, 128);
            this.btnSqure.Name = "btnSqure";
            this.btnSqure.Size = new System.Drawing.Size(93, 41);
            this.btnSqure.TabIndex = 1;
            this.btnSqure.Text = "&Squre";
            this.btnSqure.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSqure.UseVisualStyleBackColor = true;
            this.btnSqure.Click += new System.EventHandler(this.btnSqure_Click);
            // 
            // btnCircle
            // 
            this.btnCircle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCircle.Image = ((System.Drawing.Image)(resources.GetObject("btnCircle.Image")));
            this.btnCircle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCircle.Location = new System.Drawing.Point(9, 19);
            this.btnCircle.Name = "btnCircle";
            this.btnCircle.Size = new System.Drawing.Size(93, 41);
            this.btnCircle.TabIndex = 0;
            this.btnCircle.Text = "&Circle";
            this.btnCircle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCircle.UseVisualStyleBackColor = true;
            this.btnCircle.Click += new System.EventHandler(this.btnCircle_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // textBoxConnectinStatus
            // 
            this.textBoxConnectinStatus.BackColor = System.Drawing.Color.Black;
            this.textBoxConnectinStatus.ForeColor = System.Drawing.Color.White;
            this.textBoxConnectinStatus.Location = new System.Drawing.Point(12, 262);
            this.textBoxConnectinStatus.Name = "textBoxConnectinStatus";
            this.textBoxConnectinStatus.Size = new System.Drawing.Size(92, 20);
            this.textBoxConnectinStatus.TabIndex = 5;
            this.textBoxConnectinStatus.Text = "Disconnected";
            this.textBoxConnectinStatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(10, 246);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Connection Status";
            // 
            // FormController
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(119, 291);
            this.Controls.Add(this.textBoxConnectinStatus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormController";
            this.Text = "Shap Controller";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnEcllipse;
        private System.Windows.Forms.Button btnRectangle;
        private System.Windows.Forms.Button btnSqure;
        private System.Windows.Forms.Button btnCircle;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textBoxConnectinStatus;
        private System.Windows.Forms.Label label1;
    }
}