﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using Microsoft.ServiceBus;

namespace SoftnetSolutions.RelayService.ShapeController
{
    using SoftnetSolutions.RelayService.ServiceContract;
    using SoftnetSolutions.Shape;
    using SoftnetSolutions.Shape.Draw;

    public partial class FormController : Form
    {
        private IPublishEventService _publishEventService = null;
        private HybridPublishService _hybridPublishService = null;
        private string _connectionStatus = "Disconnected";

        public FormController()
        {
            InitializeComponent();
        }

        public FormController(IPublishEventService publishEventService)
        {
            InitializeComponent();

            _publishEventService = publishEventService;
            string endpoint = "RelayEndpoint";
            _hybridPublishService = new HybridPublishService(endpoint);

            IHybridConnectionStatus hybridConnectionStatus = _hybridPublishService.ClientChannel.GetProperty<IHybridConnectionStatus>();
            _connectionStatus = hybridConnectionStatus.ConnectionState.ToString();

            hybridConnectionStatus.ConnectionStateChanged += new EventHandler<HybridConnectionStateChangedArgs>(hybridConnectionStatus_ConnectionStateChanged);

            (_publishEventService as FormDrawShape).Show();
        }

        private void btnCircle_Click(object sender, EventArgs e)
        {
            PostData shapeData = new PostData();
            shapeData.shape = SHAPE_TYPE.CIRCLE;
            _publishEventService.OnShapeSelectChanged(shapeData);
            _PostMessage(SHAPE_TYPE.CIRCLE);
        }

        private void btnRectangle_Click(object sender, EventArgs e)
        {
            PostData shapeData = new PostData();
            shapeData.shape = SHAPE_TYPE.RECTANGLE;
            _publishEventService.OnShapeSelectChanged(shapeData);
            _PostMessage(SHAPE_TYPE.RECTANGLE);
        }

        private void btnSqure_Click(object sender, EventArgs e)
        {
            PostData shapeData = new PostData();
            shapeData.shape = SHAPE_TYPE.SQUER;
            _publishEventService.OnShapeSelectChanged(shapeData);
            _PostMessage(SHAPE_TYPE.SQUER);
        }

        private void btnEcllipse_Click(object sender, EventArgs e)
        {
            PostData shapeData = new PostData();
            shapeData.shape = SHAPE_TYPE.ELLIPSE;
            _publishEventService.OnShapeSelectChanged(shapeData);
            _PostMessage(SHAPE_TYPE.ELLIPSE);
        }

        private void hybridConnectionStatus_ConnectionStateChanged(object sender, HybridConnectionStateChangedArgs args)
        {
            System.Diagnostics.Trace.WriteLine(string.Format("---Connection has bee switch from relay to direct connection ---{0}", Environment.NewLine));
            _connectionStatus = args.ConnectionState.ToString();
        }

        private void _PostMessage(SHAPE_TYPE shapeType)
        {
            PostData postData = new PostData();
            postData.shape = shapeType;
            postData.Message = string.Format("[{0}]:Shape Controller select <{1}>", DateTime.Now.ToString(), postData.shape);
            (_hybridPublishService.ClientChannel as IPublishEventService).PostMessage(postData);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            textBoxConnectinStatus.Text = _connectionStatus;

            switch (_connectionStatus)
            {
                case "Relayed":
                    textBoxConnectinStatus.ForeColor = Color.Red;
                    break;
                case "Direct":
                    textBoxConnectinStatus.ForeColor = Color.Lime;
                    break;

            }
        }

    }
}
