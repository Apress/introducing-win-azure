﻿using System;
using System.ServiceModel;
using Microsoft.ServiceBus;
using System.Text;
using System.Configuration;
using System.Windows.Forms;
using System.Threading;

namespace SoftnetSolutions.RelayService.ShapeController
{
    using SoftnetSolutions.RelayService.ServiceContract;
    using SoftnetSolutions.Shape.Draw;

    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            IPublishEventService service = new FormDrawShape();
            Thread workerThread = new Thread(new ParameterizedThreadStart(Program._StartService));
            workerThread.Start(service);
            workerThread.Join();

            Thread.Sleep(2000);

            FormController controller = new FormController(service);
            Application.Run(controller);
        }

        static public void _StartService(object service)
        {
            RelayPublishServiceHost<IPublishEventService> host = new RelayPublishServiceHost<IPublishEventService>(service as IPublishEventService);
        }
    }
}
