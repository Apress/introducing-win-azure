using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using Microsoft.ServiceBus;
using System.Text;
using System.Configuration;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    using SoftnetSolutions.RelayService.ServiceContract;

    class Program
    {
        static void Main(string[] args)
        {
            IPublishEventService service = new PublishEventService();
            RelayPublishServiceHost<IPublishEventService> host = new RelayPublishServiceHost<IPublishEventService>(service);

            Console.WriteLine(string.Format("---Press <Enter> to exit receiving----{0}", Environment.NewLine));
            Console.ReadLine();

            host.Host.Close();

        }
    }
}