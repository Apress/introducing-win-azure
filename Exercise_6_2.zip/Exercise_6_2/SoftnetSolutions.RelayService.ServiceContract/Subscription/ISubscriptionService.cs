﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    [ServiceContract]
    public interface ISubscriptionService
    {
        [OperationContract]
        void Subscribe(string eventOperation);

        [OperationContract]
        void Unsubscribe(string eventOperation);
    }

    [ServiceContract(CallbackContract = typeof(IPublishEventService))]
    public interface IEventPublishSubscription : ISubscriptionService
    { 
    }

    public partial class EventPublishSubscriptionClient : DuplexClientBase<IEventPublishSubscription>, IEventPublishSubscription
    {
        public EventPublishSubscriptionClient(InstanceContext inputInstance)
            : base(inputInstance)
        { }
        public void Subscribe(string eventOperation)
        {
            Channel.Subscribe(eventOperation);
        }
        public void Unsubscribe(string eventOperation)
        {
            Channel.Unsubscribe(eventOperation);
        }
    }
}
