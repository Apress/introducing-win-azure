using System;
using System.ServiceModel;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    [ServiceContract(Name = "IPublishEventService", 
        Namespace = "http://SoftnetSolutions.RelayService/")]
    public interface IPublishEventService
    {
        [OperationContract(IsOneWay = true)]
        void PostMessage(PostData postData);
    }

    public interface IPublishEventServiceChannel : IPublishEventService, IClientChannel { }
}
