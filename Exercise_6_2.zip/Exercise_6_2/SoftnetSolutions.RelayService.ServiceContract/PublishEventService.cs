using System;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    [ServiceBehavior(Name = "PublishEventService",
        Namespace = "http://SoftnetSolutions.RelayService/",
        InstanceContextMode = InstanceContextMode.Single)]
    public class PublishEventService : IPublishEventService
    {
        public void PostMessage(PostData postData)
        {
            Console.WriteLine(string.Format("---Host received message: <{0}>", postData.Message));
        }
    }

    [DataContract]
    public class PostData
    {
        [DataMember]
        public string Message;
    }
}
