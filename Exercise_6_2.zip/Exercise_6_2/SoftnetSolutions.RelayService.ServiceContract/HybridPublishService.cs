﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using Microsoft.ServiceBus;
using System.Text;
using System.Configuration;

namespace SoftnetSolutions.RelayService.ServiceContract
{
    public class HybridPublishService
    {
        public IPublishEventServiceChannel ClientChannel { get; set; }

        private ChannelFactory<IPublishEventServiceChannel> _channelFactory = null;

        public HybridPublishService(string endpoint)
        {
            string subject = ConfigurationManager.AppSettings["Topic"];
            string solutionName = ConfigurationManager.AppSettings["Solution"];
            string password = ConfigurationManager.AppSettings["password"];

            TransportClientEndpointBehavior relayCredentials = new TransportClientEndpointBehavior();
            relayCredentials.CredentialType = TransportClientCredentialType.UserNamePassword;
            relayCredentials.Credentials.UserName.UserName = solutionName;
            relayCredentials.Credentials.UserName.Password = password;

            Uri serviceUri = ServiceBusEnvironment.CreateServiceUri("sb",
                                                                    solutionName,
                                                                    subject);
            _channelFactory = new ChannelFactory<IPublishEventServiceChannel>(endpoint, new EndpointAddress(serviceUri));
            _channelFactory.Endpoint.Behaviors.Add(relayCredentials);
            ClientChannel = _channelFactory.CreateChannel();
            ClientChannel.Open();
        }

        public void Dispose()
        {
            ClientChannel.Close();
            _channelFactory.Close();
        }
    }

}