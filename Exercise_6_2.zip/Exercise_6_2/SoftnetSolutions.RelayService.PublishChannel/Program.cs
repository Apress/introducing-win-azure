﻿using System;
using System.ServiceModel;
using Microsoft.ServiceBus;
using System.Text;
using System.Configuration;

namespace SoftnetSolutions.RelayService.PublishChannel
{
    using SoftnetSolutions.RelayService.ServiceContract;

    class Program
    {
        static void Main(string[] args)
        {

            PublishEventService service = new PublishEventService();
            string endpoint = "RelayEndpoint";
            HybridPublishService hybridPublishService = new HybridPublishService(endpoint);
            Console.WriteLine(string.Format("---Relay connection has been established ----{0}", Environment.NewLine));

            IHybridConnectionStatus hybridConnectionStatus = hybridPublishService.ClientChannel.GetProperty<IHybridConnectionStatus>();
            hybridConnectionStatus.ConnectionStateChanged += new EventHandler<HybridConnectionStateChangedArgs>(hybridConnectionStatus_ConnectionStateChanged);
            Console.WriteLine(string.Format("---Press <Enter> to exit publishing----{0}", Environment.NewLine));

            string input = Console.ReadLine();
            while (input != String.Empty)
            {

                PostData postData = new PostData();
                postData.Message = string.Format("[{0}]:{1}", DateTime.Now.ToString(), input);
                (hybridPublishService.ClientChannel as IPublishEventService).PostMessage(postData);

                input = Console.ReadLine();
            }

            hybridPublishService.ClientChannel.Dispose();
        }

        static private void hybridConnectionStatus_ConnectionStateChanged(object sender, HybridConnectionStateChangedArgs args)
        {
            Console.WriteLine(string.Format("---Connection has bee switch from relay to direct connection ---{0}", Environment.NewLine));
        }
    }
}
