﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Services.Client;
using System.Configuration;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace CreateDataStorage.Models.CloudDataContext
{
    using CreateDataStorage.Models.CloudData;
    using CreateDataStorage.Models.CloudDataServices;

    public class UserDataContext : TableServiceContext
    {
        public DataServiceQuery<Address> AddressTable
        {
            get
            {
                return CreateQuery<Address>(ConfigurationManager.AppSettings["AddressTable"]);
            }
        }

        public UserDataContext(string baseAddress, StorageCredentials credentials)
            : base(baseAddress, credentials)
        {
        }
    }
}
