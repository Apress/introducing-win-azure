﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace CreateDataStorage.Models.CloudDataServices
{
    using CreateDataStorage.Models.CloudData;

    public class AddressTableService : DataTableService, INoDependcyTableService
    {
        public AddressTableService()
        {
            _Table = ConfigurationManager.AppSettings["AddressTable"];
        }
    }
}
