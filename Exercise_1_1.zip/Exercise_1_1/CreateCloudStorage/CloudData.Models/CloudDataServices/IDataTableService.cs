﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreateDataStorage.Models.CloudDataServices
{
    using Microsoft.WindowsAzure.StorageClient;

    public interface IDataTableService
    {
        bool Insert(TableServiceEntity entity);
        bool Update(TableServiceEntity entity);
        bool Delete(TableServiceEntity entity);
    }

    public interface IHasDependcyTableService : IDataTableService
    {
        bool UpdateDependencyTable(TableServiceEntity entity);
    }

    public interface INoDependcyTableService : IDataTableService
    {
    }
}
