﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.WindowsAzure.StorageClient;

namespace CreateDataStorage.Models.CloudDataServices
{
    using CreateDataStorage.Models.CloudDataContext;

    abstract public class DataTableService
    {
        protected UserDataContext _userDataContext = null;
        protected string _Table { get; set; }

        public DataTableService()
        {
        }

        public UserDataContext DataContext() { return _userDataContext; }

        virtual public bool Insert(TableServiceEntity entity)
        {
            bool success = false;

            try
            {
                if (this is IHasDependcyTableService)
                {
                    (this as IHasDependcyTableService).UpdateDependencyTable(entity);
                }
                _userDataContext.AddObject(_Table, entity);
                _userDataContext.SaveChanges();
                success = true;
            }
            catch { }

            return success;
        }

        public bool Update(TableServiceEntity entity) 
        {
            bool success = false;

            try
            {
                if (Delete(entity))
                {
                    success = Insert(entity);
                }
            }
            catch { }

            return success;
        }

        virtual public bool Delete(TableServiceEntity entity)
        {
            bool success = false;

            try
            {
                if (this is IHasDependcyTableService)
                {
                    (this as IHasDependcyTableService).UpdateDependencyTable(entity);
                }
                _userDataContext.DeleteObject(entity);
                _userDataContext.SaveChanges();
                success = true;
            }
            catch { }

            return success;
        }
    }
}
