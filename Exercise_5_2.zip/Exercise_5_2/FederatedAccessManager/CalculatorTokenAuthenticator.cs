using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IdentityModel.Claims;
using System.IdentityModel.Policy;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;
using System.ServiceModel;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{

    class UserRegisterTokenAuthenticator : SamlSecurityTokenAuthenticator
    {
        IList<SecurityTokenAuthenticator> supportingAuthenticators;
        SamlSecurityTokenAuthenticator innerSamlSecurityTokenAuthenticator;
        String solutionName;

        public UserRegisterTokenAuthenticator(IList<SecurityTokenAuthenticator> supportingAuthenticators, String solutionName)
            : base(supportingAuthenticators)
        {
            this.supportingAuthenticators = new List<SecurityTokenAuthenticator>(supportingAuthenticators);
            this.innerSamlSecurityTokenAuthenticator = new SamlSecurityTokenAuthenticator(supportingAuthenticators);
            this.solutionName = solutionName;
        }

        public UserRegisterTokenAuthenticator(IList<SecurityTokenAuthenticator> supportingAuthenticators, TimeSpan maxClockSkew)
            : base(supportingAuthenticators, maxClockSkew)
        {
            this.supportingAuthenticators = new List<SecurityTokenAuthenticator>(supportingAuthenticators);
            this.innerSamlSecurityTokenAuthenticator = new SamlSecurityTokenAuthenticator(supportingAuthenticators, maxClockSkew);
        }

        protected override ReadOnlyCollection<IAuthorizationPolicy> ValidateTokenCore(SecurityToken token)
        {
            if (token == null)
            {
                throw new ArgumentNullException("token");
            }

            SamlSecurityToken samlToken = token as SamlSecurityToken;

            if (samlToken == null)
            {
                throw new SecurityTokenException("Not a SamlSecurityToken.");
            }

            if (!samlToken.Assertion.Issuer.Equals(String.Format("http://accesscontrol.windows.net/{0}", this.solutionName), StringComparison.OrdinalIgnoreCase))
            {
                throw new SecurityTokenException("Not expected issuer.");
            }

            return this.innerSamlSecurityTokenAuthenticator.ValidateToken(token);
        }
    }
}
