using System;
using System.IdentityModel.Selectors;
using System.ServiceModel.Description;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{

    public class UserRegisterServiceCredentials : ServiceCredentials
    {
        String solutionName;

        public UserRegisterServiceCredentials(String solutionName)
            : base()
        {
            this.solutionName = solutionName;
        }

        protected override ServiceCredentials CloneCore()
        {
            return new UserRegisterServiceCredentials(solutionName);
        }

        public override SecurityTokenManager CreateSecurityTokenManager()
        {
            return new UserRegisterSecurityTokenManager(this, solutionName);
        }
    }
}
