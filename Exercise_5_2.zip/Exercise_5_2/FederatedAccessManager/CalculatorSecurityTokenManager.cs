using System;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;
using System.ServiceModel.Security;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{

    public class UserRegisterSecurityTokenManager : ServiceCredentialsSecurityTokenManager
    {
        UserRegisterServiceCredentials UserRegisterServiceCredentials;
        String solutionName;

        public UserRegisterSecurityTokenManager(UserRegisterServiceCredentials UserRegisterServiceCredentials, String solutionName)
            : base(UserRegisterServiceCredentials)
        {
            this.UserRegisterServiceCredentials = UserRegisterServiceCredentials;
            this.solutionName = solutionName;
        }

        public override SecurityTokenAuthenticator CreateSecurityTokenAuthenticator(SecurityTokenRequirement tokenRequirement, out SecurityTokenResolver outOfBandTokenResolver)
        {
            if (tokenRequirement.TokenType.Equals("http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.1#SAMLV1.1", StringComparison.OrdinalIgnoreCase))
            {
                base.CreateSecurityTokenAuthenticator(tokenRequirement, out outOfBandTokenResolver);
                return new UserRegisterTokenAuthenticator(new SecurityTokenAuthenticator[] {
                    new X509SecurityTokenAuthenticator(X509CertificateValidator.None),
                    new RsaSecurityTokenAuthenticator()}, solutionName);
            }
            else
            {
                return base.CreateSecurityTokenAuthenticator(tokenRequirement, out outOfBandTokenResolver);
            }
        }
    }
}
