//---------------------------------------------------------------------------------
// Microsoft (R) .NET Services SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{
    using System;
    using System.Runtime.Serialization;
    using System.ServiceModel;
    using System.ServiceModel.Channels;

    // Define a service contract.
    [ServiceContract(Name = "Calculator", Namespace = "http://Microsoft.ServiceModel.Samples")]
    public interface ICalculator
    {
        [OperationContract(Action = "Add", ReplyAction = "AddResponse")]
        double Add(double n1, double n2);

        [OperationContract(Action = "Subtract", ReplyAction = "SubtractResponse")]
        double Subtract(double n1, double n2);

        [OperationContract(Action = "Multiply", ReplyAction = "MultiplyResponse")]
        double Multiply(double n1, double n2);

        [OperationContract(Action = "Divide", ReplyAction = "DivideResponse")]
        double Divide(double n1, double n2);
    }

    // Service class which implements the service contract.
    public class CalculatorService : ICalculator
    {
        public double Add(double n1, double n2)
        {
            //AccessControlHelper.DemandActionClaim("Calculator.Add");
            return n1 + n2;
        }

        public double Subtract(double n1, double n2)
        {
            //AccessControlHelper.DemandActionClaim("Calculator.Subtract");
            return n1 - n2;
        }

        public double Multiply(double n1, double n2)
        {
            //AccessControlHelper.DemandActionClaim("Calculator.Multiply");
            return n1 * n2;
        }

        public double Divide(double n1, double n2)
        {
            //AccessControlHelper.DemandActionClaim("Calculator.Divide");
            return n1 / n2;
        }
    }
}
