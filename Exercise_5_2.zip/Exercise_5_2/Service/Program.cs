using System;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(AzureForDotNetDeveloperWCFservice));

            // uncomment to use the Access Control Service
            //String solutionName = ReadSolutionName();
            //ServiceCredentials sc = host.Credentials;
            //X509Certificate2 cert = sc.ServiceCertificate.Certificate;
            //UserRegisterServiceCredentials serviceCredential = new UserRegisterServiceCredentials(solutionName);
            //serviceCredential.ServiceCertificate.Certificate = cert;
            //host.Description.Behaviors.Remove((typeof(ServiceCredentials)));
            //host.Description.Behaviors.Add(serviceCredential);

            host.Open();

            Console.WriteLine("UserRegister service is running.");
            Console.WriteLine("Press [Enter] to exit");
            Console.ReadLine();

            host.Close();
        }

        private static string ReadSolutionName()
        {
            Console.Write("Please enter your solution name: ");
            return Console.ReadLine();
        }

    }
}

