using System;
using System.Collections.Generic;
using System.IdentityModel.Claims;
using System.IdentityModel.Policy;
using System.ServiceModel;


namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{
    public class AccessControlHelper
    {
        public static void DemandActionClaim(string claimValue)
        {
            foreach (ClaimSet claimSet in OperationContext.Current.ServiceSecurityContext.AuthorizationContext.ClaimSets)
            {
                foreach (Claim claim in claimSet)
                {
                    if (AccessControlHelper.CheckClaim(claim.ClaimType, claim.Resource.ToString(), "http://docs.oasis-open.org/wsfed/authorization/200706/claims/action", claimValue))
                    {
                        if (AccessControlHelper.IsIssuedByIbn(claimSet))
                        {
                            return;
                        }
                    }
                }
            }

            throw new FaultException("Access denied.");
        }

        static bool IsIssuedByIbn(ClaimSet claimSet)
        {
            foreach (Claim claim in claimSet.Issuer)
            {
                if (AccessControlHelper.CheckClaim(claim.ClaimType, claim.Resource.ToString(), "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dns", "accesscontrol.windows.net"))
                {
                    return true;
                }
            }

            return false;
        }

        static bool CheckClaim(string claimType, string claimValue, string expectedClaimType, string expectedClaimValue)
        {
            if (StringComparer.OrdinalIgnoreCase.Equals(claimType, expectedClaimType) &&
                StringComparer.OrdinalIgnoreCase.Equals(claimValue, expectedClaimValue))
            {
                return true;
            }
            return false;
        }
    }
}
