using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Collections.Generic;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{

    class Program
    {
        static void Main(string[] args)
        {
            UserRegisterClient client = new UserRegisterClient();
            
            try
            {
                //List<object> userList = client.GetUserList();
                //Console.WriteLine(string.Format("--- Get register user list count = <{0}>", userList.Count));
                Console.WriteLine(string.Format("--- Ping server return = <{0}>", client.Ping()));
                //client.AddUser(null);
            }
            catch (Exception e)
            {
                DumpException(e);
            }

            //Closing the client gracefully closes the connection and cleans up resources   
            client.Close();

            Console.WriteLine();
            Console.WriteLine("Press <ENTER> to terminate client.");
            Console.ReadLine();
        }

        static void DumpException(Exception e)
        {
            Console.WriteLine(e.Message);
        }
    }
}
