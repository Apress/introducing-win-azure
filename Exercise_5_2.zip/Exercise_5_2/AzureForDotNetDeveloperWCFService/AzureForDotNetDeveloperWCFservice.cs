using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Collections.Generic;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{

    public class AzureForDotNetDeveloperWCFservice : IAzureForDotNetDeveloperWCFservice
    {
        private List<object> _userList = new List<object>();

        #region IUserRegisterService Members

        public string Ping()
        {
            return string.Format("--- I am here <{0}>", this.ToString());
        }

        public void AddUser(object user)
        {
            try
            {
                //TODO : Remove hard code
                User u = new User();
                u.FirstName = "Henry";
                u.LastName = "Li";
                u.Password = "Hello Azure WCF host";
                _userList.Add(u);
            }
            catch (Exception ex)
            {
            }
        }

        public List<object> GetUserList()
        {
            //TODO : Remove hard code
            AddUser(new User());

            return _userList;
        }

        #endregion
    }
}
