﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Collections.Generic;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{
    [ServiceContract(Name = "UserRegisterService", Namespace = "http://AzureForDotNetDeveloper.DotNetService.ServiceBus")]
    public interface IAzureForDotNetDeveloperWCFservice
    {
        [OperationContract(Action = "Ping", ReplyAction = "PingResponse")]
        string Ping();

        [OperationContract(Action = "AddUser", ReplyAction = "AddUserResponse")]
        void AddUser(object user);

        [OperationContract(Action = "GetUserList", ReplyAction = "GetUserListResponse")]
        List<object> GetUserList();
    }

    [DataContract]
    public class User
    {
        [DataMember]
        public string FirstName;

        [DataMember]
        public string LastName;

        [DataMember]
        public DateTime TimeRegistered;

        [DataMember]
        public string Password;
    }
}
