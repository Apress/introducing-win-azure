﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.IO;
using System.Text;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Windows.Media.Imaging;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace SilverlightMeshEnableAppSilverlight
{
    using Microsoft.LiveFX.Client;
    using Microsoft.LiveFX.ResourceModel;

    public partial class Page : UserControl
    {

        const string SNAPSHOT_FEED = "SnapshotDataFeed";
        const string SNAPSHOT_DATAENTRY = "SnapshotDataEntry";
        const string SNAPSHOT_MESH_OBJECT = "SnapshotDataObject";

        private MeshApplicationService _meshApp = null;
        private Mesh _mesh = null;
        private MeshObject _snapshotMeshObject = null;
        private DataEntry _snapshotDataEntry = null;
        private DataFeed _snapShotDataFeed = null;
        private Queue<MeshDevice> _mappingQueue = new Queue<MeshDevice>();
        private double _sliderValue = 100.0;

        public Page()
        {
            InitializeComponent();

            _meshApp = Application.Current.GetMeshApplicationService();
            _meshApp.LoadCompleted += new EventHandler(meshAppLoaded);
            _meshApp.LoadAsync(null);
        }

        #region Private Get Feed Properties

        private double _DataFeedValue
        {
            get
            {
                double dataFeedValue = 0.0;
                if (null != _snapShotDataFeed)
                {
                    double d = 0.0;

                    if (null != _snapShotDataFeed)
                    {
                        _snapShotDataFeed.LoadAsync(_snapShotDataFeed);
                    }

                    DataFeed snapShotDataFeed = _meshApp.DataFeeds.Entries.FirstOrDefault(f => f.Resource.Title == SNAPSHOT_FEED);
                    if (null != snapShotDataFeed)
                    {
                        foreach (DataEntry entry in snapShotDataFeed.DataEntries.Entries)
                        {
                            try
                            {
                                d = entry.Resource.GetUserData<double>();
                                break;
                            }
                            catch { }
                        }
                    }

                    if (d > 0.0)
                    {
                        dataFeedValue = d;
                    }
                }
                return dataFeedValue;
            }
        }

        private DataEntry _SnapshotDataEntry
        {
            get
            {
                DataEntry dataEntry = null;

                DataFeed dataFeed = _SnapshotDataFeed;
                if (null != dataFeed)
                {
                    dataEntry = dataFeed.DataEntries.Entries.FirstOrDefault(de => de.Resource.Type == SNAPSHOT_DATAENTRY);
                }

                return dataEntry;
            }
        }

        private DataFeed _SnapshotDataFeed
        {
            get
            {
                DataFeed dataFeed = null;

                MeshObject meshObject = _SnapshotMeshObject;
                if (null != meshObject)
                {
                    dataFeed = meshObject.DataFeeds.Entries.FirstOrDefault(df => df.Resource.Type == SNAPSHOT_FEED);
                }

                return dataFeed;
            }
        }

        private MeshObject _SnapshotMeshObject
        {
            get
            {
                MeshObject meshObject = null;

                if (null != _mesh)
                {
                    meshObject = _mesh.MeshObjects.Entries.FirstOrDefault(mo => mo.Resource.Type == SNAPSHOT_MESH_OBJECT);
                }

                return meshObject;
            }
        }

        #endregion

        private void meshAppLoaded(object sender, EventArgs e)
        {
            MeshApplicationService meshApp = Application.Current.GetMeshApplicationService();

            LiveOperatingEnvironment endpoint = meshApp.LiveOperatingEnvironment;

            _mesh = meshApp.LiveOperatingEnvironment.Mesh;

            _MappingDevices();

            _InitialSnapshotFeeds();
        }

        private void _StartUpdateTimer(object o, RoutedEventArgs sender)
        {
            System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
            dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 1);
            dispatcherTimer.Tick += new EventHandler(_timer_Tick);
            dispatcherTimer.Start();
        }

        private void _timer_Tick(object o, EventArgs sender)
        {
            if (null != _snapShotDataFeed)
            {
                double feedValue = _DataFeedValue;

                if (feedValue > 0.0)
                {
                    _sliderValue = feedValue;
                }

                _slider.Value = (int)_sliderValue;
                Buntton_Value.Height = (int)(_sliderValue * 1.5);
                Buntton_Value.Width = (int)(_sliderValue * 1.5);
                txtSliderValue.Text = ((int)_sliderValue).ToString();

                if (Button_RotateTransform.Angle >= 359)
                {
                    Button_RotateTransform.Angle = 0;
                }
                else
                {
                    Button_RotateTransform.Angle += 10;
                }
            }
        }

        private void _slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            _sliderValue = e.NewValue;
            if (null != _snapShotDataFeed)
            {
                Button_RotateTransform.CenterX = (int)(_sliderValue * 0.75);
                Button_RotateTransform.CenterY = (int)(_sliderValue * 0.75);
            }
        }

        private void txtMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (null == _snapShotDataFeed)
            {
                return;
            }

            if (e.Key == Key.Enter)
            {
                string s = txtMessage.Text.Trim();
                bool valid = false;

                if (null != s)
                {
                    if (string.Empty != s)
                    {
                        txtErrorMessage.Text = string.Empty;
                        if (_IsValidKeyStroke(s) )
                        {
                            try
                            {
                                double feedValue = double.Parse(s);
                                if (0.0 <= feedValue && feedValue <= 100.0)
                                {
                                    valid = true;
                                    _AddDataEntry(feedValue);
                                }
                            }
                            catch { }
                        }
                        if (!valid)
                        {
                            txtErrorMessage.Text = "* Expected Data Range: [0 - 100]";
                            txtMessage.Text = string.Empty;
                        }
                    }
                }
            }
        }
      
        private void txtMessage_TextChanged(object sender, TextChangedEventArgs e)
        {
        }

        #region Asynchronous Add DataFeeds

        private void _AddDataEntry(double feedValue)
        {
            DataFeed snapshotDataFeed = _meshApp.DataFeeds.Entries.FirstOrDefault(f => f.Resource.Title == SNAPSHOT_FEED);
            if (null != snapshotDataFeed)
            {
                //Add a new DataEntry
                DataEntryResource entryResource = new DataEntryResource();
                entryResource.Type = SNAPSHOT_DATAENTRY;
                _snapshotDataEntry = new DataEntry(entryResource);

                _snapshotDataEntry.Resource.SetUserData<double>(feedValue);

                //Add DataEntry to the DataEntries collection
                snapshotDataFeed.DataEntries.AddCompleted += new EventHandler<LiveItemEventArgs<DataEntry>>(DataEntries_AddCompleted);
                snapshotDataFeed.DataEntries.AddAsync(_snapshotDataEntry, snapshotDataFeed);
            }
        }

        private void DataEntries_AddCompleted(object o, AsyncCompletedEventArgs args)
        {
            _snapShotDataFeed.UpdateAsync(args.UserState);
        }

        #endregion

        private void _InitialSnapshotFeeds()
        {

            if (null != _mesh)
            {
                if (null != _snapshotMeshObject && null != _snapShotDataFeed)
                {
                    return;
                }

                try
                {
                    _snapShotDataFeed = _meshApp.DataFeeds.Entries.FirstOrDefault(f => f.Resource.Title == SNAPSHOT_FEED);
                    if (null == _snapShotDataFeed)
                    {
                        _snapShotDataFeed = new DataFeed(SNAPSHOT_FEED);
                        _snapShotDataFeed.Resource.Type = _snapShotDataFeed.Resource.Title = SNAPSHOT_FEED;
                        _meshApp.DataFeeds.AddCompleted += (s_0, e_0) =>
                        {
                            _meshApp.DataFeeds.LoadCompleted += (s_1, e_1) =>
                            {
                                _meshApp.DataFeeds.LoadCompleted += (s_2, e_2) =>
                                {
                                    _snapShotDataFeed = (DataFeed)e_2.UserState;
                                };
                                _meshApp.DataFeeds.LoadAsync(e_1.UserState);
                            };
                        };
                        _meshApp.DataFeeds.AddAsync(_snapShotDataFeed, _snapShotDataFeed);
                    }
                }
                catch { }
            }
        }

        private void _MappingDevices()
        {
            if (_mappingQueue.Count < 1)
            {
                return;
            }

            MeshDevice device = _mappingQueue.Dequeue();

            if (null != device)
            {
                Mapping mapping = new Mapping();
                mapping.Device = device;
                _meshApp.Mappings.AddCompleted += new EventHandler<LiveItemEventArgs<Mapping>>(Mappings_AddCompleted);
                _meshApp.Mappings.AddAsync(mapping, mapping);
            }
        }

        private void Mappings_AddCompleted(object o, LiveItemEventArgs<Mapping> args)
        {
            _meshApp.UpdateAsync(args.UserState);
            _MappingDevices();
        }

        private bool _IsValidKeyStroke(string key)
        {
            const string VALID_KEY_CHAR_PATTERN = @"([0-9])";
            bool isValid = false;
            Match match = null;

            Regex regEx = new Regex(VALID_KEY_CHAR_PATTERN,
                                        RegexOptions.CultureInvariant
                                        | RegexOptions.IgnorePatternWhitespace);

            match = regEx.Match(key.ToString());

            if (null != match && match.Success)
            {
                isValid = true;
            }

            return isValid;
        }
    }
}
