﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.ServiceModel.Web;
using ShoppingCartServiceLibrary;
using System.ServiceModel;

namespace ShoopingCartWorkflows
{
    using ShoppingCartServiceLibrary;

    public sealed partial class ShoppingCartItemWorkflow : StateMachineWorkflowActivity
    {
        public ShoppingCartItem receivedShoppingCartItem;
        public string receivedId;

        public ShoppingCartItem currentShoppingCartItem;
        public CreditCardPayment ShoppingCartItemCreditCardPayment;

        public ShoppingCartItemWorkflow()
        {
            InitializeComponent();
        }

        private void OnShoppingCartItemPlacedCode_ExecuteCode(object sender, EventArgs e)
        {
            var id = WorkflowEnvironment.WorkflowInstanceId.ToString();

            currentShoppingCartItem = new ShoppingCartItem();
            currentShoppingCartItem.ShoppingCartItemId = id;
            currentShoppingCartItem.Price = receivedShoppingCartItem.Price;
            currentShoppingCartItem.ItemName = receivedShoppingCartItem.ItemName;

            currentShoppingCartItem.NextItem = new NextItem[] {    new NextItem
	                                                    {
		                                                    Relateive = ShoppingCartItem.ENDPOINT_CREDITCARD_PAYMENT,
		                                                    Uri = string.Format("{0}{1}",
                                                                                ShoppingCartItem.CREDIT_CARD_PAYMENT_URI,
                                                                                WorkflowEnvironment.WorkflowInstanceId.ToString()),
	                                                    },
	                                                    new NextItem
	                                                    {
		                                                    Relateive = ShoppingCartItem.ENDPOINT_ITEM_UPDATE,
		                                                    Uri = string.Format("{0}{1}",
                                                                                ShoppingCartItem.SHOPPING_CART_URI,
                                                                                WorkflowEnvironment.WorkflowInstanceId.ToString())
	                                                    },
	                                                    new NextItem
	                                                    {
		                                                    Relateive = ShoppingCartItem.ENDPOINT_ITEM_DELETE,
		                                                    Uri = string.Format("{0}{1}",
                                                                                ShoppingCartItem.SHOPPING_CART_URI,
                                                                                WorkflowEnvironment.WorkflowInstanceId.ToString())
	                                                    }
                                                    };

            WebOperationContext.Current.OutgoingResponse.StatusCode = System.Net.HttpStatusCode.Created;
        }

        private void codeUpdateShoppingCartItem_ExecuteCode(object sender, EventArgs e)
        {
            var id = WorkflowEnvironment.WorkflowInstanceId.ToString();

            currentShoppingCartItem.ShoppingCartItemId = receivedId;
            currentShoppingCartItem.ItemName = receivedShoppingCartItem.ItemName;
            currentShoppingCartItem.Price = receivedShoppingCartItem.Price;
            currentShoppingCartItem.NextItem = new NextItem[] { 
                new NextItem
                {
                    Relateive = ShoppingCartItem.ENDPOINT_CREDITCARD_PAYMENT,
                    Uri = string.Format("{0}{1}",
                                        ShoppingCartItem.CREDIT_CARD_PAYMENT_URI,
                                        id.ToString()),
                },
				new NextItem
				{
					Relateive = ShoppingCartItem.ENDPOINT_ITEM_UPDATE,
					Uri = string.Format("{0}{1}",
                                        ShoppingCartItem.SHOPPING_CART_URI,
                                        id.ToString()),
				},
				new NextItem
				{
					Relateive = ShoppingCartItem.ENDPOINT_ITEM_DELETE,
					Uri = string.Format("{0}{1}",
                                        ShoppingCartItem.SHOPPING_CART_URI,
                                        id.ToString()),
				}
			};

            WebOperationContext.Current.OutgoingResponse.StatusCode = System.Net.HttpStatusCode.OK;
        }

        private void codePayShoppingCartItem_ExecuteCode(object sender, EventArgs e)
        {
            var id = WorkflowEnvironment.WorkflowInstanceId.ToString();

            currentShoppingCartItem.ShoppingCartItemId = receivedId;
            currentShoppingCartItem.ItemName = receivedShoppingCartItem.ItemName;
            currentShoppingCartItem.Price = receivedShoppingCartItem.Price;
            currentShoppingCartItem.NextItem = new NextItem[] { 
                new NextItem
                {
                    Relateive = ShoppingCartItem.ENDPOINT_CREDITCARD_PAYMENT,
                    Uri = string.Format("{0}{1}",
                                        ShoppingCartItem.CREDIT_CARD_PAYMENT_URI,
                                        id.ToString()),
                },
				new NextItem
				{
					Relateive = ShoppingCartItem.ENDPOINT_ITEM_UPDATE,
					Uri = string.Format("{0}{1}",
                                        ShoppingCartItem.SHOPPING_CART_URI,
                                        id.ToString()),
				},
				new NextItem
				{
					Relateive = ShoppingCartItem.ENDPOINT_ITEM_DELETE,
					Uri = string.Format("{0}{1}",
                                        ShoppingCartItem.SHOPPING_CART_URI,
                                        id.ToString()),
				}
			};
            WebOperationContext.Current.OutgoingResponse.StatusCode = System.Net.HttpStatusCode.Created;
        }

        private void codeCheckOutShoppingCartItem_ExecuteCode(object sender, EventArgs e)
        {
            WebOperationContext.Current.OutgoingResponse.StatusCode = System.Net.HttpStatusCode.Created;
        }
    }
}
