﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Web;
using System.Net;
using System.IO;

namespace ClientUnitestibrary
{
    using ShoppingCartServiceLibrary;

    public class InvokeWorkflows
    {
        public void HttWebRequestInvokeWorkflows()
        {
            //Create a new ShoppingCartItem
            ShoppingCartItem shoppingCartItem = new ShoppingCartItem
            {
                ItemName = "Nikon Camera",
                Price = (decimal)1000.0
            };

            HttpWebRequest createShoppingCartItemRequest = CreateRequest(new Uri("http://localhost:8000/ShoppingCartItem"), "POST", shoppingCartItem);
            shoppingCartItem = InvokeHttpWebRequest<ShoppingCartItem>(createShoppingCartItemRequest.GetResponse());

            Console.WriteLine("ShoppingCartItem Price {0}", shoppingCartItem.Price);
            foreach (NextItem NextItem in shoppingCartItem.NextItem)
            {
                Console.WriteLine("Check NextItem {0}", NextItem.Uri);
            }

            //Update
            shoppingCartItem.ItemName = "Dell latiture D620";
            shoppingCartItem.Price = (decimal)710.0;

            Uri updateShoppingCartItemUri = new Uri(shoppingCartItem.NextItem.Where(n => n.Relateive == ShoppingCartItem.ENDPOINT_ITEM_UPDATE).Single().Uri);
            HttpWebRequest updateShoppingCartItemRequest = CreateRequest(updateShoppingCartItemUri, "PUT", shoppingCartItem);
            ShoppingCartItem updatedShoppingCartItem = InvokeHttpWebRequest<ShoppingCartItem>(updateShoppingCartItemRequest.GetResponse());

            Console.WriteLine("ShoppingCartItem Price {0}", updatedShoppingCartItem.Price);
            foreach (NextItem NextItem in updatedShoppingCartItem.NextItem)
            {
                Console.WriteLine("Process NextItem {0}", NextItem.Uri);
            }

            //Pay
            CreditCardPayment CreditCardPayment = new CreditCardPayment
            {
                CardHolerName = "David Smith",
                CardNumber = "1234567",
                ExpiresDate = "10/10",
                ChargedAmount = updatedShoppingCartItem.Price.GetValueOrDefault()
            };

            Uri payShoppingCartItemUri = new Uri(shoppingCartItem.NextItem.Where(n => n.Relateive == ShoppingCartItem.ENDPOINT_CREDITCARD_PAYMENT).Single().Uri);
            HttpWebRequest payShoppingCartItemRequest = CreateRequest(payShoppingCartItemUri, "PUT", CreditCardPayment);

            int statusCode = Execute(payShoppingCartItemRequest.GetResponse());

            if (statusCode == 201)
                Console.WriteLine("Transaction success!");
            else
                Console.WriteLine("Failed to process the CreditCardPayment");

            //Checkout 
            Uri deleteShoppingCartItemUri = new Uri(shoppingCartItem.NextItem.Where(n => n.Relateive == ShoppingCartItem.ENDPOINT_ITEM_DELETE).Single().Uri);
            HttpWebRequest deletehoppingCartItemRequest = CreateRequest(deleteShoppingCartItemUri, "POST", shoppingCartItem);

            ShoppingCartItem deletedShoppingCartItem = InvokeHttpWebRequest<ShoppingCartItem>(deletehoppingCartItemRequest.GetResponse());
        }

        static HttpWebRequest CreateRequest(Uri address, string method, object contract)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(address);
            webRequest.ContentType = "application/xml";
            webRequest.Timeout = 20000;
            webRequest.Method = method;

            DataContractSerializer serializer = new DataContractSerializer(contract.GetType());
            using (Stream stream = webRequest.GetRequestStream())
            {
                serializer.WriteObject(stream, contract);
                stream.Flush();
            }

            return webRequest;
        }

        static T InvokeHttpWebRequest<T>(WebResponse response)
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(T));
            using (Stream stream = response.GetResponseStream())
            {
                return (T)serializer.ReadObject(stream);
            }
        }

        static int Execute(WebResponse response)
        {
            using (Stream stream = response.GetResponseStream()) { };
            return (int)((HttpWebResponse)response).StatusCode;
        }
    }
}
