﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ShoppingCartServiceLibrary
{
	[Serializable]
	[DataContract(Name = "CreditCardPayment", Namespace = "http://costco.com/OnlineShopping")]
	public class CreditCardPayment
	{
		public string ShoppingCartItemId { get; set; }

		[DataMember(Name = "CardNumber")]
		public string CardNumber { get; set; }

		[DataMember(Name = "ExpiresDate")]
		public string ExpiresDate { get; set; }

        [DataMember(Name = "CardHolerName")]
		public string CardHolerName { get; set; }

		[DataMember(Name = "amount")]
		public decimal ChargedAmount { get; set; }
	}
}
