﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;

namespace Microsoft.ServiceModel.Samples
{
	internal class WebHttpContextRequestContext : RequestContext
	{
		private ContextProtocol contextProtocol;
		private RequestContext innerContext;

		public WebHttpContextRequestContext(RequestContext innerContext, ContextProtocol contextProtocol)
		{
			this.innerContext = innerContext;
			this.contextProtocol = contextProtocol;
		}

		public override void Abort()
		{
			this.innerContext.Abort();
		}

		public override IAsyncResult BeginReply(Message message, AsyncCallback callback, object state)
		{
			if (message != null)
			{
				this.contextProtocol.OnOutgoingMessage(message, this);
			}
			return this.innerContext.BeginReply(message, callback, state);
		}

		public override IAsyncResult BeginReply(Message message, TimeSpan timeout, AsyncCallback callback, object state)
		{
			if (message != null)
			{
				this.contextProtocol.OnOutgoingMessage(message, this);
			}
			return this.innerContext.BeginReply(message, timeout, callback, state);
		}

		public override void Close()
		{
			this.innerContext.Close();
		}

		public override void Close(TimeSpan timeout)
		{
			this.innerContext.Close(timeout);
		}

		public override void EndReply(IAsyncResult result)
		{
			this.innerContext.EndReply(result);
		}

		public override void Reply(Message message)
		{
			if (message != null)
			{
				this.contextProtocol.OnOutgoingMessage(message, this);
			}
			this.innerContext.Reply(message);
		}

		public override void Reply(Message message, TimeSpan timeout)
		{
			if (message != null)
			{
				this.contextProtocol.OnOutgoingMessage(message, this);
			}
			this.innerContext.Reply(message, timeout);
		}

		public override Message RequestMessage
		{
			get
			{
				return this.innerContext.RequestMessage;
			}
		}
	}
}
