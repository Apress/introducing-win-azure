#region using

using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;
using System.Configuration;
using System.IO;
using System.Xml;

#endregion

namespace Microsoft.ServiceModel.Samples
{
    //This class implements binding element section to 
    //hook up this binding element to the configuration
    //system.
    public sealed class WebHttpContextBindingElementSection	 : BindingElementExtensionElement
    {
        ConfigurationPropertyCollection properties;

        public WebHttpContextBindingElementSection()
        {
        }

        public override void ApplyConfiguration(BindingElement bindingElement)
        {
            base.ApplyConfiguration(bindingElement);

            WebHttpContextBindingElement typedBindingElement =
                (WebHttpContextBindingElement)bindingElement;
        }

        public override Type BindingElementType
        {
            get { return typeof(WebHttpContextBindingElement); }
        }

        protected override BindingElement CreateBindingElement()
        {
            WebHttpContextBindingElement bindingElement =
                new WebHttpContextBindingElement(ContextMode.HttpHeader, null);

            ApplyConfiguration(bindingElement);

            return bindingElement;
        }
    }

}
