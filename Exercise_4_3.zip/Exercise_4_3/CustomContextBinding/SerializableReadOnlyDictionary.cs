﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Microsoft.ServiceModel.Samples
{
	[Serializable]
	internal class SerializableReadOnlyDictionary<K, V> : IDictionary<K, V>, ICollection<KeyValuePair<K, V>>, IEnumerable<KeyValuePair<K, V>>, IEnumerable
	{
		// Fields
		private IDictionary<K, V> dictionary;
		private static IDictionary<K, V> empty;

		// Methods
		public SerializableReadOnlyDictionary(IDictionary<K, V> dictionary)
			: this(dictionary, true)
		{
		}

		public SerializableReadOnlyDictionary(params KeyValuePair<K, V>[] entries)
		{
			this.dictionary = new Dictionary<K, V>(entries.Length);
			foreach (KeyValuePair<K, V> pair in entries)
			{
				this.dictionary.Add(pair);
			}
		}

		public SerializableReadOnlyDictionary(IDictionary<K, V> dictionary, bool makeCopy)
		{
			if (makeCopy)
			{
				this.dictionary = new Dictionary<K, V>(dictionary);
			}
			else
			{
				this.dictionary = dictionary;
			}
		}

		public void Add(KeyValuePair<K, V> item)
		{
			throw new Exception();
		}

		public void Add(K key, V value)
		{
			throw new Exception();
		}

		public void Clear()
		{
			throw new Exception();
		}

		public bool Contains(KeyValuePair<K, V> item)
		{
			return this.dictionary.Contains(item);
		}

		public bool ContainsKey(K key)
		{
			return this.dictionary.ContainsKey(key);
		}

		public void CopyTo(KeyValuePair<K, V>[] array, int arrayIndex)
		{
			this.dictionary.CopyTo(array, arrayIndex);
		}

		public IEnumerator<KeyValuePair<K, V>> GetEnumerator()
		{
			return this.dictionary.GetEnumerator();
		}

		public bool Remove(KeyValuePair<K, V> item)
		{
			throw new Exception();
		}

		public bool Remove(K key)
		{
			throw new Exception();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		public bool TryGetValue(K key, out V value)
		{
			return this.dictionary.TryGetValue(key, out value);
		}

		// Properties
		public int Count
		{
			get
			{
				return this.dictionary.Count;
			}
		}

		public static IDictionary<K, V> Empty
		{
			get
			{
				if (SerializableReadOnlyDictionary<K, V>.empty == null)
				{
					SerializableReadOnlyDictionary<K, V>.empty = new SerializableReadOnlyDictionary<K, V>(new Dictionary<K, V>(0), false);
				}
				return SerializableReadOnlyDictionary<K, V>.empty;
			}
		}

		public bool IsReadOnly
		{
			get
			{
				return true;
			}
		}

		public V this[K key]
		{
			get
			{
				return this.dictionary[key];
			}
			set
			{
				throw new Exception();
			}
		}

		public ICollection<K> Keys
		{
			get
			{
				return this.dictionary.Keys;
			}
		}

		public ICollection<V> Values
		{
			get
			{
				return this.dictionary.Values;
			}
		}
	}


}
