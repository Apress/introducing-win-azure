﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace ShoppingCarServiceHost
{
    using Microsoft.ServiceBus;
    using CloudWorkflowServiceLibrary;

    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(ShoppingCarService));

            ServiceEndpoint endpoint = host.AddServiceEndpoint("CloudWorkflowServiceLibrary.IShoppingCarService",
                                                         new NetEventRelayBinding(),
                                                         "sb://servicebus.windows.net/services/SoftnetSolutions_113/ShoppingCar");
            TransportClientEndpointBehavior transportEndpointBehavior = new TransportClientEndpointBehavior();
            transportEndpointBehavior.CredentialType = TransportClientCredentialType.SharedSecret;// UserNamePassword;
            transportEndpointBehavior.Credentials.SharedSecret.IssuerName = "";//UserName.UserName = ;
            transportEndpointBehavior.Credentials.SharedSecret.IssuerSecret = ""; //UserName.Password = "";

            endpoint.Behaviors.Add(transportEndpointBehavior);

            try
            {
                host.Open();
                Console.WriteLine("Host is running");
                Console.ReadLine();
                host.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("---ShoppingCarServiceHost:Main, exception caught{0}", ex.Message));
            }
        }
    }
}
