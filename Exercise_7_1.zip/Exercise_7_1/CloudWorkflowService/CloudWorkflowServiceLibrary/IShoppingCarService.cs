﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace CloudWorkflowServiceLibrary
{
    [ServiceContract]
    public interface IShoppingCarService
    {
        //[OperationContract]
        //void AddShoppingCarItem(ShoppingCarItem shoppingCarItem);

        //[OperationContract]
        //List<ShoppingCarItem> GetShoppingCarItemList();

        [OperationContract(IsOneWay = true)]
        void Ping();
    }

    [DataContract]
    public class ShoppingCarItem
    {
        [DataMember]
        public string SKU;

        [DataMember]
        public string ProductName;

        [DataMember]
        public DateTime AddTime;

        [DataMember]
        public int ItemCount;
    }
}
