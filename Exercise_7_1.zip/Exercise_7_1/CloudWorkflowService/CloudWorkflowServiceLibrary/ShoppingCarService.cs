﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Diagnostics;

namespace CloudWorkflowServiceLibrary
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class ShoppingCarService : IShoppingCarService
    {
        List<ShoppingCarItem> shoppingCarItemList = new List<ShoppingCarItem>();

        #region IShoppingCarService Members

        public void AddShoppingCarItem(ShoppingCarItem shoppingCarItem)
        {
            shoppingCarItemList.Add(shoppingCarItem);
        }

        public List<ShoppingCarItem> GetShoppingCarItemList()
        {
            return shoppingCarItemList;
        }

        public void Ping()
        {
            string message = string.Format("---{0}:Ping, {1}", DateTime.Now.ToString(), this.ToString());
            Trace.WriteLine(message);
            Console.WriteLine(message);
        }

        #endregion
    }
}
