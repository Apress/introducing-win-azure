﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{
    [ServiceContract(Name = "UserRegisterService", Namespace = "http://AzureForDotNetDeveloper.DotNetService.ServiceBus")]
    public interface IAzureForDotNetDeveloperWCFservice
    {
        [OperationContract(Action = "Ping", ReplyAction = "PingResponse")]
        string Ping();

        [OperationContract(Action = "RegisterUser", ReplyAction = "AddUserResponse")]
        void RegisterUser(string xmlString);

        [OperationContract(Action = "GetRegisteredUser", ReplyAction = "GetUserListResponse")]
        string GetRegisteredUser();
    }

    [DataContract]
    public class User
    {
        [DataMember]
        public string FirstName;

        [DataMember]
        public string LastName;

        [DataMember]
        public DateTime TimeRegistered;

        [DataMember]
        public string Password;
    }
}
