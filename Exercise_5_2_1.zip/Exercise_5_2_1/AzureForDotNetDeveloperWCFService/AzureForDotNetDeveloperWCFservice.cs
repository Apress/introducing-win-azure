using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Text;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{

    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class AzureForDotNetDeveloperWCFservice : IAzureForDotNetDeveloperWCFservice
    {
        private User _registeredUser = null;

        #region IUserRegisterService Members

        public string Ping()
        {
            return string.Format("--- I am here <{0}>", this.ToString());
        }

        public void RegisterUser(string xmlString)
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(xmlString);
                XmlSerializer serializer = new XmlSerializer(typeof(User));
                StringReader reader = new StringReader(xmlString);

                _registeredUser = (User)serializer.Deserialize(reader);
            }
            catch (Exception ex)
            {
            }
        }

        public string GetRegisteredUser()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(User));
            StringBuilder sb = new StringBuilder();
            StringWriter writer = new StringWriter(sb);

            serializer.Serialize(writer, _registeredUser);
            return writer.GetStringBuilder().ToString();
        }

        #endregion
    }
}
