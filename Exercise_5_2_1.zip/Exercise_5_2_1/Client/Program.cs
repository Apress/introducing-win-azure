using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Text;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{
    using AzureForDotNetDeveloper.DotNetService.ServiceBus.UserRegisterServiceClient;

    class Program
    {
        static void Main(string[] args)
        {
            UserRegisterServiceClient.UserRegisterServiceClient client = new UserRegisterServiceClient.UserRegisterServiceClient();

            try
            {
                Console.WriteLine(string.Format("--- Ping server return = <{0}>{1}",
                    client.Ping(),
                    Environment.NewLine));

                User user = new User();
                user.FirstName = "Henry";
                user.LastName = "Li";
                user.Password = "Hello Azure WCF host";
                user.TimeRegistered = DateTime.Now;
                XmlSerializer serializer = new XmlSerializer(user.GetType());
                StringBuilder sb = new StringBuilder();
                StringWriter writer = new StringWriter(sb);

                serializer.Serialize(writer, user);
                client.RegisterUser(writer.GetStringBuilder().ToString());

                string xmlString = client.GetRegisteredUser();
                XmlSerializer deSerializer = new XmlSerializer(typeof(User));
                StringReader stringReader = new StringReader(xmlString);

                User registeredUser = (User)serializer.Deserialize(stringReader);
                Console.WriteLine(string.Format("--- User <{0} {1}> register secces @[{2}].{3}",
                                registeredUser.FirstName,
                                registeredUser.LastName,
                                registeredUser.TimeRegistered.ToString(),
                                Environment.NewLine));

            }
            catch (Exception e)
            {
                DumpException(e);
            }

            client.Close();

            Console.WriteLine();
            Console.WriteLine("Press <ENTER> to exit client.");
            Console.ReadLine();
        }

        static void DumpException(Exception e)
        {
            Console.WriteLine(e.Message);
        }
    }
}
