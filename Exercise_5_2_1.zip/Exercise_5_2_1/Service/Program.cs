using System;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace AzureForDotNetDeveloper.DotNetService.ServiceBus
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(AzureForDotNetDeveloperWCFservice));
            host.Open();

            Console.WriteLine("---UserRegister service is running.");
            Console.WriteLine("---Press <Enter> to terminate server");
            Console.ReadLine();

            host.Close();
        }

        private static string ReadSolutionName()
        {
            Console.Write(string.Format("---Please enter your solution name: {0}", Environment.NewLine));
            return Console.ReadLine();
        }

    }
}

