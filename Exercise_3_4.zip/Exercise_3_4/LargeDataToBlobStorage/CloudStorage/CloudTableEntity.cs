﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Net.Mime;
using System.Configuration;
using System.IO;
using System.Net;
using System.Collections.Specialized;
using System.Data.Services.Common;
using System.Data.Services.Client;
using System.Globalization;
using System.Xml;
using System.Xml.Linq;
using Microsoft.ServiceHosting.ServiceRuntime;
using Microsoft.Samples.ServiceHosting.StorageClient;

namespace AzureForDotNetDevelopers.LargeDataToBlob
{

    [DataServiceKey("PartitionKey", "RowKey")]
    public class CloudTableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }

        private Dictionary<string, object> _properties = new Dictionary<string, object>();

        internal object this[string key]
        {
            get {return this._properties[key];}

            set{this._properties[key] = value;}
        }

/*        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            string value;
            int count = 0;
            if (_properties != null)
            {
                foreach (KeyValuePair<string, object> kvp in _properties)
                {
                    if (count > 0)
                        sb.Append("|");
                    if (kvp.Value == null)
                        value = string.Empty;
                    else
                        value = kvp.Value.ToString();
                    sb.Append(kvp.Key + "=" + value);
                    count++;
                }
            }
            return sb.ToString();
        }

        public string ToXml()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<entity>");       // RowKey=\"" + this.RowKey + "\">");
            sb.AppendLine("  <PartitionKey>" + this.PartitionKey + "</PartitionKey>");
            sb.AppendLine("  <RowKey>" + this.RowKey + "</RowKey>");

            string value;
            if (_properties != null)
            {
                foreach (KeyValuePair<string, object> kvp in _properties)
                {
                    if (kvp.Value == null)
                        value = string.Empty;
                    else
                        value = kvp.Value.ToString();
                    sb.AppendLine("  <" + kvp.Key + ">" + value + "</" + kvp.Key + ">");
                }
            }

            sb.AppendLine("</entity>");
            return sb.ToString();
        }

        public string ToXmlBinaryValues()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<entity>");       // RowKey=\"" + this.RowKey + "\">");
            sb.AppendLine("  <PartitionKey>" + this.PartitionKey + "</PartitionKey>");
            sb.AppendLine("  <RowKey>" + this.RowKey + "</RowKey>");

            string value;
            if (_properties != null)
            {
                foreach (KeyValuePair<string, object> keyValuePair in _properties)
                {
                    if (keyValuePair.Value == null)
                        value = string.Empty;
                    else
                        value = keyValuePair.Value.ToString();

                    value = DisplayCharsAsBytes(value.ToCharArray());

                    sb.AppendLine("  <" + keyValuePair.Key + ">" + value + "</" + keyValuePair.Key + ">");
                }
            }

            sb.AppendLine("</entity>");
            return sb.ToString();
        }

        /// Convert a byte sequence into a displayable multi-line string showing the values.
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>

        private string DisplayBytes(byte[] bytes)
        {
            StringBuilder sb = new StringBuilder();

            for (int b = 0; b < bytes.Length; b++)
                sb.Append(String.Format("{0:X2}", bytes[b]) + " ");
            return sb.ToString();
        }

        private string DisplayCharsAsBytes(char[] chars)
        {
            StringBuilder sb = new StringBuilder();

            for (int b = 0; b < chars.Length; b++)
                sb.Append(String.Format("{0:X4}", Convert.ToInt64(char.GetNumericValue(chars[b]))) + " ");
            return sb.ToString();
        }*/
   }
}
