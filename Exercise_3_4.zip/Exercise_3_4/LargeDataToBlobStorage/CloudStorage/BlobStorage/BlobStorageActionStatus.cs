﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Collections.Specialized;
using System.Threading;

namespace AzureForDotNetDevelopers.LargeDataToBlob.CloudStorage.BlobStorage
{
    abstract public class BlobStorageActionStatus
    {
        protected float _percentComplete = 0.0f;
        protected BlobStorageFacade _blobStorageFacade = null;
        protected byte [] _dataSource = null;


        public BlobStorageActionStatus(byte[] dataSource)
        {
            _dataSource = dataSource;
        }

        public BlobStorageActionStatus(string blobName)
        {
            this.UId = blobName;
            this._Initialization();
        }

        public BlobStorageActionStatus(string blobName, byte[] dataSource)
            : this(dataSource)
        {
            this.UId = blobName;
            this._Initialization();
        }

        public String UId{ get; set;}

        public int PercentComplete
        {
            get { return (int)_percentComplete; }
        }

        private void _Initialization()
        {
            _blobStorageFacade = new BlobStorageFacade(this.UId, this._dataSource);
            Thread thread = new Thread(new ParameterizedThreadStart(this._blobStorageWorkerThread));
            thread.Start(_blobStorageFacade);
        }

        abstract protected void _blobStorageWorkerThread(object paramters);
    }
}
