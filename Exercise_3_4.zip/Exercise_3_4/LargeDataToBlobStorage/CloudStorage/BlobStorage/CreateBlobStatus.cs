﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Collections.Specialized;
using System.Threading;

namespace AzureForDotNetDevelopers.LargeDataToBlob.CloudStorage.BlobStorage
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using Microsoft.WindowsAzure.ServiceRuntime;
    using CSharpBuildingBlocks;

    public class CreateBlobStatus : BlobStorageActionStatus, ICommand
    {
        public long CreateContentSize { get; set; }

        public CreateBlobStatus(byte[] dataSource)
            : base(dataSource)
        { }

        public CreateBlobStatus(string blobName, byte[] dataSource)
            : base(blobName, dataSource)
        { }

        public void Execute()
        {
            try
            {
                CloudBlob blob = _blobStorageFacade.BlobContainer.GetBlobReference(base.UId);
                blob.UploadByteArray(base._dataSource);
                _percentComplete = (float)((blob.Properties.Length * 100.0f) / (CreateContentSize * 1.0f));
                System.Diagnostics.Trace.WriteLine(string.Format("---{0}:Execute, _percentComplete = <{1}>", this.ToString(), _percentComplete));
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(string.Format("---{0}:Execute,exception caught <{1}>", this.ToString(), ex.Message));
            }
        }

        override protected void _blobStorageWorkerThread(object paramters)
        {
            //(paramters as BlobStorageFacade).CreateBlob();
        }
    }
}
