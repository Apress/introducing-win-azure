﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace AzureForDotNetDevelopers.LargeDataToBlob.CloudStorage.BlobStorage
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using Microsoft.WindowsAzure.ServiceRuntime;
    using CSharpBuildingBlocks;

    public class DeleteBlobStatus : BlobStorageActionStatus, ICommand
    {
        public DeleteBlobStatus(string blobName)
            : base(blobName)
        {
        }

        public void Execute()
        {
            CloudBlob blob = _blobStorageFacade.BlobContainer.GetBlobReference(base.UId);
            bool success = blob.DeleteIfExists();
            if (success)
            {
                _percentComplete = 100.0f;
            }
        }

        override protected void _blobStorageWorkerThread(object paramters)
        {
            //(paramters as BlobStorageFacade).DeleteBlob();
        }
    }
}
