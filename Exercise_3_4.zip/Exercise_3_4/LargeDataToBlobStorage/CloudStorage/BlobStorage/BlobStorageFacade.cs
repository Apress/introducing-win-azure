﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Collections.Specialized;
using System.Threading;
using System.IO;

namespace AzureForDotNetDevelopers.LargeDataToBlob.CloudStorage.BlobStorage
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using Microsoft.WindowsAzure.ServiceRuntime;
    using CSharpBuildingBlocks;

    public class BlobStorageFacade : AzureStorageFacade
    {
        static public long LARGE_BLOB_SIZE = 2 * 1024 * 1024;// 2 MB
        protected CloudBlobClient _blobStorage;
        protected CloudBlobContainer _blobContainer;
        protected string _blobContainerName = ConfigurationManager.AppSettings["BlobContainerName"];
        protected NameValueCollection _metadata = null;
        protected Thread _createBlobWorkerthread = null;
        public BlobProperties Properties { get; set; }
        protected object Data{ get; set; }
        public string BlobName { get; set; }
        public string BlobType { get; set; }

        public BlobStorageFacade():base()
        {
            _blobStorage = _accountInformation.CreateCloudBlobClient();
            _blobStorage.RetryPolicy = RetryPolicies.Retry(retry, TimeSpan.FromMilliseconds(retryInterval));
            _blobContainer = _blobStorage.GetContainerReference(_blobContainerName);
            _blobContainer.CreateIfNotExist();
            var permissions = _blobContainer.GetPermissions();
            permissions.PublicAccess = BlobContainerPublicAccessType.Container;
            _blobContainer.SetPermissions(permissions);
        }

        public BlobStorageFacade(NameValueCollection metadata):this()
        {
            _metadata = metadata;
        }

        public BlobStorageFacade(NameValueCollection metadata, 
                                object data)
            : this(metadata)
        {
            Data = data;
        }

        public BlobStorageFacade(string blobName, object data)
            : this()
        {
            Data = data;
            BlobName = blobName;
        }

        public BlobStorageFacade(string blobName, string blobType, object data)
            : this(blobName, data)
        {
            BlobType = blobType;
        }

        public CloudBlobContainer BlobContainer
        {
            get { return _blobContainer; }
        }

        public IEnumerable<CloudBlobContainer> GetBlobContainers()
        {
            return _blobStorage.ListContainers();
        }
    }
}
