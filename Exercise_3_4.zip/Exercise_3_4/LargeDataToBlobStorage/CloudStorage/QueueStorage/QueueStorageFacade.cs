﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Net.Mime;
using System.Configuration;
using System.IO;
using System.Net;
using System.Collections.Specialized;
using System.Data.Services.Common;
using System.Data.Services.Client;
using System.Globalization;
using System.Xml;
using System.Xml.Linq;

namespace AzureForDotNetDevelopers.LargeDataToBlob.CloudStorage.QueueStorage
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using Microsoft.WindowsAzure.ServiceRuntime;

    public class QueueStorageFacade : AzureStorageFacade
    {
        protected CloudQueueClient _queueStorage = null;
        protected CloudQueue _queue = null;
        protected string _queueName = "DefaultQueue";

        public QueueStorageFacade()
        {
            #if CTP_MAY_2009
            StorageAccountInfo qaccount = StorageAccountInfo.GetDefaultQueueStorageAccountFromConfiguration();
            _queueStorage = QueueStorage.Create(qaccount);
            _queueStorage = QueueStorage.Create(qaccount);
            _queueStorage.RetryPolicy = RetryPolicies.Retry(retry, TimeSpan.FromMilliseconds(retryInterval));
            #else
            CloudStorageAccount account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            _queueStorage = account.CreateCloudQueueClient();
            _queue = _queueStorage.GetQueueReference(this.QueueName);
            _queue.CreateIfNotExist();
            _queueStorage.RetryPolicy = RetryPolicies.Retry(retry, TimeSpan.FromMilliseconds(retryInterval));
            #endif
        }

        virtual protected string QueueName
        {
            get { return this._queueName; }
            set { this._queueName = value; }
        }

        #region Public Method

        public IEnumerable<CloudQueue> GetQueues()
        {
            return _queueStorage.ListQueues();
        }

        #endregion
    }
}
