﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Net.Mime;
using System.Configuration;
using System.IO;
using System.Net;
using System.Collections.Specialized;
using System.Data.Services.Common;
using System.Data.Services.Client;
using System.Globalization;
using System.Xml;
using System.Xml.Linq;

namespace AzureForDotNetDevelopers.LargeDataToBlob.CloudStorage.TableStorage
{
    public class TableStorageFacade : AzureStorageFacade
    {
        protected TableStorage _tableStorage = null;

        public TableStorageFacade()
        {
            StorageAccountInfo taccount = StorageAccountInfo.GetDefaultTableStorageAccountFromConfiguration();
            _tableStorage = TableStorage.Create(taccount);
            _tableStorage = TableStorage.Create(taccount);
            _tableStorage.RetryPolicy = RetryPolicies.RetryN(retry, TimeSpan.FromMilliseconds(retryInterval));
        }
        #region Public Method

        public IEnumerable<string> GetTables()
        {
            return _tableStorage.ListTables();
        }

        public void DeleteTable(string tableName)
        {
            _tableStorage.DeleteTable(tableName);
        }

        public void DeleteTableRecord(string tableName, CloudTableEntity entity)
        {
            List<CloudTableEntity> entityList = new List<CloudTableEntity>();

            TableStorageDataServiceContext tableStorageDataServiceContext = _tableStorage.GetDataServiceContext();

            tableStorageDataServiceContext.IgnoreMissingProperties = true;
            tableStorageDataServiceContext.ReadingEntity += new EventHandler<ReadingWritingEntityEventArgs>(_OnReadingEntity);

            var queryResults = (from x in tableStorageDataServiceContext.CreateQuery<CloudTableEntity>(tableName)
                                where x.PartitionKey == entity.PartitionKey && x.RowKey == entity.RowKey
                                select x);

            TableStorageDataServiceQuery<CloudTableEntity> tableStorageQuery = new TableStorageDataServiceQuery<CloudTableEntity>(queryResults as DataServiceQuery<CloudTableEntity>);
            IEnumerable<CloudTableEntity> entities = tableStorageQuery.ExecuteAllWithRetries();
            foreach (CloudTableEntity entityFound in entities)
            {
                tableStorageDataServiceContext.DeleteObject(entityFound);
            }
            tableStorageDataServiceContext.SaveChanges();
        }

        public IEnumerable<CloudTableEntity> GetTableRecords(string tableName)
        {
            List<CloudTableEntity> entityList = new List<CloudTableEntity>();

            TableStorageDataServiceContext tableServiceContext = _tableStorage.GetDataServiceContext();

            tableServiceContext.IgnoreMissingProperties = true;
            tableServiceContext.ReadingEntity += new EventHandler<ReadingWritingEntityEventArgs>(_OnReadingEntity);

            var qResult2 = (from c in tableServiceContext.CreateQuery<CloudTableEntity>(tableName)
                            select c);

            TableStorageDataServiceQuery<CloudTableEntity> tableStorageQuery = new TableStorageDataServiceQuery<CloudTableEntity>(qResult2 as DataServiceQuery<CloudTableEntity>);
            IEnumerable<CloudTableEntity> entities = tableStorageQuery.ExecuteAllWithRetries();
            foreach (CloudTableEntity entity in entities)
            {
                entityList.Add(entity);
            }

            return entityList;
        }

        #endregion

        #region Private Method

        private void _OnReadingEntity(object sender, ReadingWritingEntityEventArgs args)
        {
            XNamespace XNAMESPACE_ATOM = ConfigurationManager.AppSettings["AtomNamespace"];
            XNamespace XNAMESPACE_DATASERICE = ConfigurationManager.AppSettings["DataservicesNamespace"];
            XNamespace XNAMESPACE_METADATA = ConfigurationManager.AppSettings["MetadataNamespace"];

            CloudTableEntity entity = args.Entity as CloudTableEntity;
            if (entity == null)
            {
                return;
            }

            var properties = args.Entity.GetType().GetProperties();
            var queryResults = from p in args.Data.Element(XNAMESPACE_ATOM + "content")
                                    .Element(XNAMESPACE_METADATA + "properties")
                                    .Elements()
                               where properties.All(pn => pn.Name != p.Name.LocalName)
                               select new
                               {
                                   Name = p.Name.LocalName,
                                   IsNull = string.Equals("true", p.Attribute(XNAMESPACE_METADATA + "null") == null ? null : p.Attribute(XNAMESPACE_METADATA + "null").Value, StringComparison.OrdinalIgnoreCase),
                                   TypeName = p.Attribute(XNAMESPACE_METADATA + "type") == null ? null : p.Attribute(XNAMESPACE_METADATA + "type").Value,
                                   p.Value
                               };

            foreach (var dp in queryResults)
            {
                entity[dp.Name] = _GetTypedEdmValue(dp.TypeName, dp.Value, dp.IsNull);
            }
        }

        private static object _GetTypedEdmValue(string type, string value, bool isnull)
        {
            if (isnull) return null;

            if (string.IsNullOrEmpty(type)) return value;

            switch (type)
            {
                case "Edm.String": return value;
                case "Edm.Byte": return Convert.ChangeType(value, typeof(byte));
                case "Edm.SByte": return Convert.ChangeType(value, typeof(sbyte));
                case "Edm.Int16": return Convert.ChangeType(value, typeof(short));
                case "Edm.Int32": return Convert.ChangeType(value, typeof(int));
                case "Edm.Int64": return Convert.ChangeType(value, typeof(long));
                case "Edm.Double": return Convert.ChangeType(value, typeof(double));
                case "Edm.Single": return Convert.ChangeType(value, typeof(float));
                case "Edm.Boolean": return Convert.ChangeType(value, typeof(bool));
                case "Edm.Decimal": return Convert.ChangeType(value, typeof(decimal));
                case "Edm.DateTime": return XmlConvert.ToDateTime(value, XmlDateTimeSerializationMode.RoundtripKind);
                case "Edm.Binary": return Convert.FromBase64String(value);
                case "Edm.Guid": return new Guid(value);

                default: throw new NotSupportedException(string.Format("the type <{0}> is not supported.", type));
            }
        }

        #endregion
    }
}
