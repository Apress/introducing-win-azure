﻿﻿using System;
using System.Configuration;
using System.IO;
using System.Text;

namespace AzureForDotNetDevelopers.LargeDataToBlob
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using Microsoft.WindowsAzure.ServiceRuntime;

    public class AzureStorageFacade 
    {
        protected CloudStorageAccount _accountInformation;
        protected int retry = 1;
        protected int retryInterval = 1000;

        public CloudStorageAccount StorageAccountInfo
        {
            get{ return _accountInformation; }
        }


        public AzureStorageFacade()
        {
            _InitializationStorages();
        }

        public static byte[] ConvertToByteArray(object source)
        {
            byte[] results = null;

            if (null != source)
            {
                if (source is string)
                {
                    string strSource = source.ToString();
                    if (!string.IsNullOrEmpty(strSource))
                    {
                        if (File.Exists(strSource))
                        {
                            results = File.ReadAllBytes(strSource);
                        }
                        else
                        {
                            results = UTF8Encoding.UTF8.GetBytes(strSource);
                        }
                    }
                }
                else if (source is Stream)
                {
                    StreamReader sr = new StreamReader(source as Stream);
                    string s = sr.ReadToEnd();
                    if (!string.IsNullOrEmpty(s))
                    {
                        results = UTF8Encoding.UTF8.GetBytes(s);
                    }
                }
            }

            return results;
        }

        protected void _InitializationStorages()
        {
            retry = Convert.ToInt32(ConfigurationManager.AppSettings["Retry"]);
            retryInterval = Convert.ToInt32(ConfigurationManager.AppSettings["RetryInterval"]);

            string accountKey = ConfigurationManager.AppSettings["AccountSharedKey"];
            string accountName = ConfigurationManager.AppSettings["AccountName"];
            
            StorageCredentialsAccountAndKey credentials = new StorageCredentialsAccountAndKey(accountName, accountKey);

            _accountInformation = new CloudStorageAccount(credentials,
                                                          new Uri(String.Format("{0}/{1}", ConfigurationManager.AppSettings["BlobStorageEndpoint"], accountName)),
                                                          new Uri(String.Format("{0}/{1}", ConfigurationManager.AppSettings["QueueStorageEndpoint"], accountName)),
                                                          new Uri(String.Format("{0}/{1}", ConfigurationManager.AppSettings["TableStorageEndpoint"], accountName)));
        }
    }
}
