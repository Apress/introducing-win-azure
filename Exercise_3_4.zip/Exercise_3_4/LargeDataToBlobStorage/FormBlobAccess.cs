﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections.Specialized;
using System.Configuration;

namespace AzureForDotNetDevelopers.LargeDataToBlob.CloudStorage
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using Microsoft.WindowsAzure.ServiceRuntime;

    using CSharpBuildingBlocks;
    using CSharpBuildingBlocks.QueuedBackgroundWorker;
    using CSharpBuildingBlocks.EventsHelper;
    using AzureForDotNetDevelopers.LargeDataToBlob.CloudStorage.BlobStorage;

    public partial class FormBlobAccess : Form
    {
        const string MB = "(mb)";
        private QueuedBackgroundWorkeComponent _backgroundWorkeComponent = null;
        private ICommand _command = null;
        private FileInfo _fileInfo = null;

        public FormBlobAccess()
        {
            InitializeComponent();

            this._backgroundWorkeComponent = new QueuedBackgroundWorkeComponent();
            this._backgroundWorkeComponent.DoWork += new System.ComponentModel.DoWorkEventHandler(this._backgroundWorker_DoWork);
            this._backgroundWorkeComponent.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this._backgroundWorker_RunWorkerCompleted);
            this._backgroundWorkeComponent.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this._backgroundWorkeComponent_ProgressChanged);

            _UpdateUI();
        }

        private void _UpdateUI()
        {
            try
            {
                _btnGenerateBlobName.Enabled = _fileInfo == null ? false : true;
                btnAbort.Enabled = false;

                this.combBoxBlobList.Items.Clear();
                combBoxBlobList.Text = string.Empty;

                BlobStorageFacade blobStorageFacade = new BlobStorageFacade();

                IEnumerable<IListBlobItem> blobs = blobStorageFacade.BlobContainer.ListBlobs(new BlobRequestOptions()
                                                                                            {
                                                                                                UseFlatBlobListing = true,
                                                                                                BlobListingDetails = BlobListingDetails.All
                                                                                            });

                if (null != blobs)
                {
                    blobs.ToList<IListBlobItem>().ForEach(b => this.combBoxBlobList.Items.Add((b as CloudBlob).Uri));

                    if (this.combBoxBlobList.Items.Count > 0)
                    {
                        this.combBoxBlobList.SelectedIndex = 0;
                        btnDelete.Enabled = true;
                    }
                    else
                    {
                        btnDelete.Enabled = false;
                    }

                    timer1.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                toolStripStatusLabel1.ForeColor = Color.Red;
                toolStripStatusLabel1.Text = string.Format("The Dev storage and local Fabric must be started before running this App!!!, {0}:_UpdateUI, exception caught:{1}", this.ToString(), ex.Message);
            }
        }

        private void _pickFile_Click(object sender, EventArgs e)
        {
            if (_openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileToUpload = _openFileDialog.FileNames[0];
                _fileName.Text = fileToUpload;
                _fileInfo = new FileInfo(fileToUpload);
                lblFileSize.Text = string.Format("{0:####.##} {1}", _fileInfo.Length * 1.0 / 1024.0 / 1024.0, MB);
                lblCreateTime.Text = _fileInfo.CreationTime.ToString();

                this.btnGenerateBlobName_Click(this, null);

                btnUpload.Enabled = true;

                _UpdateUI();
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            toolStripProgressBar1.Visible = true;
            toolStripStatusLabel1.Text = string.Empty; ;
            btnAbort.Enabled = true;
            btnDelete.Enabled = false;
            lblTimeStart.Text = DateTime.Now.ToString();
            lblTimeEnd.Text = string.Empty;
            lblTimeElapsed.Text = string.Empty;
            timer1.Enabled = true;

            if (txtBlobName.Text.ToString().Trim() == string.Empty)
            {
                btnGenerateBlobName_Click(this, null);
            }

            string blobName = txtBlobName.Text.ToString().Trim();

            _command = new CreateBlobStatus(blobName, AzureStorageFacade.ConvertToByteArray(_fileInfo.FullName))
            {
                CreateContentSize = _fileInfo.Length
            } ;

            _backgroundWorkeComponent._QueuedBackgroundWorker.RunWorkerAsync(_command);
        }

        private void btnGenerateBlobName_Click(object sender, EventArgs e)
        {
            double fileSize = 0;
            string s = lblFileSize.Text.ToString().Trim().Replace(MB, string.Empty);
            if ( s != string.Empty)
            {
                fileSize = double.Parse(s) * 1024 * 1024;
            }

            if (fileSize > BlobStorageFacade.LARGE_BLOB_SIZE)
            {
                txtBlobName.Text = string.Format("{0}_{1}",
                                                 Guid.NewGuid(),
                                                 "large");
            }
            else
            {
                txtBlobName.Text = string.Format("{0}",
                                                 Guid.NewGuid());
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            toolStripProgressBar1.Visible = true;
            toolStripStatusLabel1.Text = string.Empty;
            toolStripStatusLabel1.ForeColor = Color.Black;
            btnAbort.Enabled = true;
            lblTimeStart.Text = DateTime.Now.ToString();
            lblTimeEnd.Text = string.Empty;
            lblTimeElapsed.Text = string.Empty;
            timer1.Enabled = true;

            string blobName = combBoxBlobList.SelectedItem.ToString();
            try
            {
                _command = new DeleteBlobStatus(blobName);
                _backgroundWorkeComponent._QueuedBackgroundWorker.RunWorkerAsync(_command);
            }
            catch (Exception ex)
            {
                toolStripStatusLabel1.ForeColor = Color.Red;
                toolStripStatusLabel1.Text = ex.Message;
            }
        }

        private void _backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {

            if (e.Argument is CreateBlobStatus)
            {
                _command = (CreateBlobStatus)e.Argument;
                if (_backgroundWorkeComponent._QueuedBackgroundWorker.IsCancellationPending(_command))
                {
                    e.Cancel = true;
                }
            }
            else if (e.Argument is FibGeneratorState)
            {
                _command = (FibGeneratorState)e.Argument;
            }

            if (null != _command)
            {
                while (!_backgroundWorkeComponent._QueuedBackgroundWorker.IsCancellationPending(_command)
                    && _command.PercentComplete < 100)
                {
                    _backgroundWorkeComponent._QueuedBackgroundWorker.ReportProgress(_command.PercentComplete, _command);
                    _command.Execute();
                    e.Result = _command;
                    Application.DoEvents();
                }
            }


        }

        private void _backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            lblTimeEnd.Text = DateTime.Now.ToString();
            if (_command is CreateBlobStatus)
            {
                toolStripStatusLabel1.Text = "Upload blob success.";
            }
            else if (_command is DeleteBlobStatus)
            {
                toolStripStatusLabel1.Text = "Delete blob success.";
            }

            _UpdateUI();
        }

        private void _backgroundWorkeComponent_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //_progressBar.Value = e.ProgressPercentage;
            Update();
            Application.DoEvents();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            btnUpload.Enabled = true;
            btnDelete.Enabled = true;
            btnAbort.Enabled = false;
            toolStripStatusLabel1.Text = "Actiong aborted.";
            _backgroundWorkeComponent._QueuedBackgroundWorker.CancelAllAsync();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string timeStart = lblTimeStart.Text.Trim();
            if (string.Empty != timeStart)
            {
                DateTime startTime = DateTime.Parse(timeStart);
                DateTime timeNow = DateTime.Now;
                TimeSpan timeElapsed = new TimeSpan(timeNow.Day - startTime.Day,
                                                    timeNow.Hour - startTime.Hour,
                                                    timeNow.Minute - startTime.Minute,
                                                    timeNow.Second - startTime.Second,
                                                    timeNow.Millisecond - startTime.Millisecond);
                lblTimeElapsed.Text = string.Format("{0:#####.###}", timeElapsed.TotalMilliseconds / 1000.0);
            }
        }
    }
}
