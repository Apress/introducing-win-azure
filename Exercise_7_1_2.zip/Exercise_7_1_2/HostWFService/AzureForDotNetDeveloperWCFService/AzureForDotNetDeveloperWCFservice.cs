﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Workflow.Runtime;
using System.Threading;
using System.Workflow.ComponentModel;

namespace AzureForDotNetDeveloperWCFserviceLibrary
{
    using CustomerRegisterNotification;

    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class UserRegisterService : IUserRegisterService
    {
        List<User> userList = new List<User>();

        #region IUserRegisterService Members

        public void AddUser(User user)
        {
            userList.Add(user);

            using (WorkflowRuntime workflowRuntime = new WorkflowRuntime())
            {
                AutoResetEvent waitHandle = new AutoResetEvent(false);
                workflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e) { waitHandle.Set(); };
                workflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e)
                {
                    Console.WriteLine(e.Exception.Message);
                    waitHandle.Set();
                };

                WorkflowInstance instance = workflowRuntime.CreateWorkflow(typeof(CustomerRegisterNotificationWorkflow));
                instance.Start();


                waitHandle.WaitOne();
            }
        }

        public List<User> GetUserList()
        {
            return userList;
        }

        #endregion
    }
}
