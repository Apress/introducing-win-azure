﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.ServiceModel;
using System.IO;
using System.Xml;
using System.Runtime.Serialization;

namespace Microsoft.ServiceModel.Samples
{
	internal class ClientContextProtocol : ContextProtocol, IContextManager
	{
		private ContextMessageProperty context;
		private bool contextInitialized;
		private bool contextManagementEnabled;
		private IChannel owner;
		private object thisLock;
		private System.Uri uri;

		public ClientContextProtocol(System.Uri uri, IChannel owner) : base()
		{
			this.context = GetEmpty();
			this.contextManagementEnabled = true;
			this.owner = owner;
			this.thisLock = new object();
			this.uri = uri;
		}

		private void EnsureInvariants(bool isServerIssued, ContextMessageProperty newContext)
		{
			if (!this.contextManagementEnabled)
			{
				throw new Exception("Context Managment not enabled");
			}
			if ((isServerIssued && !this.contextInitialized) || (this.owner.State == CommunicationState.Created))
			{
				lock (this.thisLock)
				{
					if ((isServerIssued && !this.contextInitialized) || (this.owner.State == CommunicationState.Created))
					{
						this.context = newContext;
						this.contextInitialized = true;
						return;
					}
				}
			}
			if (isServerIssued)
			{
				throw new Exception("Received invalid context");
			}
			throw new Exception("The cached context is inmutable");
		}

		public IDictionary<string, string> GetContext()
		{
			if (!this.contextManagementEnabled)
			{
				throw new Exception("Context Managment not enabled");
			}
			return new Dictionary<string, string>(this.context.Context);
		}

		private string GetHttpHeaderFromContext(ContextMessageProperty contextMessageProperty)
		{
			return EncodeContextAsHttpHeader(contextMessageProperty);
		}

		private string EncodeContextAsHttpHeader(ContextMessageProperty context)
		{
			if (context == null)
			{
				throw new ArgumentNullException("context");
			}

			MemoryStream output = new MemoryStream();
			XmlWriterSettings settings = new XmlWriterSettings();
			settings.OmitXmlDeclaration = true;
			XmlWriter writer = XmlWriter.Create(output, settings);
			new ContextMessageHeader(context.Context).WriteHeader(writer, MessageVersion.Default);
			writer.Flush();

			return Convert.ToBase64String(output.GetBuffer(), 0, (int)output.Length);
		}

		public override void OnIncomingMessage(Message message)
		{
			if (message == null)
			{
				throw new ArgumentNullException("message");
			}
			
			ContextMessageProperty newContext = this.OnReceiveMessage(message);
			if (newContext != null)
			{
				if (this.contextManagementEnabled)
				{
					this.EnsureInvariants(true, newContext);
				}
				else
				{
					newContext.AddOrReplaceInMessage(message);
				}
			}
		}

		public override void OnOutgoingMessage(Message message, System.ServiceModel.Channels.RequestContext requestContext)
		{
			if (message == null)
			{
				throw new ArgumentNullException("message");
			}
			
			ContextMessageProperty contextMessageProperty = null;
			if (ContextMessageProperty.TryGet(message, out contextMessageProperty) && this.contextManagementEnabled)
			{
				throw new Exception("Invalid message context");			
			}

			if (this.contextManagementEnabled && this.context.Context.Count > 0)
			{
				contextMessageProperty = this.context;
			}
			if (contextMessageProperty != null)
			{
				this.OnSendMessage(message, contextMessageProperty);
			}
		}

		private ContextMessageProperty OnReceiveMessage(Message message)
		{
			ContextMessageProperty context = null;
			object obj2;
			if (message.Properties.TryGetValue(HttpResponseMessageProperty.Name, out obj2))
			{
				HttpResponseMessageProperty property2 = obj2 as HttpResponseMessageProperty;
				if (property2 == null)
				{
					return context;
				}
				string str = property2.Headers["WscContext"];
				if (string.IsNullOrEmpty(str))
				{
					return context;
				}
				
				if (!string.IsNullOrEmpty(str))
				{
					TryCreateFromHttpHeader(str, out context);
				}
			}
			return context;
		}

		private bool TryCreateFromHttpHeader(string httpHeader, out ContextMessageProperty context)
		{
			if (httpHeader == null)
				throw new ArgumentNullException("httpHeader");

			try
			{
				context = ContextMessageHeader.ParseContextHeader(XmlReader.Create(new MemoryStream(Convert.FromBase64String(httpHeader))));
			}
			catch (SerializationException exception)
			{
				throw;
			}
			catch (ProtocolException exception2)
			{
				throw;
			}

			return (context != null);
		}

		private void OnSendMessage(Message message, ContextMessageProperty context)
		{
			object value;
			HttpRequestMessageProperty httpProperty = null;
			if (message.Properties.TryGetValue(HttpRequestMessageProperty.Name, out value))
			{
				httpProperty = value as HttpRequestMessageProperty;
			}
			if (httpProperty == null)
			{
				httpProperty = new HttpRequestMessageProperty();
				message.Properties.Add(HttpResponseMessageProperty.Name, httpProperty);
			}
			string str = EncodeContextAsHttpHeader(context);
			httpProperty.Headers.Add("WscContext", str);
		}

		public void SetContext(IDictionary<string, string> context)
		{
			if (context == null)
			{
				throw new ArgumentNullException("context");
			}
			ContextMessageProperty newContext = new ContextMessageProperty(context);
			this.EnsureInvariants(false, newContext);
		}

		bool IContextManager.Enabled
		{
			get
			{
				return this.contextManagementEnabled;
			}
			set
			{
				if (this.owner.State != CommunicationState.Created)
				{
					throw new InvalidOperationException("Channel is already open");
				}
				this.contextManagementEnabled = value;
			}
		}

		protected System.Uri Uri
		{
			get
			{
				return this.uri;
			}
		}

		private ContextMessageProperty GetEmpty()
		{
			ContextMessageProperty property = new ContextMessageProperty(SerializableReadOnlyDictionary<string, string>.Empty);
			return property;
		}

		
	}
}
