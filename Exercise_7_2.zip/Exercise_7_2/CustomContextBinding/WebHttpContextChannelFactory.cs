using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Microsoft.ServiceModel.Samples.Properties;

namespace Microsoft.ServiceModel.Samples
{
    
	class WebHttpContextChannelFactory<TChannel> : ChannelFactoryBase<TChannel>
    {
        IChannelFactory<TChannel> innerChannelFactory;

        public WebHttpContextChannelFactory(IChannelFactory<TChannel> innerChannelFactory)
        {
            this.innerChannelFactory = innerChannelFactory;
        }

		public override T GetProperty<T>()
		{
			if (typeof(T) == typeof(IChannelFactory<TChannel>))
			{
				return (T)(object)this;
			}
			T property = base.GetProperty<T>();
			if (property != null)
			{
				return property;
			}
			return this.innerChannelFactory.GetProperty<T>();

		}

        protected override TChannel OnCreateChannel(EndpointAddress address, Uri via)
        {
            TChannel innerChannel =
                innerChannelFactory.CreateChannel(address, via);

			if (typeof(TChannel) ==
				typeof(IRequestChannel))
			{
				return (TChannel)(object)new WebHttpContextRequestChannel(
					this,
					(IRequestChannel)innerChannel);
			}													
			else
			{
				throw new NotSupportedException("");
			}
			
        }

        protected override void OnOpen(TimeSpan timeout)
        {
            innerChannelFactory.Open(timeout);
        }

        protected override IAsyncResult OnBeginOpen(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return innerChannelFactory.BeginOpen(timeout, callback, state);
        }

        protected override void OnEndOpen(IAsyncResult result)
        {
            innerChannelFactory.EndOpen(result);
        }
    }
}
