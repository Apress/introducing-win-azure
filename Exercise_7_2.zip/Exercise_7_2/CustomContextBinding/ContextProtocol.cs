﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;

namespace Microsoft.ServiceModel.Samples
{
	internal abstract class ContextProtocol
	{
		protected ContextProtocol()
		{
		}

		public abstract void OnIncomingMessage(Message message);
		public abstract void OnOutgoingMessage(Message message, RequestContext requestContext);
	}
}
