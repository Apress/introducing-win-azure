using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Collections.Specialized;

namespace Microsoft.ServiceModel.Samples
{
    class WebHttpContextReplyChannel : WebHttpContextChannelBase, IReplyChannel
    {
        IReplyChannel innerReplyChannel;

        public WebHttpContextReplyChannel(ChannelManagerBase channelManager, IReplyChannel innerChannel, ContextMode contextMode, NameValueCollection uriTemplates)
            : base(channelManager, innerChannel)
        {
            this.innerReplyChannel = innerChannel;
			this.ContextMode = contextMode;
			this.UriTemplates = uriTemplates;
        }

		public ContextMode ContextMode
		{
			get;
			private set;
		}

		public NameValueCollection UriTemplates
		{
			get;
			private set;
		}

		public override T GetProperty<T>()
		{
			T baseProperty = base.GetProperty<T>();
			if (baseProperty != null)
			{
				return baseProperty;
			}

			return this.innerChannel.GetProperty<T>();
		}

        public IAsyncResult BeginReceiveRequest(TimeSpan timeout,
            AsyncCallback callback, object state)
        {
            return innerReplyChannel.BeginReceiveRequest(timeout,
                callback, state);
        }

        public IAsyncResult BeginReceiveRequest(AsyncCallback callback, object state)
        {
            return BeginReceiveRequest(DefaultReceiveTimeout,
                callback, state);
        }

        public IAsyncResult BeginTryReceiveRequest(TimeSpan timeout,
            AsyncCallback callback, object state)
        {
            return innerReplyChannel.BeginTryReceiveRequest(timeout,
                callback, state);
        }

        public IAsyncResult BeginWaitForRequest(TimeSpan timeout,
            AsyncCallback callback, object state)
        {
            return innerReplyChannel.BeginWaitForRequest(timeout, callback, state);
        }

		private WebHttpContextRequestContext CreateContextChannelRequestContext(RequestContext innerContext)
		{
			ServiceContextProtocol contextProtocol = new ServiceContextProtocol(this.ContextMode, this.UriTemplates);
			contextProtocol.OnIncomingMessage(innerContext.RequestMessage);
			return new WebHttpContextRequestContext(innerContext, contextProtocol);
		}

        public RequestContext EndReceiveRequest(IAsyncResult result)
        {
			RequestContext innerContext = innerReplyChannel.EndReceiveRequest(result);
			if (innerContext == null)
			{
				return null;
			}
			return this.CreateContextChannelRequestContext(innerContext);

        }

        public bool EndTryReceiveRequest(IAsyncResult result, out RequestContext context)
        {
			RequestContext context2;
			context = null;
			if (!this.innerReplyChannel.EndTryReceiveRequest(result, out context2))
			{
				return false;
			}
			if (context2 != null)
			{
				context = this.CreateContextChannelRequestContext(context2);
			}
			return true;

        }

        public bool EndWaitForRequest(IAsyncResult result)
        {
            return innerReplyChannel.EndWaitForRequest(result);
        }

        public EndpointAddress LocalAddress
        {
            get
            {
                return innerReplyChannel.LocalAddress;
            }
        }

        public RequestContext ReceiveRequest(TimeSpan timeout)
        {
			RequestContext innerContext = this.innerReplyChannel.ReceiveRequest();
			if (innerContext == null)
			{
				return null;
			}
			return this.CreateContextChannelRequestContext(innerContext);

        }

        public RequestContext ReceiveRequest()
        {
            return ReceiveRequest(DefaultReceiveTimeout);
        }

        public bool TryReceiveRequest(TimeSpan timeout, out RequestContext context)
        {
			RequestContext context2;
			if (this.innerReplyChannel.TryReceiveRequest(timeout, out context2))
			{
				context = this.CreateContextChannelRequestContext(context2);
				return true;
			}
			context = null;
			return false;

        }

        public bool WaitForRequest(TimeSpan timeout)
        {
            return innerReplyChannel.WaitForRequest(timeout);
        }
    }
}
