using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.IO;
using System.ServiceModel.Security;
using System.Collections.Specialized;

namespace Microsoft.ServiceModel.Samples
{
	public class WebHttpContextBindingElement : BindingElement, IContextBindingElement
	{
		public WebHttpContextBindingElement(ContextMode contextMode, NameValueCollection uriTemplates)
		{
			this.ContextMode = contextMode;
			this.UriTemplates = uriTemplates;
		}

		public WebHttpContextBindingElement(WebHttpContextBindingElement other)
		{
			this.ContextMode = other.ContextMode;
			this.UriTemplates = other.UriTemplates;
		}

		public ContextMode ContextMode
		{
			get;
			private set;
		}

		public NameValueCollection UriTemplates
		{
			get;
			private set;
		}

		public override T GetProperty<T>(BindingContext context)
		{
			if (typeof(T) == typeof(IContextBindingElement))
			{
				return (T)(object)this;
			}

			return context.GetInnerProperty<T>();
		}
		
		public override bool CanBuildChannelFactory<TChannel>(
		    BindingContext context)
		{
			if (typeof(TChannel) != typeof(IRequestChannel))
			{
				return false;
			}

			return context.CanBuildInnerChannelFactory<TChannel>();
		}

		public override bool CanBuildChannelListener<TChannel>(
			BindingContext context)
		{
			if (typeof(TChannel) != typeof(IReplyChannel))
			{
				return false;
			}
			
			return context.CanBuildInnerChannelListener<TChannel>();
		}

		public override IChannelFactory<TChannel> BuildChannelFactory<TChannel>(BindingContext context)
		{
			IChannelFactory<TChannel> innerChannelFactory = context.BuildInnerChannelFactory<TChannel>();

			IChannelFactory<TChannel> channelFactory =
				new WebHttpContextChannelFactory<TChannel>(innerChannelFactory);

			return channelFactory;
		}

		public override IChannelListener<TChannel>
			BuildChannelListener<TChannel>(BindingContext context)
		{
			return new WebHttpContextChannelListener<TChannel>(context, this.ContextMode, this.UriTemplates);
		}

		public override BindingElement Clone()
		{
			return new WebHttpContextBindingElement(this);
		}

	}
}
