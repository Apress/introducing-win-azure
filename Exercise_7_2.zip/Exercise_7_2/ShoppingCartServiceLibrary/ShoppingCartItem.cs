﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ShoppingCartServiceLibrary
{

	[Serializable]
	[DataContract(Name="ShoppingCartItem", Namespace="http://costco.com/OnlineShopping")]
	public class ShoppingCartItem
	{
        static public string ENDPOINT_CREDITCARD_PAYMENT = "http://costco.com/OnlineShopping/CreditCardPayment/";
        static public string ENDPOINT_ITEM_UPDATE = "http://costco.com/OnlineShopping/ShoppingCartItem/update/";
        static public string ENDPOINT_ITEM_DELETE = "http://costco.com/OnlineShopping/ShoppingCartItem/delete/";
        static public string CREDIT_CARD_PAYMENT_URI = "http://localhost:8000/CreditCardPayment/ShoppingCartItem/";
        static public string SHOPPING_CART_URI = "http://localhost:8000/ShoppingCartItem/";

		public string ShoppingCartItemId { get; set; }

		[DataMember(Name="ItemName")]
		public string ItemName { get; set; }

		[DataMember(Name="Price")]
		public decimal? Price { get; set; }

		[DataMember(Name="NextItem")]
		public NextItem[] NextItem { get; set; }
	}

	[Serializable]
	[DataContract(Name="NextItem", Namespace="http://costco.com/OnlineShopping")]
	public class NextItem
	{
		[DataMember(Name="Relateive")]
		public string Relateive { get; set; }

		[DataMember(Name="uri")]
		public string Uri { get; set; }

		[DataMember(Name="type")]
		public string Type { get; set; }

		public NextItem()
		{
			Type = "application/xml";
		}
	}
}
