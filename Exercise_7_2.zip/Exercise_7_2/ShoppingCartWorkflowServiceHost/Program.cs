﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace ShoppingCartWorkflowServiceHost
{
    using ShoopingCartWorkflows;

    class Program
    {
        static void Main(string[] args)
        {
            Uri baseAddress = new Uri("http://localhost:8000");

            WorkflowServiceHost host = new WorkflowServiceHost(typeof(ShoppingCartItemWorkflow), baseAddress);
            host.Description.Behaviors.Find<WorkflowRuntimeBehavior>().WorkflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e) { Console.WriteLine("WorkflowTerminated: " + e.Exception.Message); };
            host.Description.Behaviors.Find<WorkflowRuntimeBehavior>().WorkflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e) { Console.WriteLine("WorkflowCompleted."); };

            host.Description.Behaviors.Find<WorkflowRuntimeBehavior>().WorkflowRuntime.AddService(
                new SqlWorkflowPersistenceService(
                "Initial Catalog=WorkflowPersistenceStore;Data Source=localhost\\SQLEXPRESS;Integrated Security=SSPI;",
                true,
                TimeSpan.FromHours(1.0),
                TimeSpan.FromSeconds(5.0)
            ));

            host.Open();

            Console.WriteLine("---- Press <enter> key to exit ----");
            Console.ResetColor();
            Console.ReadLine();

            host.Close();
        }
    }
}
