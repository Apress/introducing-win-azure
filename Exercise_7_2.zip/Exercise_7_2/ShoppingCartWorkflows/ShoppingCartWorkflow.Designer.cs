﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace ShoopingCartWorkflows
{
    partial class ShoppingCartItemWorkflow
    {
        #region Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
            this.CanModifyActivities = true;
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding1 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding2 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding3 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo1 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding4 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding5 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo2 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding6 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind7 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding7 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind8 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding8 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo3 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind9 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding9 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind10 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding10 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo4 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.Activities.WorkflowServiceAttributes workflowserviceattributes1 = new System.Workflow.Activities.WorkflowServiceAttributes();
            this.setCommitClose = new System.Workflow.Activities.SetStateActivity();
            this.codeCommit = new System.Workflow.Activities.CodeActivity();
            this.setStateCheckout = new System.Workflow.Activities.SetStateActivity();
            this.codePayShoppingCartItem = new System.Workflow.Activities.CodeActivity();
            this.setShoppingCartItemPlacedFromUpdate = new System.Workflow.Activities.SetStateActivity();
            this.codeUpdateShoppingCartItem = new System.Workflow.Activities.CodeActivity();
            this.setStateActivity1 = new System.Workflow.Activities.SetStateActivity();
            this.OnShoppingCartItemPlacedCode = new System.Workflow.Activities.CodeActivity();
            this.receiveActivity1 = new System.Workflow.Activities.ReceiveActivity();
            this.setClosedState = new System.Workflow.Activities.SetStateActivity();
            this.delayActivity = new System.Workflow.Activities.DelayActivity();
            this.receiveShoppingCartItemPaid = new System.Workflow.Activities.ReceiveActivity();
            this.receiveShoppingCartItemUpdate = new System.Workflow.Activities.ReceiveActivity();
            this.receiveOnShoppingCartItemPlaced = new System.Workflow.Activities.ReceiveActivity();
            this.eventCheckout = new System.Workflow.Activities.EventDrivenActivity();
            this.eventTimeout = new System.Workflow.Activities.EventDrivenActivity();
            this.eventItemCrediCardApproved = new System.Workflow.Activities.EventDrivenActivity();
            this.eventItemUpdated = new System.Workflow.Activities.EventDrivenActivity();
            this.eventItemAdded = new System.Workflow.Activities.EventDrivenActivity();
            this.stateCheckout = new System.Workflow.Activities.StateActivity();
            this.ItemPlaced = new System.Workflow.Activities.StateActivity();
            this.CartClosed = new System.Workflow.Activities.StateActivity();
            this.WaitingForShoppingCartItem = new System.Workflow.Activities.StateActivity();
            // 
            // setCommitClose
            // 
            this.setCommitClose.Name = "setCommitClose";
            this.setCommitClose.TargetStateName = "CartClosed";
            // 
            // codeCommit
            // 
            this.codeCommit.Name = "codeCommit";
            this.codeCommit.ExecuteCode += new System.EventHandler(this.codeCheckOutShoppingCartItem_ExecuteCode);
            // 
            // setStateCheckout
            // 
            this.setStateCheckout.Name = "setStateCheckout";
            this.setStateCheckout.TargetStateName = "stateCheckout";
            // 
            // codePayShoppingCartItem
            // 
            this.codePayShoppingCartItem.Name = "codePayShoppingCartItem";
            this.codePayShoppingCartItem.ExecuteCode += new System.EventHandler(this.codePayShoppingCartItem_ExecuteCode);
            // 
            // setShoppingCartItemPlacedFromUpdate
            // 
            this.setShoppingCartItemPlacedFromUpdate.Name = "setShoppingCartItemPlacedFromUpdate";
            this.setShoppingCartItemPlacedFromUpdate.TargetStateName = "ItemPlaced";
            // 
            // codeUpdateShoppingCartItem
            // 
            this.codeUpdateShoppingCartItem.Name = "codeUpdateShoppingCartItem";
            this.codeUpdateShoppingCartItem.ExecuteCode += new System.EventHandler(this.codeUpdateShoppingCartItem_ExecuteCode);
            // 
            // setStateActivity1
            // 
            this.setStateActivity1.Name = "setStateActivity1";
            this.setStateActivity1.TargetStateName = "ItemPlaced";
            // 
            // OnShoppingCartItemPlacedCode
            // 
            this.OnShoppingCartItemPlacedCode.Name = "OnShoppingCartItemPlacedCode";
            this.OnShoppingCartItemPlacedCode.ExecuteCode += new System.EventHandler(this.OnShoppingCartItemPlacedCode_ExecuteCode);
            // 
            // receiveActivity1
            // 
            this.receiveActivity1.Activities.Add(this.codeCommit);
            this.receiveActivity1.Activities.Add(this.setCommitClose);
            this.receiveActivity1.Name = "receiveActivity1";
            activitybind1.Name = "ShoppingCartItemWorkflow";
            activitybind1.Path = "receivedId";
            workflowparameterbinding1.ParameterName = "id";
            workflowparameterbinding1.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            activitybind2.Name = "ShoppingCartItemWorkflow";
            activitybind2.Path = "receivedShoppingCartItem";
            workflowparameterbinding2.ParameterName = "ShoppingCartItem";
            workflowparameterbinding2.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
            activitybind3.Name = "ShoppingCartItemWorkflow";
            activitybind3.Path = "receivedShoppingCartItem";
            workflowparameterbinding3.ParameterName = "(ReturnValue)";
            workflowparameterbinding3.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
            this.receiveActivity1.ParameterBindings.Add(workflowparameterbinding1);
            this.receiveActivity1.ParameterBindings.Add(workflowparameterbinding2);
            this.receiveActivity1.ParameterBindings.Add(workflowparameterbinding3);
            typedoperationinfo1.ContractType = typeof(ShoopingCartWorkflows.IShoppingCartService);
            typedoperationinfo1.Name = "DeleteShoppingCartItem";
            this.receiveActivity1.ServiceOperationInfo = typedoperationinfo1;
            // 
            // setClosedState
            // 
            this.setClosedState.Name = "setClosedState";
            this.setClosedState.TargetStateName = "CartClosed";
            // 
            // delayActivity
            // 
            this.delayActivity.Name = "delayActivity";
            this.delayActivity.TimeoutDuration = System.TimeSpan.Parse("00:05:00");
            // 
            // receiveShoppingCartItemPaid
            // 
            this.receiveShoppingCartItemPaid.Activities.Add(this.codePayShoppingCartItem);
            this.receiveShoppingCartItemPaid.Activities.Add(this.setStateCheckout);
            this.receiveShoppingCartItemPaid.Name = "receiveShoppingCartItemPaid";
            activitybind4.Name = "ShoppingCartItemWorkflow";
            activitybind4.Path = "receivedId";
            workflowparameterbinding4.ParameterName = "id";
            workflowparameterbinding4.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
            activitybind5.Name = "ShoppingCartItemWorkflow";
            activitybind5.Path = "ShoppingCartItemCreditCardPayment";
            workflowparameterbinding5.ParameterName = "CreditCardPayment";
            workflowparameterbinding5.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
            this.receiveShoppingCartItemPaid.ParameterBindings.Add(workflowparameterbinding4);
            this.receiveShoppingCartItemPaid.ParameterBindings.Add(workflowparameterbinding5);
            typedoperationinfo2.ContractType = typeof(ShoopingCartWorkflows.IShoppingCartService);
            typedoperationinfo2.Name = "PayShoppingCartItem";
            this.receiveShoppingCartItemPaid.ServiceOperationInfo = typedoperationinfo2;
            // 
            // receiveShoppingCartItemUpdate
            // 
            this.receiveShoppingCartItemUpdate.Activities.Add(this.codeUpdateShoppingCartItem);
            this.receiveShoppingCartItemUpdate.Activities.Add(this.setShoppingCartItemPlacedFromUpdate);
            this.receiveShoppingCartItemUpdate.Name = "receiveShoppingCartItemUpdate";
            activitybind6.Name = "ShoppingCartItemWorkflow";
            activitybind6.Path = "currentShoppingCartItem";
            workflowparameterbinding6.ParameterName = "(ReturnValue)";
            workflowparameterbinding6.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
            activitybind7.Name = "ShoppingCartItemWorkflow";
            activitybind7.Path = "receivedId";
            workflowparameterbinding7.ParameterName = "id";
            workflowparameterbinding7.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind7)));
            activitybind8.Name = "ShoppingCartItemWorkflow";
            activitybind8.Path = "receivedShoppingCartItem";
            workflowparameterbinding8.ParameterName = "ShoppingCartItem";
            workflowparameterbinding8.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind8)));
            this.receiveShoppingCartItemUpdate.ParameterBindings.Add(workflowparameterbinding6);
            this.receiveShoppingCartItemUpdate.ParameterBindings.Add(workflowparameterbinding7);
            this.receiveShoppingCartItemUpdate.ParameterBindings.Add(workflowparameterbinding8);
            typedoperationinfo3.ContractType = typeof(ShoopingCartWorkflows.IShoppingCartService);
            typedoperationinfo3.Name = "UpdateShoppingCartItem";
            this.receiveShoppingCartItemUpdate.ServiceOperationInfo = typedoperationinfo3;
            // 
            // receiveOnShoppingCartItemPlaced
            // 
            this.receiveOnShoppingCartItemPlaced.Activities.Add(this.OnShoppingCartItemPlacedCode);
            this.receiveOnShoppingCartItemPlaced.Activities.Add(this.setStateActivity1);
            this.receiveOnShoppingCartItemPlaced.CanCreateInstance = true;
            this.receiveOnShoppingCartItemPlaced.Name = "receiveOnShoppingCartItemPlaced";
            activitybind9.Name = "ShoppingCartItemWorkflow";
            activitybind9.Path = "currentShoppingCartItem";
            workflowparameterbinding9.ParameterName = "(ReturnValue)";
            workflowparameterbinding9.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind9)));
            activitybind10.Name = "ShoppingCartItemWorkflow";
            activitybind10.Path = "receivedShoppingCartItem";
            workflowparameterbinding10.ParameterName = "ShoppingCartItem";
            workflowparameterbinding10.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind10)));
            this.receiveOnShoppingCartItemPlaced.ParameterBindings.Add(workflowparameterbinding9);
            this.receiveOnShoppingCartItemPlaced.ParameterBindings.Add(workflowparameterbinding10);
            typedoperationinfo4.ContractType = typeof(ShoopingCartWorkflows.IShoppingCartService);
            typedoperationinfo4.Name = "PlaceShoppingCartItem";
            this.receiveOnShoppingCartItemPlaced.ServiceOperationInfo = typedoperationinfo4;
            // 
            // eventCheckout
            // 
            this.eventCheckout.Activities.Add(this.receiveActivity1);
            this.eventCheckout.Name = "eventCheckout";
            // 
            // eventTimeout
            // 
            this.eventTimeout.Activities.Add(this.delayActivity);
            this.eventTimeout.Activities.Add(this.setClosedState);
            this.eventTimeout.Name = "eventTimeout";
            // 
            // eventItemCrediCardApproved
            // 
            this.eventItemCrediCardApproved.Activities.Add(this.receiveShoppingCartItemPaid);
            this.eventItemCrediCardApproved.Name = "eventItemCrediCardApproved";
            // 
            // eventItemUpdated
            // 
            this.eventItemUpdated.Activities.Add(this.receiveShoppingCartItemUpdate);
            this.eventItemUpdated.Name = "eventItemUpdated";
            // 
            // eventItemAdded
            // 
            this.eventItemAdded.Activities.Add(this.receiveOnShoppingCartItemPlaced);
            this.eventItemAdded.Name = "eventItemAdded";
            // 
            // stateCheckout
            // 
            this.stateCheckout.Activities.Add(this.eventCheckout);
            this.stateCheckout.Name = "stateCheckout";
            // 
            // ItemPlaced
            // 
            this.ItemPlaced.Activities.Add(this.eventItemUpdated);
            this.ItemPlaced.Activities.Add(this.eventItemCrediCardApproved);
            this.ItemPlaced.Activities.Add(this.eventTimeout);
            this.ItemPlaced.Name = "ItemPlaced";
            // 
            // CartClosed
            // 
            this.CartClosed.Name = "CartClosed";
            // 
            // WaitingForShoppingCartItem
            // 
            this.WaitingForShoppingCartItem.Activities.Add(this.eventItemAdded);
            this.WaitingForShoppingCartItem.Name = "WaitingForShoppingCartItem";
            workflowserviceattributes1.ConfigurationName = "ShoopingCartWorkflows.ShoppingCartItemWorkflow";
            workflowserviceattributes1.Name = "ShoppingCartItemWorkflow";
            // 
            // ShoppingCartItemWorkflow
            // 
            this.Activities.Add(this.WaitingForShoppingCartItem);
            this.Activities.Add(this.CartClosed);
            this.Activities.Add(this.ItemPlaced);
            this.Activities.Add(this.stateCheckout);
            this.CompletedStateName = "CartClosed";
            this.DynamicUpdateCondition = null;
            this.InitialStateName = "WaitingForShoppingCartItem";
            this.Name = "ShoppingCartItemWorkflow";
            this.SetValue(System.Workflow.Activities.ReceiveActivity.WorkflowServiceAttributesProperty, workflowserviceattributes1);
            this.CanModifyActivities = false;

        }

        #endregion

        private SetStateActivity setShoppingCartItemPlacedFromUpdate;
        private SetStateActivity setStateActivity1;
        private DelayActivity delayActivity;
        private ReceiveActivity receiveActivity1;
        private EventDrivenActivity eventCheckout;
        private StateActivity stateCheckout;
        private SetStateActivity setCommitClose;
        private CodeActivity codeCommit;
        private SetStateActivity setStateCheckout;
        private SetStateActivity setClosedState;
        private EventDrivenActivity eventTimeout;
        private CodeActivity codePayShoppingCartItem;
        private ReceiveActivity receiveShoppingCartItemPaid;
        private CodeActivity codeUpdateShoppingCartItem;
        private StateActivity ItemPlaced;
        private EventDrivenActivity eventItemUpdated;
        private EventDrivenActivity eventItemCrediCardApproved;
        private ReceiveActivity receiveShoppingCartItemUpdate;
        private StateActivity CartClosed;
        private CodeActivity OnShoppingCartItemPlacedCode;
        private ReceiveActivity receiveOnShoppingCartItemPlaced;
        private EventDrivenActivity eventItemAdded;
        private StateActivity WaitingForShoppingCartItem;



























































































    }
}
