﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using ShoppingCartServiceLibrary;

namespace ShoopingCartWorkflows
{
	[ServiceContract]
	public interface IShoppingCartService
	{
		[OperationContract]
		[WebInvoke(Method="POST", UriTemplate="ShoppingCartItem")]
		ShoppingCartItem PlaceShoppingCartItem(ShoppingCartItem ShoppingCartItem);

		[OperationContract]
		[WebInvoke(Method = "PUT", UriTemplate = "ShoppingCartItem/{id}")]
		ShoppingCartItem UpdateShoppingCartItem(string id, ShoppingCartItem ShoppingCartItem);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "ShoppingCartItem/{id}")]
        ShoppingCartItem DeleteShoppingCartItem(string id, ShoppingCartItem ShoppingCartItem);

		[OperationContract]
		[WebInvoke(Method="PUT", UriTemplate="CreditCardPayment/ShoppingCartItem/{id}")]
		void PayShoppingCartItem(string id, CreditCardPayment CreditCardPayment);
	}
}
