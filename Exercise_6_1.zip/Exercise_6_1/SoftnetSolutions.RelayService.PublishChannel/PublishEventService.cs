using System;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.Text;

namespace SoftnetSolutions.RelayService.PublishChannel
{
    [ServiceBehavior(Name = "PublishEventService",
                    Namespace = "http://SoftnetSolutions.RelayService/",
                    InstanceContextMode = InstanceContextMode.Single)]
    public class PublishEventService : IPublishEventService
    {
        private StringBuilder _messageBuffer = new StringBuilder();

        public void PostMessage(PostData postData)
        {
            _messageBuffer.Append(string.Format("[{0}]:received message - {1}{2}", 
                DateTime.Now.ToString(), 
                postData.Message, 
                Environment.NewLine));
            Console.Write(_messageBuffer.ToString());
        }
    }

    [DataContract]
    public class PostData
    {
        [DataMember]
        public string Message;
    }
}
