using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.ServiceModel;
using Microsoft.ServiceBus.Description;
using System.Configuration;

namespace SoftnetSolutions.RelayService.PublishChannel
{
    using Microsoft.ServiceBus;

    class Program
    {
        private Program(string[] args)
        {
        }

        static void Main(string[] args)
        {
            Program programInstance = new Program(args);
            programInstance.Run();
        }

        private void Run()
        {
            string subject = ConfigurationManager.AppSettings["Topic"];
            string solutionName = ConfigurationManager.AppSettings["Solution"];
            string password = ConfigurationManager.AppSettings["password"];

            PublishEventService service = new PublishEventService();
            RelayPublishEventHost<PublishEventService> _host = new RelayPublishEventHost<PublishEventService>(service,
            subject,
            solutionName,
            password);

            Console.WriteLine(string.Format("{0}--- Connecting success, Press <Enter> to exit ---{0}", Environment.NewLine));

            string input = Console.ReadLine();
            while (input != String.Empty)
            {

                PostData postData = new PostData();
                postData.Message = input;
                _host.Channel.PostMessage(postData);

                input = Console.ReadLine();
            }

            _host.Channel.Close();
        }
    }
}
