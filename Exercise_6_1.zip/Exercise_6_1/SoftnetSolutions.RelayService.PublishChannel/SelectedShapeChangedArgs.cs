﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftnetSolutions.RelayService.PublishChannel
{
    using CSharpBuildingBlocks.EventsHelper;
    using SoftnetSolutions.Shape;

    public class SelectedShapeChangedArgs : EventHelperArgs
    {
        public SHAPE_TYPE Shape { get; set; }

        public SelectedShapeChangedArgs(SHAPE_TYPE shape)
        {
            Shape = shape;
        }

        public override string ToString()
        {
            return Shape.ToString();
        }
    }
}
