﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.ServiceModel;

namespace SoftnetSolutions.RelayService.PublishChannel
{
    using Microsoft.ServiceBus;
    using Microsoft.ServiceBus.Description;

    public class RelayPublishEventHost <T> where T : class 
    {
        protected ChannelFactory<IRelayPublishEventService> _channelFactory = null;
        public string ServiceTitle { get; set; }
        public IRelayPublishEventService Channel { get; set; }

        public RelayPublishEventHost( T serviceImpl,
                                        string topic,
                                        string solutionName, 
                                        string password)
        {
            ServiceBusEnvironment.SystemConnectivity.Mode = ConnectivityMode.AutoDetect;// this.GetConnectivityMode(args);
            TransportClientEndpointBehavior relayCredentials = new TransportClientEndpointBehavior();
            relayCredentials.CredentialType = TransportClientCredentialType.SharedSecret;// UserNamePassword;//CardSpace;// 
            relayCredentials.Credentials.SharedSecret.IssuerName = solutionName;// UserName.UserName = solutionName;
            relayCredentials.Credentials.SharedSecret.IssuerSecret = password;// UserName.Password = password;
            ServiceTitle = topic;

            Uri serviceAddress = ServiceBusEnvironment.CreateServiceUri("sb", 
                                                                        solutionName, 
                                                                        String.Format("{0}/RelayService/", ServiceTitle));
            ServiceHost host = new ServiceHost(serviceImpl.GetType(), serviceAddress);//(service, serviceAddress);
            host.Description.Endpoints[0].Behaviors.Add(relayCredentials);
            host.Open();

            _channelFactory = new ChannelFactory<IRelayPublishEventService>("RelayEndpoint", new EndpointAddress(serviceAddress));
            _channelFactory.Endpoint.Behaviors.Add(relayCredentials);
            Channel = _channelFactory.CreateChannel();
            Channel.Open();
        }

        public RelayPublishEventHost(T serviceImpl,
                                     Uri serviceAddress, 
                                     TransportClientEndpointBehavior relayCredentials)
        {
            ServiceHost host = new ServiceHost(serviceImpl.GetType(), serviceAddress);//(service, serviceAddress);
            host.Description.Endpoints[0].Behaviors.Add(relayCredentials);
            host.Open();

            _channelFactory = new ChannelFactory<IRelayPublishEventService>("RelayEndpoint", new EndpointAddress(serviceAddress));
            _channelFactory.Endpoint.Behaviors.Add(relayCredentials);
            Channel = _channelFactory.CreateChannel();
            Channel.Open();
        }
    }
}
