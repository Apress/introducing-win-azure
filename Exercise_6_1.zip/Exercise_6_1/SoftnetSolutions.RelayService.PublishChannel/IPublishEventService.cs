using System;
using System.ServiceModel;

namespace SoftnetSolutions.RelayService.PublishChannel
{
    [ServiceContract(Name = "IPublishEventService", Namespace = "http://SoftnetSolutions.RelayService/")]
    public interface IPublishEventService
    {
       [OperationContract(IsOneWay = true)]
        void PostMessage(PostData postData);

    }

    public interface IRelayPublishEventService : IPublishEventService, IClientChannel { }
}
