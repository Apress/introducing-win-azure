﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AzureForDotNetDeveloper.Live.MeshClientFacade
{
    using Microsoft.LiveFX.Client;
    using Microsoft.LiveFX.ResourceModel;

    [Serializable]
    public class MeshFeedsFacade : MeshClientFacade
    {
        public string DataFeedsTitle { get; set; }
        protected DataFeed _dataFeed = null;
        private DataEntry _dataEntry = null;

        public MeshFeedsFacade(string liveID,
                                string password)
            : base(liveID, password)
        {
        }

        public MeshFeedsFacade( string liveID,
                                string password,
                                string meshObjectTitle)
            : base(liveID, password, meshObjectTitle)
        {
        }

        public MeshFeedsFacade(string liveID,
                                string password,
                                string meshObjectTitle,
                                string dataFeedsTitle)
            : base(liveID, password, meshObjectTitle)
        {
            DataFeedsTitle = dataFeedsTitle;

            _dataFeed = this[DataFeedsTitle];
            if (_dataFeed == null)
            {
                _dataFeed = new DataFeed(DataFeedsTitle);
                base._meshObject.DataFeeds.Add(ref _dataFeed);
            }
            base._meshObject.Update();
        }

        public Mesh ParentMeshEnvironment { get { return _mesh; } }
        public MeshObject ParentMeshObject { get { return _meshObject; } }

        new public DataFeed this[string dataFeedTitle]
        {
            get
            {
                DataFeed dataFeed = null;
                if (null != _meshObject)
                {
                    dataFeed = base[base.MeshObjectTitle].DataFeeds.Entries.FirstOrDefault(d => d.Resource.Title == dataFeedTitle);
                }

                return dataFeed;
            }
        }

        public void SetUserData<T>(T data)
        {
            try
            {
                if (null != _dataEntry)
                {
                    RemoveDataEntry(_dataEntry);
                }
                _dataEntry = new DataEntry();
                _dataEntry.Resource.SetUserData<T>(data);
                _dataFeed.DataEntries.Add(ref _dataEntry);
                _dataFeed.Update();
                _dataFeed.Load();
                _dataFeed.DataEntries.Load();
            }
            catch { }
        }

        public object GetUserData<T>()
        {
            object o = null;

            try
            {
                DataFeed dataFeed = this[DataFeedsTitle];
                if (null != dataFeed)
                {
                    foreach (DataEntry entry in dataFeed.DataEntries.Entries)
                    {
                        try
                        {
                            o = entry.Resource.GetUserData<T>();
                            if (null == o || string.Empty == o.ToString())
                            {
                                RemoveDataEntry(entry);
                            }
                            else
                            {
                                _dataEntry = entry;
                            }
                            break;
                        }
                        catch { }
                    }
                }
            }
            catch { }

            return o;
        }

        public void DeleteDataFeed(string dataFeedsTitle)
        {
            if (null != _meshObject)
            {
                DataFeed dataFeed = this[dataFeedsTitle];
                if (null != dataFeed)
                {
                    try
                    {
                        _meshObject.DataFeeds.Remove(dataFeed);
                        _meshObject.Update();
                    }
                    catch { }
                }
            }
        }

        public void DumpDataEntries(string dataFeedsTitle)
        {
            _dataFeed.Load();
            if (null != _dataFeed)
            {
                foreach (DataEntry entry in _dataFeed.DataEntries.Entries)
                {
                    _dataFeed.DataEntries.Remove(entry);
                }
                _dataFeed.Update();
            }
        }

        public void RemoveDataEntry(DataEntry datEntry)
        {
            try
            {
                _dataFeed.DataEntries.Remove(datEntry);
                _dataFeed.Update();
                _dataFeed.Load();
            }
            catch { }
        }
    }
}
