﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Runtime.Serialization;

namespace AzureForDotNetDeveloper.Live.MeshClientFacade
{
    using Microsoft.LiveFX.Client;
    using Microsoft.LiveFX.ResourceModel;
    using CSharpBuildingBlocks;

    [Serializable]
    public class MeshClientFacade : ICommand
    {
        protected Mesh _mesh = null;
        protected MeshObject _meshObject = null;
        protected float _percentComplete = 0.0f;
        protected string _liveID = string.Empty;
        protected string _password = string.Empty;
        protected StringBuilder _sbErrorMessage = new StringBuilder();

        public string MeshObjectTitle { get; set; }
        public bool IsConnected { get; set; }
        public int PercentComplete
        {
            get { return (int)_percentComplete; }
        }

        public MeshClientFacade(string liveID,
                                string password)
        {
            _liveID = liveID;
            _password = password;

            _Connect(liveID, password);
        }

        public MeshClientFacade(string liveID,
                                string password,
                                string meshObjectTitle)
            :this(liveID, password)
        {
            MeshObjectTitle = meshObjectTitle;

            _meshObject = this[meshObjectTitle];
            if (null == _meshObject)
            {
                _CreateMeshObject(MeshObjectTitle);
            }
        }

        public Mesh MeshEnvironment { get { return _mesh; } }
        public string ErrorLog { get { return _sbErrorMessage.ToString(); } }

        public void DisplayAllDataEntries(string meshObjectTitle)
        {
            foreach (MeshObject meshObject in _mesh.MeshObjects.Entries)
            {
                if (meshObject.ToString() != meshObjectTitle)
                {
                    continue;
                }
                foreach (DataFeed dataFeed in meshObject.DataFeeds.Entries)
                {
                    foreach (DataEntry dataEntry in dataFeed.DataEntries.Entries)
                    {
                        var data = dataEntry.Resource.GetUserData<string>();
                        System.Diagnostics.Trace.WriteLine(string.Format("---{0}:_DisplayAllDataEntries, meshObject = <{1}>, dataFeed = <{2}>, dataEntry = <{3}>, data=<{4}>{5}",
                                                                        this.ToString(),
                                                                        meshObject.ToString(),
                                                                        dataFeed.ToString(),
                                                                        dataEntry.ToString(),
                                                                        data,
                                                                        Environment.NewLine));
                    }
                }
            }
        }

        public void DeleteResource(string meshObjectTitle)
        {
            MeshObject meshObject = QueryMeshObject(meshObjectTitle);

            if (null != _mesh && null != meshObject)
            {
                _mesh.MeshObjects.Remove(meshObject);
            }
        }

        #region Public Method

        public MeshObject this[string meshObjectTitle]
        {
            get
            {
                return MeshObjectCollection.FirstOrDefault(m => m.Resource.Title == meshObjectTitle);
            }
        }

        public IEnumerable<MeshObject> MeshObjectCollection
        {
            get
            {
                if (null == _mesh)
                {
                    return null;
                }

                return from o in _mesh.CreateQuery<MeshObject>().Execute() select o;
            }
        }

        public IEnumerable<DataEntry> QueryDataEntryCollection(string meshObjectTile, string meshFeedTitle)
        {
            IEnumerable<DataEntry> dataEntryCollection = null;

            if (null != _mesh)
            {

                DataFeed dataFeed = QueryDataFeed(meshObjectTile, meshFeedTitle);
                if (null != dataFeed)
                {
                    dataEntryCollection = from de 
                                          in dataFeed.CreateQuery<DataEntry>().Execute()
                                          select de;
                }
            }

            return dataEntryCollection; 
        }

        public IEnumerable<Mapping> QueryMappingCollection(string meshObjectTitle)
        {
            IEnumerable<Mapping> mappingCollection = null;

            if (null != _mesh)
            {
                MeshObject meshObject = QueryMeshObject(meshObjectTitle);

                if (null != meshObject)
                {
                    mappingCollection = from m
                                        in meshObject.CreateQuery<Mapping>().Execute()
                                        select m;
                }
            }

            return mappingCollection;
        }

        public IEnumerable<Member> QueryMemberCollection(string meshObjectTiltl)
        {
            IEnumerable<Member> memberCollection = null;

            if (null != _mesh)
            {
                MeshObject meshObject = QueryMeshObject(meshObjectTiltl);

                if (null != meshObject)
                {
                    memberCollection = from m
                                       in meshObject.CreateQuery<Member>().Execute()
                                       select m;
                }
            }

            return memberCollection;
        }
        
        public MeshObject QueryMeshObject(string meshObjectTitle)
        {
            if ( null == _mesh )
            {
                return null;
            }

            return (from o in _mesh.CreateQuery<MeshObject>() where o.Resource.Title == meshObjectTitle select o).FirstOrDefault<MeshObject>();
        }

        public DataFeed QueryDataFeed( string meshObjectTitle, 
                                       string meshFeedTitle)
        {
            DataFeed dataFeed = null;

            if (null != _mesh)
            {
                //dataFeed = (from df
                //            in _mesh.CreateQuery<DataFeed>()
                //            where df.Resource.Title == meshFeed
                //            select df).FirstOrDefault<DataFeed>();
                MeshObject meshObj = _mesh.MeshObjects.Entries.FirstOrDefault(m => m.Resource.Title == meshObjectTitle);
                if (null != meshObj)
                {
                    dataFeed = meshObj.DataFeeds.Entries.FirstOrDefault(d => d.Resource.Title == meshFeedTitle);
                }
            }

            return dataFeed;
        }

        public void DumpMeshObject(string meshObjectTitle)
        {
            while(null != QueryMeshObject(meshObjectTitle))
            {
                _RemoveMeshObject(meshObjectTitle);
            }
        }

        protected void _RemoveMeshObject(string meshObjectTitle)
        {
            MeshObject meshObject = QueryMeshObject(meshObjectTitle);

            if (null != _mesh && null != meshObject)
            {
                _mesh.MeshObjects.Remove(meshObject);
            }
        }

        protected MeshObject _CreateMeshObject(string meshObjectTitle)
        {
            _meshObject = QueryMeshObject(meshObjectTitle);

            if (null == _meshObject)
            {
                _meshObject = new MeshObject(meshObjectTitle);
                //_meshObject.Resource.Type = _meshObject.Resource.Title = meshObjectTitle;
                //When a new MeshObject been created a new mapping must be created across all mesh devices, otherwise the dat can not 
                //be synchronous across all mesh device properly
                try
                {
                    foreach (MeshDevice device in _mesh.Devices.Entries)
                    {
                        Mapping mapping = new Mapping();
                        mapping.Device = device;
                        _meshObject.Mappings.Add(ref mapping);
                    }
                    _meshObject.Update();
                }
                catch { }

                _mesh.MeshObjects.Add(ref _meshObject);
            }
            else
            {
                _sbErrorMessage.Append(string.Format("[{0}]:The mesh objec <{1}> is already existed, create skipped.{2}",
                    DateTime.Now.ToString(),
                    meshObjectTitle,
                    Environment.NewLine));
            }

            return _meshObject;
        }


        public static DataFeed FindDataFeed( MeshObject parent, 
                                             string dataFeedTitle)
        {
            var query1 = from coreObject in parent.CreateQuery<DataFeed>()
                         where coreObject.Resource.Title == dataFeedTitle
                         select coreObject;
            var dataFeed = query1.FirstOrDefault<DataFeed>();
            return dataFeed;
        }

        #endregion

        #region ICommand implementation

        public void Execute()
        {
            _Connect(_liveID, _password);
        }

        #endregion

        #region Private Method

        protected void _Connect(string liveID, 
                              string password)
        {
            string errorMessage = string.Empty;
            string strUri = "https://user-ctp.windows.net/";
            NetworkCredential networkCredential = new NetworkCredential(liveID,
                                                              password,
                                                              strUri);

            try
            {
                LiveOperatingEnvironment liveOperationEnvironment = new LiveOperatingEnvironment();
                LiveItemAccessOptions liveItemAccessOptions = new LiveItemAccessOptions(true);
                string authenticationToken = networkCredential.GetWindowsLiveAuthenticationToken();
                //authenticationToken = Encoding.UTF8.GetString(Convert.FromBase64String(authenticationToken));
                Uri uri = new Uri(strUri);
                liveOperationEnvironment.Connect(authenticationToken,
                                                  AuthenticationTokenType.UserToken,
                                                  uri,
                                                  liveItemAccessOptions);
                _mesh = liveOperationEnvironment.Mesh;

                IsConnected = true;
                _percentComplete = 100.0f;
            }
            catch (Exception ex)
            {
                _sbErrorMessage.Append(string.Format("[{0}]:exception caught from connecting to mesh. {1}{2}", 
                    DateTime.Now.ToString(), 
                    ex.Message,
                    Environment.NewLine));
                IsConnected = false;
            }
        }

        #endregion
    }
}
