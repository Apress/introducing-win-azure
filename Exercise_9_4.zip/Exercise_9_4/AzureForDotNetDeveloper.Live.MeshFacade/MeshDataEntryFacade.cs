﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AzureForDotNetDeveloper.Live.MeshClientFacade
{
    using Microsoft.LiveFX.Client;
    using Microsoft.LiveFX.ResourceModel;
    using Microsoft.Web;

    [Serializable]
    public class MeshDataEntryFacade : MeshFeedsFacade
    {
        public string DataEntryTitle { get; set; }
        public DataEntry _dataEntry = null;
        public MeshDataEntryFacade(string liveID,
                                string password)
            : base(liveID, password)
        {
        }

        public MeshDataEntryFacade( string liveID,
                                string password,
                                string meshObjectTitle)
            : base(liveID, password, meshObjectTitle)
        {
        }

        public MeshDataEntryFacade(string liveID,
                                string password,
                                string meshObjectTitle,
                                string dataFeedsTitle,
                                string dataEntryTitle)
            : base(liveID, password, meshObjectTitle, dataFeedsTitle)
        {
            DataEntryTitle = dataEntryTitle;

            _dataEntry = this[DataEntryTitle];
            if (null == _dataEntry)
            {
                _dataEntry = new DataEntry(dataEntryTitle);
            }
        }

        public DataFeed ParentFeed { get { return _dataFeed; } }
        new public DataEntry this[string dataEntryTitle]
        {
            get
            {
                DataEntry dataEntry = null;

                if (null != _dataFeed)
                {
                    dataEntry = _dataFeed.DataEntries.Entries.FirstOrDefault(d => d.Resource.Title == dataEntryTitle);
                }

                return dataEntry;
            }
        }

        public void SetUserData<T>(T data)
        {
            _dataEntry.Resource.SetUserData<T>(data);
        }

        public object GetUserData<T>()
        {
            object o = null;
            try
            {
                o = _dataEntry.Resource.GetUserData<T>();

            }
            catch { }
            return o;
        }
    }
}
