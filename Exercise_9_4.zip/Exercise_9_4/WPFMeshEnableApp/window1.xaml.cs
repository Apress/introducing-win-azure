﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Configuration;
using System.ComponentModel;

namespace WPFMeshEnableApp
{
    using Microsoft.LiveFX.Client;
    using Microsoft.LiveFX.ResourceModel;
    using AzureForDotNetDeveloper.Live.MeshClientFacade;
    using CSharpBuildingBlocks;
    using CSharpBuildingBlocks.QueuedBackgroundWorker;
    using CSharpBuildingBlocks.EventsHelper;

    /// <summary>
    /// Interaction logic for FunToyWindow.xaml
    /// </summary>
    public partial class FunToyWindow : Window
    {
        const string SNAPSHOT_FEED = "SnapshotDataFeed";
        const string SNAPSHOT_DATAENTRY = "SnapshotDataEntry";
        private string _meshObjectTile = ConfigurationManager.AppSettings["MeshObjectTitle"];//"SilverlightMeshEnableApp";
        private double _sliderValue = 100.0;

        private ICommand _meshFacade = null;
        private QueuedBackgroundWorkeComponent _backgroundWorkeComponent = null;
        private bool _dumpExistingMeshObjects = Convert.ToBoolean(ConfigurationManager.AppSettings["DumpExistingSnapshotMeshObject"]);

        public FunToyWindow()
        {
            InitializeComponent();
            this._backgroundWorkeComponent = new QueuedBackgroundWorkeComponent();
            this._backgroundWorkeComponent.DoWork += new System.ComponentModel.DoWorkEventHandler(this._backgroundWorker_DoWork);
            this._backgroundWorkeComponent.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this._backgroundWorker_RunWorkerCompleted);
            this._backgroundWorkeComponent.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this._backgroundWorkeComponent_ProgressChanged);
        }

        private void _StartUpdateTimer(object o, RoutedEventArgs sender)
        {
            System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
            dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 1);
            dispatcherTimer.Tick += new EventHandler(_timer_Tick);
            dispatcherTimer.Start();
        }

        private void _timer_Tick(object o, EventArgs sender)
        {
            if (Button_RotateTransform.Angle >= 359)
            {
                Button_RotateTransform.Angle = 0;
            }
            else
            {
                Button_RotateTransform.Angle += 10;
            }
        }

        private void _UpdateUI()
        {
            if (null != _meshFacade)
            {
                object feedValue = (_meshFacade as MeshFeedsFacade).GetUserData<double>();
                if (null != feedValue)
                {
                    _sliderValue = (double)feedValue;
                    txtFeedValue.Text = ((int)_sliderValue).ToString();
                }
            }
            _slider.Value = (int)_sliderValue;
            Buntton_Value.Height = (int)(_sliderValue * 1.5);
            Buntton_Value.Width = (int)(_sliderValue * 1.5);
            txtSliderValue.Text  = ((int)_sliderValue).ToString();
        }

        private void _slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            _sliderValue = e.NewValue;

            Button_RotateTransform.CenterX = (int)(_sliderValue * 0.75);
            Button_RotateTransform.CenterY = (int)(_sliderValue * 0.75);

            _UpdateUI();
        }


        private void txtMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (null == _meshFacade)
            {
                return;
            }

            if (e.Key == Key.Return)
            {
                string s = txtFeedValue.Text.Trim();
                bool valid = false;

                if (null != s)
                {
                    if (string.Empty != s)
                    {
                        txtErrorMessage.Text = string.Empty;
                        if (_IsValidKeyStroke(s))
                        {
                            double feedValue = -0.1;
                            try
                            {
                                feedValue = double.Parse(s);
                            }
                            catch { }
                            if (0.0 <= feedValue && feedValue <= 100.0)
                            {
                                (_meshFacade as MeshFeedsFacade).SetUserData<double>(feedValue);
                                valid = true;
                            }
                        }
                        if (!valid)
                        {
                            txtErrorMessage.Text = "* Expected Data Range: [0 - 100]";
                            txtFeedValue.Text = string.Empty;
                        }
                    }
                    else
                    {
                        (_meshFacade as MeshFeedsFacade).SetUserData<string>(string.Empty);
                    }
                }
            }
        }

        private void txtMessage_TextChanged(object sender, TextChangedEventArgs e)
        {
        }

        private bool _IsValidKeyStroke(string key)
        {
            const string VALID_KEY_CHAR_PATTERN = @"([0-9])";
            bool isValid = false;
            Match match = null;

            Regex regEx = new Regex(VALID_KEY_CHAR_PATTERN,
                                        RegexOptions.CultureInvariant
                                        | RegexOptions.IgnorePatternWhitespace);

            match = regEx.Match(key.ToString());

            if (null != match && match.Success)
            {
                isValid = true;
            }

            return isValid;
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                btnConnect_Click(null, null);
            }
        }

        private void btnConnect_Click(object sender, RoutedEventArgs e)
        {
            if (null == _meshFacade)
            {
                txtButtonText.Text = "Connecting ...";
                UpdateLayout();

                string liveID = ConfigurationManager.AppSettings["LiveID"];
                string password = txtPassword.Password;
                string message = string.Empty;

                if (liveID == string.Empty || password == string.Empty)
                {
                    message = "Please Enter the password.";
                    _UpdateStatus(message);
                    return;
                }

                _UpdateStatus(string.Empty);

                _meshFacade = new MeshFeedsFacade(liveID,
                                                  password,
                                                  _meshObjectTile,
                                                  SNAPSHOT_FEED);
                _backgroundWorkeComponent._QueuedBackgroundWorker.RunWorkerAsync(_meshFacade);
            }
        }

        private void _UpdateStatus(string message)
        {
            txtErrorMessage.Text = message;
        }

        #region QueuedBackgroundWorker Handler

        private void _backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {

            if (e.Argument is MeshClientFacade)
            {
                _meshFacade = (MeshClientFacade)e.Argument;
            }

            if (null != _meshFacade)
            {
                while (!_backgroundWorkeComponent._QueuedBackgroundWorker.IsCancellationPending(_meshFacade)
                    && _meshFacade.PercentComplete < 100)
                {
                    _backgroundWorkeComponent._QueuedBackgroundWorker.ReportProgress(_meshFacade.PercentComplete, _meshFacade);
                    _meshFacade.Execute();
                    e.Result = _meshFacade;
                }
            }
        }

        private void _backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            txtButtonText.Text = "Connected";
            (_meshFacade as MeshFeedsFacade)[SNAPSHOT_FEED].DataEntries.ChangeNotificationReceived += new EventHandler(DataEntries_ChangeNotificationReceived);
#if UNITEST
            _meshFacade.SetUserData<string>(string.Empty);
            object o = _meshFacade.GetUserData<double>();
            if (_dumpExistingMeshObjects)
            {
                (_meshFacade as MeshClientFacade).DumpMeshObject(SNAPSHOT_MESH_OBJECT);
                _dumpExistingMeshObjects = false;
                _meshFacade = null;
                btnConnect_Click(null, null);
            }
#endif
       }

        private void _backgroundWorkeComponent_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
        }

        private void DataEntries_ChangeNotificationReceived(object o, EventArgs args)
        {
            _UpdateUI();
        }
        #endregion
    }
}
