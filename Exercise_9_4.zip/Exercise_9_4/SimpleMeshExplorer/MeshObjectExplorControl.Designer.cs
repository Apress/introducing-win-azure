﻿namespace SimpleMeshExplorer
{
    partial class MeshObjectExplorControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBoxDataEntries = new System.Windows.Forms.GroupBox();
            this.btnDataEntryDelete = new System.Windows.Forms.Button();
            this.btnDataEntryAdd = new System.Windows.Forms.Button();
            this.txtDataEntry = new System.Windows.Forms.TextBox();
            this.listBoxDataEntries = new System.Windows.Forms.ListBox();
            this.groupBoxDataFeeds = new System.Windows.Forms.GroupBox();
            this.btnDataFeedDelete = new System.Windows.Forms.Button();
            this.btnAddDataFeeds = new System.Windows.Forms.Button();
            this.txtDataFeeds = new System.Windows.Forms.TextBox();
            this.listBoxDataFeeds = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.groupBoxDataEntries.SuspendLayout();
            this.groupBoxDataFeeds.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBoxDataEntries);
            this.panel1.Controls.Add(this.groupBoxDataFeeds);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(599, 106);
            this.panel1.TabIndex = 0;
            // 
            // groupBoxDataEntries
            // 
            this.groupBoxDataEntries.Controls.Add(this.btnDataEntryDelete);
            this.groupBoxDataEntries.Controls.Add(this.btnDataEntryAdd);
            this.groupBoxDataEntries.Controls.Add(this.txtDataEntry);
            this.groupBoxDataEntries.Controls.Add(this.listBoxDataEntries);
            this.groupBoxDataEntries.Location = new System.Drawing.Point(296, 3);
            this.groupBoxDataEntries.Name = "groupBoxDataEntries";
            this.groupBoxDataEntries.Size = new System.Drawing.Size(300, 100);
            this.groupBoxDataEntries.TabIndex = 1;
            this.groupBoxDataEntries.TabStop = false;
            this.groupBoxDataEntries.Text = "DataEntries";
            // 
            // btnDataEntryDelete
            // 
            this.btnDataEntryDelete.Location = new System.Drawing.Point(195, 70);
            this.btnDataEntryDelete.Name = "btnDataEntryDelete";
            this.btnDataEntryDelete.Size = new System.Drawing.Size(96, 23);
            this.btnDataEntryDelete.TabIndex = 7;
            this.btnDataEntryDelete.Text = "D&elete";
            this.btnDataEntryDelete.UseVisualStyleBackColor = true;
            this.btnDataEntryDelete.Click += new System.EventHandler(this.btnDataEntryDelete_Click);
            // 
            // btnDataEntryAdd
            // 
            this.btnDataEntryAdd.Enabled = false;
            this.btnDataEntryAdd.Location = new System.Drawing.Point(195, 40);
            this.btnDataEntryAdd.Name = "btnDataEntryAdd";
            this.btnDataEntryAdd.Size = new System.Drawing.Size(96, 23);
            this.btnDataEntryAdd.TabIndex = 6;
            this.btnDataEntryAdd.Text = "A&dd";
            this.btnDataEntryAdd.UseVisualStyleBackColor = true;
            this.btnDataEntryAdd.Click += new System.EventHandler(this.btnDataEntryAdd_Click);
            // 
            // txtDataEntry
            // 
            this.txtDataEntry.Location = new System.Drawing.Point(192, 10);
            this.txtDataEntry.Name = "txtDataEntry";
            this.txtDataEntry.Size = new System.Drawing.Size(100, 20);
            this.txtDataEntry.TabIndex = 5;
            // 
            // listBoxDataEntries
            // 
            this.listBoxDataEntries.FormattingEnabled = true;
            this.listBoxDataEntries.Location = new System.Drawing.Point(12, 14);
            this.listBoxDataEntries.Name = "listBoxDataEntries";
            this.listBoxDataEntries.Size = new System.Drawing.Size(177, 82);
            this.listBoxDataEntries.TabIndex = 4;
            this.listBoxDataEntries.SelectedIndexChanged += new System.EventHandler(this.listBoxDataEntries_SelectedIndexChanged);
            // 
            // groupBoxDataFeeds
            // 
            this.groupBoxDataFeeds.Controls.Add(this.btnDataFeedDelete);
            this.groupBoxDataFeeds.Controls.Add(this.btnAddDataFeeds);
            this.groupBoxDataFeeds.Controls.Add(this.txtDataFeeds);
            this.groupBoxDataFeeds.Controls.Add(this.listBoxDataFeeds);
            this.groupBoxDataFeeds.Location = new System.Drawing.Point(3, 3);
            this.groupBoxDataFeeds.Name = "groupBoxDataFeeds";
            this.groupBoxDataFeeds.Size = new System.Drawing.Size(287, 100);
            this.groupBoxDataFeeds.TabIndex = 0;
            this.groupBoxDataFeeds.TabStop = false;
            this.groupBoxDataFeeds.Text = "DataFeeds";
            // 
            // btnDataFeedDelete
            // 
            this.btnDataFeedDelete.Location = new System.Drawing.Point(185, 72);
            this.btnDataFeedDelete.Name = "btnDataFeedDelete";
            this.btnDataFeedDelete.Size = new System.Drawing.Size(96, 23);
            this.btnDataFeedDelete.TabIndex = 3;
            this.btnDataFeedDelete.Text = "&Delete";
            this.btnDataFeedDelete.UseVisualStyleBackColor = true;
            this.btnDataFeedDelete.Click += new System.EventHandler(this.btnDataFeedDelete_Click);
            // 
            // btnAddDataFeeds
            // 
            this.btnAddDataFeeds.Enabled = false;
            this.btnAddDataFeeds.Location = new System.Drawing.Point(185, 42);
            this.btnAddDataFeeds.Name = "btnAddDataFeeds";
            this.btnAddDataFeeds.Size = new System.Drawing.Size(96, 23);
            this.btnAddDataFeeds.TabIndex = 2;
            this.btnAddDataFeeds.Text = "&Add";
            this.btnAddDataFeeds.UseVisualStyleBackColor = true;
            this.btnAddDataFeeds.Click += new System.EventHandler(this.btnAddDataFeeds_Click);
            // 
            // txtDataFeeds
            // 
            this.txtDataFeeds.Location = new System.Drawing.Point(182, 15);
            this.txtDataFeeds.Name = "txtDataFeeds";
            this.txtDataFeeds.Size = new System.Drawing.Size(100, 20);
            this.txtDataFeeds.TabIndex = 1;
            // 
            // listBoxDataFeeds
            // 
            this.listBoxDataFeeds.FormattingEnabled = true;
            this.listBoxDataFeeds.Location = new System.Drawing.Point(6, 14);
            this.listBoxDataFeeds.Name = "listBoxDataFeeds";
            this.listBoxDataFeeds.Size = new System.Drawing.Size(172, 82);
            this.listBoxDataFeeds.TabIndex = 0;
            this.listBoxDataFeeds.SelectedIndexChanged += new System.EventHandler(this.listBoxDataFeeds_SelectedIndexChanged);
            // 
            // MeshObjectExplorControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "MeshObjectExplorControl";
            this.Size = new System.Drawing.Size(605, 112);
            this.panel1.ResumeLayout(false);
            this.groupBoxDataEntries.ResumeLayout(false);
            this.groupBoxDataEntries.PerformLayout();
            this.groupBoxDataFeeds.ResumeLayout(false);
            this.groupBoxDataFeeds.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBoxDataEntries;
        private System.Windows.Forms.GroupBox groupBoxDataFeeds;
        private System.Windows.Forms.ListBox listBoxDataFeeds;
        private System.Windows.Forms.Button btnDataEntryDelete;
        private System.Windows.Forms.Button btnDataEntryAdd;
        private System.Windows.Forms.TextBox txtDataEntry;
        private System.Windows.Forms.ListBox listBoxDataEntries;
        private System.Windows.Forms.Button btnDataFeedDelete;
        private System.Windows.Forms.Button btnAddDataFeeds;
        private System.Windows.Forms.TextBox txtDataFeeds;
    }
}
