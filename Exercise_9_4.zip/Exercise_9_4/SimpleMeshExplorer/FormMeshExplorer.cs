﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Runtime.Serialization;
using System.Resources;
using System.IO;

namespace SimpleMeshExplorer
{
    using Microsoft.LiveFX.Client;
    using Microsoft.LiveFX.ResourceModel;
    using AzureForDotNetDeveloper.Live.MeshClientFacade;
    using CSharpBuildingBlocks;
    using CSharpBuildingBlocks.QueuedBackgroundWorker;
    using CSharpBuildingBlocks.EventsHelper;

    public partial class FormMeshExplorer : Form
    {
        private ICommand _meshFacade = null;
        //private FileInfo _fileInfo = null;
        private QueuedBackgroundWorkeComponent _backgroundWorkeComponent = null;
        const string MESH_EXPLOR_PAGE = "MeshObjectExplorer";
        private MeshObjectExplorControl _meshObjectExplorControl = null;
       private TabPage _pageExplor = null;


        public FormMeshExplorer()
        {
            InitializeComponent();
            this._backgroundWorkeComponent = new QueuedBackgroundWorkeComponent();
            this._backgroundWorkeComponent.DoWork += new System.ComponentModel.DoWorkEventHandler(this._backgroundWorker_DoWork);
            this._backgroundWorkeComponent.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this._backgroundWorker_RunWorkerCompleted);
            this._backgroundWorkeComponent.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this._backgroundWorkeComponent_ProgressChanged);
        }

        public void UpdateStatus(string message, bool error)
        {
            if (!error)
            {
                statusStrip1.ForeColor = Color.Black;
            }
            else
            {
                statusStrip1.ForeColor = Color.Red;
            }
            toolStripStatusLabel1.Text = message;
       }

        private void FormMeshExplorer_Load(object sender, EventArgs e)
        {
            this.webBrowser.Url = new Uri(@"https://developer.mesh-ctp.com/Web/Desktop.aspx");
            _UpdateUI();
        }

        private void _UpdateUI()
        {
            listBoxMeshResources.Enabled = _meshFacade == null ? false : true;
            btnDelete.Enabled = listBoxMeshResources.Items.Count > 0 ? true : false;

            if ( null == _meshFacade)
            {
                return;
            }

            IEnumerable<MeshObject> meshObjects = (_meshFacade as MeshClientFacade).MeshObjectCollection;
            if (null != meshObjects 
                && meshObjects.Count<MeshObject>() != listBoxMeshResources.Items.Count)
            {
                if (meshObjects.Count<MeshObject>() > 0)
                {
                    _RefreshListBox(meshObjects);
                }
                else
                {
                    listBoxMeshResources.Items.Clear();
                }
            }

            //if (null != listBoxMeshResources.SelectedItem)
            //{
            //    string meshObjectTitle = listBoxMeshResources.SelectedItem.ToString();
            //    if ((_meshFacade as MeshClientFacade).IsConnected)
            //    {
            //        IEnumerable<DataEntry> dataEntityCollection = (_meshFacade as MeshClientFacade).QueryDataEntryCollection(meshObjectTitle);
            //        IEnumerable<Mapping> mappingCollection = (_meshFacade as MeshClientFacade).QueryMappingCollection(meshObjectTitle);
            //        IEnumerable<Member> memberCollection = (_meshFacade as MeshClientFacade).QueryMemberCollection(meshObjectTitle);
            //    }
            //}
        }

        private void _RefreshListBox(IEnumerable<MeshObject> meshObjects)
        {
            int selectedIndex = 0;
            int index = 0;
            string currentSelectedTitle = string.Empty;

            if (listBoxMeshResources.Items.Count > 0
                && null != listBoxMeshResources.SelectedItem)
            {
                currentSelectedTitle = listBoxMeshResources.SelectedItem.ToString();
            }

            listBoxMeshResources.Items.Clear();
            foreach (MeshObject meshObj in meshObjects)
            {
                ++index;
                if (currentSelectedTitle == meshObj.Resource.Title)
                {
                    selectedIndex = index;
                }
                listBoxMeshResources.Items.Add(meshObj.Resource.Title);
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (null == _meshFacade)
            {
                string liveID = txtLiveID.Text.Trim();
                string password = txtPassword.Text.Trim();
                string message = string.Empty;
                bool error = false;

                if (liveID == string.Empty || password == string.Empty)
                {
                    message = "Please enter the live ID and password.";
                    error = true;
                    UpdateStatus(message, error);
                    return;
                }

                UpdateStatus(string.Empty, false);

                _meshFacade = new MeshClientFacade(liveID, password);
                btnConnect.Enabled = false;
                _backgroundWorkeComponent._QueuedBackgroundWorker.RunWorkerAsync(_meshFacade);
            }
        }

        private void timerUpdate_Tick(object sender, EventArgs e)
        {
            _UpdateUI();
        }

        #if Extended
        private void btnCreate_Click(object sender, EventArgs e)
        {
            UpdateStatus(string.Empty, false);

            string meshObjectTitile = txtCreateMeshObjectTile.Text.Trim();

            if (string.Empty == meshObjectTitile)
            {
                UpdateStatus("Please enter the title of the mesh object.", true);
                return;
            }

            MeshObject meshObject = (_meshFacade as MeshClientFacade).QueryMeshObject(meshObjectTitile);
            if (null != meshObject)
            {
                UpdateStatus(string.Format("The mesh object is already existed or the title <{0}> is alread used.", 
                             meshObjectTitile), 
                             true);
                return;
            }

            (_meshFacade as MeshClientFacade).CreateResource(meshObjectTitile, MESH_RESOURCE_TYPE.IMAGE);

        }

        private void _pickFile_Click(object sender, EventArgs e)
        {
            if (_openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileToUpload = _openFileDialog.FileNames[0];
                _fileInfo = new FileInfo(fileToUpload);
                lableFileName.Text = fileToUpload;
            }
        }

        #endif

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnConnect_Click(this, null);
            }
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            string message = "Please select the resource title of the mesh object.";

            if (null != listBoxMeshResources.SelectedItem)
            {
                string selectedMeshResourceTitle = listBoxMeshResources.SelectedItem.ToString().Trim();
                if (string.Empty != selectedMeshResourceTitle)
                {
                    (_meshFacade as MeshClientFacade).DeleteResource(selectedMeshResourceTitle);
                    message = string.Empty;
                }
            }


            UpdateStatus(message, string.Empty != message );

        }

        #region QueuedBackgroundWorker Handler

        private void _backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            Application.DoEvents();

            if (e.Argument is MeshClientFacade)
            {
                _meshFacade = (MeshClientFacade)e.Argument;
            }

            if (null != _meshFacade)
            {
                while (!_backgroundWorkeComponent._QueuedBackgroundWorker.IsCancellationPending(_meshFacade)
                    && _meshFacade.PercentComplete < 100)
                {
                    _backgroundWorkeComponent._QueuedBackgroundWorker.ReportProgress(_meshFacade.PercentComplete, _meshFacade);
                    _meshFacade.Execute();
                    e.Result = _meshFacade;
                }
            }
        }

        private void _backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            timerUpdate.Enabled = true;
            toolStripProgressBar.Visible = false;
            btnConnect.Enabled = true;
            btnExplor.Enabled = true;
            btnConnect.Text = "Connected";
        }

        private void _backgroundWorkeComponent_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //_progressBar.Value = e.ProgressPercentage;
            toolStripProgressBar.Visible = true;
            Update();
            Application.DoEvents();
        }

        #endregion

        private void _AddExplorPage(MeshObject meshObj)
        {
            if (_IsPageExisted(MESH_EXPLOR_PAGE))
            {
                tabControlExplor.TabPages.Remove(_pageExplor);
            }

            _meshObjectExplorControl = new MeshObjectExplorControl(meshObj);

            if (null != _meshObjectExplorControl)
            {
                _pageExplor = new TabPage(MESH_EXPLOR_PAGE);

                _pageExplor.Controls.Add(_meshObjectExplorControl);
                _meshObjectExplorControl.Dock = DockStyle.Fill;

                tabControlExplor.TabPages.Add(_pageExplor);
            }
        }

        private bool _IsPageExisted(string pageKey)
        {
            bool existed = false;

            foreach (TabPage page in this.tabControlExplor.TabPages)
            {
                if (page.Text == pageKey)
                {
                    existed = true;
                    break;
                }
            }

            return existed;
        }

        private void btnExplor_Click(object sender, EventArgs e)
        {
            string message = "Please select the resource title of the mesh object.";

            if (null != listBoxMeshResources.SelectedItem)
            {
                string selectedMeshResourceTitle = listBoxMeshResources.SelectedItem.ToString().Trim();
                if (string.Empty != selectedMeshResourceTitle)
                {
                    //(_meshFacade as MeshClientFacade).DeleteResource(selectedMeshResourceTitle);
                    MeshObject meshObj = (this._meshFacade as MeshClientFacade).MeshObjectCollection.FirstOrDefault(m => m.Resource.Title == selectedMeshResourceTitle);
                    if (meshObj != null)
                    {
                        _AddExplorPage(meshObj);
                        tabControlExplor.SelectedTab = _pageExplor;
                    }

                    message = string.Empty;
                }
            }

            UpdateStatus(message, string.Empty != message);
        }

        private void tabControlExplor_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (null != _pageExplor && tabControlExplor.SelectedTab != _pageExplor)
            {
                if (_IsPageExisted(MESH_EXPLOR_PAGE))
                {
                    tabControlExplor.TabPages.Remove(_pageExplor);
                }
            }
        }
    }
}
