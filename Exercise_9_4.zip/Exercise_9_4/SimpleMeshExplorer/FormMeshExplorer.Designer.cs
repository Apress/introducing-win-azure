﻿namespace SimpleMeshExplorer
{
    partial class FormMeshExplorer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMeshExplorer));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPageLiveLogin = new System.Windows.Forms.TabPage();
            this.webBrowser = new System.Windows.Forms.WebBrowser();
            this.txtMeshObjectTile = new System.Windows.Forms.TextBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this._pickFile = new System.Windows.Forms.Button();
            this.lableFileName = new System.Windows.Forms.Label();
            this.tabControlExplor = new System.Windows.Forms.TabControl();
            this.tabPageLogin = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.listBoxMeshResources = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnExplor = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtLiveID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timerUpdate = new System.Windows.Forms.Timer(this.components);
            this._openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.statusStrip1.SuspendLayout();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabPageLiveLogin.SuspendLayout();
            this.tabControlExplor.SuspendLayout();
            this.tabPageLogin.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripProgressBar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 618);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(630, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(615, 17);
            this.toolStripStatusLabel1.Spring = true;
            this.toolStripStatusLabel1.Text = "Ready";
            this.toolStripStatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            this.toolStripProgressBar.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.toolStripProgressBar.Visible = false;
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.tabControl);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.tabControlExplor);
            this.splitContainer.Size = new System.Drawing.Size(630, 618);
            this.splitContainer.SplitterDistance = 465;
            this.splitContainer.TabIndex = 1;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPageLiveLogin);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(630, 465);
            this.tabControl.TabIndex = 0;
            // 
            // tabPageLiveLogin
            // 
            this.tabPageLiveLogin.Controls.Add(this.webBrowser);
            this.tabPageLiveLogin.Controls.Add(this.txtMeshObjectTile);
            this.tabPageLiveLogin.Controls.Add(this.btnCreate);
            this.tabPageLiveLogin.Controls.Add(this._pickFile);
            this.tabPageLiveLogin.Controls.Add(this.lableFileName);
            this.tabPageLiveLogin.Location = new System.Drawing.Point(4, 22);
            this.tabPageLiveLogin.Name = "tabPageLiveLogin";
            this.tabPageLiveLogin.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLiveLogin.Size = new System.Drawing.Size(622, 439);
            this.tabPageLiveLogin.TabIndex = 0;
            this.tabPageLiveLogin.Text = "Live Login";
            this.tabPageLiveLogin.UseVisualStyleBackColor = true;
            // 
            // webBrowser
            // 
            this.webBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser.Location = new System.Drawing.Point(3, 3);
            this.webBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.Size = new System.Drawing.Size(616, 433);
            this.webBrowser.TabIndex = 14;
            this.webBrowser.Url = new System.Uri("https://developer.mesh-ctp.com/Web/Desktop.aspx", System.UriKind.Absolute);
            // 
            // txtMeshObjectTile
            // 
            this.txtMeshObjectTile.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMeshObjectTile.Location = new System.Drawing.Point(338, 386);
            this.txtMeshObjectTile.Name = "txtMeshObjectTile";
            this.txtMeshObjectTile.Size = new System.Drawing.Size(93, 20);
            this.txtMeshObjectTile.TabIndex = 10;
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(442, 355);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(77, 23);
            this.btnCreate.TabIndex = 11;
            this.btnCreate.Text = "Cre&ate";
            this.btnCreate.UseVisualStyleBackColor = true;
            // 
            // _pickFile
            // 
            this._pickFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._pickFile.Location = new System.Drawing.Point(280, 355);
            this._pickFile.Name = "_pickFile";
            this._pickFile.Size = new System.Drawing.Size(28, 23);
            this._pickFile.TabIndex = 12;
            this._pickFile.Text = "...";
            this._pickFile.UseVisualStyleBackColor = true;
            // 
            // lableFileName
            // 
            this.lableFileName.AutoSize = true;
            this.lableFileName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lableFileName.Location = new System.Drawing.Point(338, 355);
            this.lableFileName.Name = "lableFileName";
            this.lableFileName.Size = new System.Drawing.Size(2, 15);
            this.lableFileName.TabIndex = 13;
            // 
            // tabControlExplor
            // 
            this.tabControlExplor.Controls.Add(this.tabPageLogin);
            this.tabControlExplor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlExplor.Location = new System.Drawing.Point(0, 0);
            this.tabControlExplor.Name = "tabControlExplor";
            this.tabControlExplor.SelectedIndex = 0;
            this.tabControlExplor.Size = new System.Drawing.Size(630, 149);
            this.tabControlExplor.TabIndex = 0;
            this.tabControlExplor.SelectedIndexChanged += new System.EventHandler(this.tabControlExplor_SelectedIndexChanged);
            // 
            // tabPageLogin
            // 
            this.tabPageLogin.Controls.Add(this.tableLayoutPanel1);
            this.tabPageLogin.Location = new System.Drawing.Point(4, 22);
            this.tabPageLogin.Name = "tabPageLogin";
            this.tabPageLogin.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLogin.Size = new System.Drawing.Size(622, 123);
            this.tabPageLogin.TabIndex = 0;
            this.tabPageLogin.Text = "Login";
            this.tabPageLogin.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.87302F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.12698F));
            this.tableLayoutPanel1.Controls.Add(this.listBoxMeshResources, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(616, 117);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // listBoxMeshResources
            // 
            this.listBoxMeshResources.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxMeshResources.Enabled = false;
            this.listBoxMeshResources.FormattingEnabled = true;
            this.listBoxMeshResources.Location = new System.Drawing.Point(347, 3);
            this.listBoxMeshResources.Name = "listBoxMeshResources";
            this.listBoxMeshResources.Size = new System.Drawing.Size(266, 108);
            this.listBoxMeshResources.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnExplor);
            this.panel1.Controls.Add(this.btnDelete);
            this.panel1.Controls.Add(this.btnConnect);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtPassword);
            this.panel1.Controls.Add(this.txtLiveID);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 111);
            this.panel1.TabIndex = 11;
            // 
            // btnExplor
            // 
            this.btnExplor.Enabled = false;
            this.btnExplor.Location = new System.Drawing.Point(226, 80);
            this.btnExplor.Name = "btnExplor";
            this.btnExplor.Size = new System.Drawing.Size(102, 23);
            this.btnExplor.TabIndex = 16;
            this.btnExplor.Text = "&Explorer...";
            this.btnExplor.UseVisualStyleBackColor = true;
            this.btnExplor.Click += new System.EventHandler(this.btnExplor_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(118, 80);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(102, 23);
            this.btnDelete.TabIndex = 15;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(7, 80);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(105, 23);
            this.btnConnect.TabIndex = 11;
            this.btnConnect.Text = "&Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Password:";
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(60, 43);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(273, 22);
            this.txtPassword.TabIndex = 9;
            this.txtPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPassword_KeyDown);
            // 
            // txtLiveID
            // 
            this.txtLiveID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLiveID.Location = new System.Drawing.Point(60, 16);
            this.txtLiveID.Name = "txtLiveID";
            this.txtLiveID.Size = new System.Drawing.Size(273, 22);
            this.txtLiveID.TabIndex = 8;
            this.txtLiveID.Text = "yinghong@softnetsolution.net";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Live ID:";
            // 
            // timerUpdate
            // 
            this.timerUpdate.Interval = 1000;
            this.timerUpdate.Tick += new System.EventHandler(this.timerUpdate_Tick);
            // 
            // _openFileDialog
            // 
            this._openFileDialog.DefaultExt = "jpg";
            this._openFileDialog.Filter = "Image Files(*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|Xml Files(*.xm)|*.xml|Text Files" +
                "|*.txt|All Files|*.*";
            this._openFileDialog.Multiselect = true;
            this._openFileDialog.Title = "Choose a File to View";
            // 
            // FormMeshExplorer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 640);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.statusStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMeshExplorer";
            this.Text = "Simple Mesh Explorer";
            this.Load += new System.EventHandler(this.FormMeshExplorer_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.tabPageLiveLogin.ResumeLayout(false);
            this.tabPageLiveLogin.PerformLayout();
            this.tabControlExplor.ResumeLayout(false);
            this.tabPageLogin.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPageLiveLogin;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.TextBox txtMeshObjectTile;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
        private System.Windows.Forms.Timer timerUpdate;
        private System.Windows.Forms.OpenFileDialog _openFileDialog;
        private System.Windows.Forms.Button _pickFile;
        private System.Windows.Forms.Label lableFileName;
        private System.Windows.Forms.ListBox listBoxMeshResources;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.WebBrowser webBrowser;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtLiveID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControlExplor;
        private System.Windows.Forms.TabPage tabPageLogin;
        private System.Windows.Forms.Button btnExplor;


    }
}

