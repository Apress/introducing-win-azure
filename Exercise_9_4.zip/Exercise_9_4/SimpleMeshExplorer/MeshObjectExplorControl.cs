﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SimpleMeshExplorer
{
    using Microsoft.LiveFX.Client;
    using Microsoft.LiveFX.ResourceModel;
    using Microsoft.Web;
    using AzureForDotNetDeveloper.Live.MeshClientFacade;

    public partial class MeshObjectExplorControl : UserControl
    {
        MeshObject _meshObject = null;
        DataFeed _dataFeed = null;
        DataEntry _entry = null;

        public MeshObjectExplorControl()
        {
            InitializeComponent();
        }

        public MeshObjectExplorControl(MeshObject meshObject)
        {
            InitializeComponent();
            _meshObject = meshObject;
            _InitializeControl();
        }

        private void _InitializeControl()
        {
            _LoadDataFeeds();
        }

        private void _LoadDataFeeds()
        {
            listBoxDataFeeds.Items.Clear();

            foreach (DataFeed dataFeed in _meshObject.DataFeeds.Entries)
            {
                listBoxDataFeeds.Items.Add(dataFeed.Resource.Title);
            }
            if (listBoxDataFeeds.Items.Count > 0)
            {
                listBoxDataFeeds.SelectedIndex = 0;
            }
        }

        private void listBoxDataFeeds_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (null != listBoxDataFeeds.SelectedItem)
            {
                _dataFeed = _meshObject.DataFeeds.Entries.FirstOrDefault(d => d.Resource.Title == listBoxDataFeeds.SelectedItem.ToString());
                _LoadDataEntries();
            }
        }

        private void _LoadDataEntries()
        {
            listBoxDataEntries.Items.Clear();
            if (null != _dataFeed)
            {
                foreach (DataEntry dataEntry in _dataFeed.DataEntries.Entries)
                {
                    listBoxDataEntries.Items.Add(dataEntry.Resource.Title);
                }
                if (listBoxDataEntries.Items.Count > 0)
                {
                    listBoxDataEntries.SelectedIndex = 0;
                }
            }
        }

        private void listBoxDataEntries_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (null != listBoxDataEntries.SelectedItem && null != _dataFeed)
            {
                _entry = _dataFeed.DataEntries.Entries.FirstOrDefault(de => de.Resource.Title == listBoxDataEntries.SelectedItem.ToString());
                txtDataEntry.Text = _entry.Resource.GetUserData<string>();
            }
        }

        private void btnDataFeedDelete_Click(object sender, EventArgs e)
        {
            if (null != _meshObject && null != _dataFeed)
            {
                try
                {
                    _meshObject.DataFeeds.Remove(_dataFeed);
                    _meshObject.Update();
                    _LoadDataEntries();
                }
                catch { }
            }
        }

        private void btnDataEntryAdd_Click(object sender, EventArgs e)
        {
            _entry = new DataEntry();
            _entry.Resource.Title = "";
            _entry.Resource.SetUserData<string>(txtDataEntry.Text);
            _dataFeed.DataEntries.Add(ref _entry);
            _dataFeed.Update();
            _dataFeed.Load();

            _LoadDataEntries();
        }

        private void btnAddDataFeeds_Click(object sender, EventArgs e)
        {
            _dataFeed = new DataFeed();
            _dataFeed.Resource.Title = "";
            _meshObject.DataFeeds.Add(ref _dataFeed);
            _meshObject.Update();

            _LoadDataEntries();
        }

        private void btnDataEntryDelete_Click(object sender, EventArgs e)
        {
            if (null != _entry && null != _dataFeed)
            {
                try
                {
                    _dataFeed.DataEntries.Remove(_entry);
                    _dataFeed.Update();
                    _dataFeed.Load();

                    _LoadDataEntries();
                }
                catch { }
            }
        }
    }
}
