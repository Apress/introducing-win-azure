﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace ShoppingCarServiceHost
{
    using Microsoft.ServiceBus;
    using CloudWorkflowServiceLibrary;

    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(ShoppingCarService));

            ServiceEndpoint endpoint = host.AddServiceEndpoint("CloudWorkflowServiceLibrary.IShoppingCarService",
                                                         new NetEventRelayBinding(),
                                                         //"sb://servicebus.windows.net/services/SoftnetSolutions_113/ShoppingCar");
                                                         "sb://servicebus.windows.net/services/softnetsolution/ShoppingCar");
            TransportClientEndpointBehavior transportEndpointBehavior = new TransportClientEndpointBehavior();
            transportEndpointBehavior.CredentialType = TransportClientCredentialType.SharedSecret;// UserNamePassword;
            //transportEndpointBehavior.Credentials.UserName.UserName = "lyh3";
            //transportEndpointBehavior.Credentials.UserName.Password = "Soul111#";
            transportEndpointBehavior.Credentials.SharedSecret.IssuerName = "lyh3";
            transportEndpointBehavior.Credentials.SharedSecret.IssuerSecret = "Soul111#";

            endpoint.Behaviors.Add(transportEndpointBehavior);

            try
            {
                host.Open();
                Console.WriteLine("Host is running");
                Console.ReadLine();
                host.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("---ShoppingCarServiceHost:Main, exception caught{0}", ex.Message));
            }
        }
    }
}
