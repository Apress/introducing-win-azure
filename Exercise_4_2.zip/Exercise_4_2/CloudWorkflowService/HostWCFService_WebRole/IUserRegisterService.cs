﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HostWCFService_WebRole
{
    // NOTE: If you change the interface name "IUserRegisterService" here, you must also update the reference to "IUserRegisterService" in Web.config.
    [ServiceContract]
    public interface IUserRegisterService
    {
        [OperationContract]
        void DoWork();
    }
}
