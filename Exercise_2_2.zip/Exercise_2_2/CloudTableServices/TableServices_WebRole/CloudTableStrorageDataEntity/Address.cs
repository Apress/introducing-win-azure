﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace TableServices_WebRole.CloudTableStrorageDataEntity
{
    using Microsoft.WindowsAzure.StorageClient;

    public enum State : int
    {
        AL, AK, AS, AZ, AR, CA, CO, CT, DE, DC, FM, FL, GA, GU, HI,
        ID, IL, IN, IA, KS, KY, LA, ME, MH, MD, MA, MI, MN, MS, MO,
        MT, NE, NV, NH, NJ, NM, NY, NC, ND, MP, OH, OK, OR, PW, PA,
        PR, RI, SC, SD, TN, TX, UT, VT, VI, VA, WA, WV, WI, WY
    }

    public class Address : TableServiceEntity
    {
        private State _state = TableServices_WebRole.CloudTableStrorageDataEntity.State.OR;

        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public int? State { get { return (int)_state; } set { _state = (State)value; } }
        public string Zip { get; set; }
        public string County { get; set; }
        public string Country { get; set; }

        public Address()
            //: this(ConfigurationManager.AppSettings["PartitionKey"], Guid.NewGuid().ToString())
            : this(Guid.NewGuid().ToString(), Guid.NewGuid().ToString())
        {
        }

        public Address(string partitionKey, string rowKey)
            : base(partitionKey, rowKey)
        {
        }
        public Address(string address1,
                       string address2,
                       string city,
                       State state,
                       string zip,
                       string county,
                       string country,
                       string partitionKey,
                       string rowKey)
            : this(partitionKey, rowKey)
        {
            Address1 = address1;
            Address2 = address2;
            City = city;
            State = (int)state;
            Zip = zip;
            County = county;
            Country = country;
        }

        public string GetPartitionKey() { return base.PartitionKey; }
        public string GetRowKey() { return base.RowKey; }
    }
}
