﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TableServices_WebRole.CloudTableStrorageDataEntity
{
    using Microsoft.WindowsAzure.StorageClient;

    public interface ICloudEntity
    {
        string GetPartitionKey();
        string GetRowKey();
        ICloudEntity GetDepencyEntity();
        void SetDependencyEntity(ICloudEntity entity);
        List<ICloudEntity> DependencyType();
    }
}
