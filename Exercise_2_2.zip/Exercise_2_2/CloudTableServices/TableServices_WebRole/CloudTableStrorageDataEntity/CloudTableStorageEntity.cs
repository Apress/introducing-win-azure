﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TableServices_WebRole.CloudTableStrorageDataEntity
{
    using Microsoft.WindowsAzure.StorageClient;

    abstract public class CloudTableStorageEntity : TableServiceEntity, ICloudEntity
    {
        protected List<ICloudEntity> _depencencyEntityTypeList = new List<ICloudEntity>();
        protected string _partitionKey = string.Empty;
        protected string _rowKey = string.Empty;

        public CloudTableStorageEntity()
        {
            _partitionKey = base.RowKey = Guid.NewGuid().ToString();
            _rowKey = base.PartitionKey = Guid.NewGuid().ToString();
            _Initialization();
        }
        
        public CloudTableStorageEntity(string partitionKey, string rowKey)
        {
            _rowKey = base.RowKey = rowKey;
            _partitionKey = base.PartitionKey = partitionKey;
            _Initialization();
        }

        public CloudTableStorageEntity(string partitionKey)
            : this(partitionKey, Guid.NewGuid().ToString())
        {
        }

        public List<ICloudEntity> DependencyType()
        {
            return _depencencyEntityTypeList;
        }

        public string GetPartitionKey() { return _partitionKey; }
        public string GetRowKey() { return _rowKey; }

        abstract protected void _Initialization();
        abstract public ICloudEntity GetDepencyEntity();
        abstract public void SetDependencyEntity(ICloudEntity entity);
    }
}
