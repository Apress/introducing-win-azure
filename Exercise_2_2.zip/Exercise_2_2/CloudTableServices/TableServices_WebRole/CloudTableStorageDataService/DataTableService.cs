﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Services.Client;

namespace TableServices_WebRole.CloudTableStorageDataService
{
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStorageDataContext;
    using TableServices_WebRole.CloudTableStrorageDataEntity;

    abstract public class DataTableService : ICloudTableStorageService
    {
        protected TableContext _dataTableContext = null;
        protected CloudTableServiceFactory _cloudTableFactory = new CloudTableServiceFactory();

        public DataTableService()
        {
            _cloudTableFactory = new CloudTableServiceFactory();
        }

        public TableContext TabeContext() { return _dataTableContext; }

        virtual public bool Insert(ICloudEntity entity)
        {
            bool success = false;
            ICloudEntity dependency = null;

            try
            {
                _dataTableContext.AddObject(_dataTableContext.TableName, entity);
                _dataTableContext.SaveChanges();

                dependency = entity.GetDepencyEntity();
                while (null != dependency)
                {
                    CloudTableServiceFactory cloudTableFactory = new CloudTableServiceFactory();
                    cloudTableFactory.FactoryCloudTableService(dependency).Insert(dependency);
                    dependency = dependency.GetDepencyEntity();
                }
            }
            catch { }

            success = true;

            return success;
        }

        virtual public bool Update(ICloudEntity entity)
        {
            bool success = false;

            if (null != entity)
            {
                _dataTableContext.MergeOption = MergeOption.PreserveChanges;

                _dataTableContext.AttachTo(_dataTableContext.TableName, entity, "*");
                _dataTableContext.UpdateObject(entity);
                _dataTableContext.SaveChanges();

                success = true;
            }

            return success;
        }

        virtual public bool Delete(ICloudEntity entity)
        {
            bool success = false;

            if (null != entity)
            {
                foreach (ICloudEntity entityType in entity.DependencyType())
                {
                    ICloudEntity dependeny = QueryDependencyEntity(entityType, (entity as TableServiceEntity).RowKey);

                    if (null != dependeny)
                    {
                        _cloudTableFactory.FactoryCloudTableService(dependeny).Delete(dependeny);
                    }
                }

                try
                {
                    _dataTableContext.AttachTo(_dataTableContext.TableName, entity, "*");
                    _dataTableContext.DeleteObject(entity);
                    _dataTableContext.SaveChanges();
                }
                catch (Exception ex)
                {
                }

                success = true;
            }

            return success;
        }

        protected ICloudEntity QueryDependencyEntity(ICloudEntity entity, string key)
        {   
            ICloudEntity  dependencies = null;

            ICloudTableStorageService cloudTableservice = _cloudTableFactory.FactoryCloudTableService(entity);
            dependencies = cloudTableservice.TabeContext().QueryEntitiesByPartionKey(key);

            return dependencies;
        }
    }   
}
