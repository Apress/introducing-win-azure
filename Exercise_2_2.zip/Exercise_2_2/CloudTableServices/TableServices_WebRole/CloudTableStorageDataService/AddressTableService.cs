﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Services.Client;
using System.Configuration;

namespace TableServices_WebRole.CloudTableStorageDataService
{
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStrorageDataEntity;
    using TableServices_WebRole.CloudTableStorageDataContext;

    public class AddressTableService : DataTableService
    {
        /// <summary>
        /// The tables Should already be created in the global.asax.cs file on first request
        /// Create the service context we'll query via Selecte
        /// </summary>
        public AddressTableService()
        {
            _dataTableContext = Global.TableContext;
            _dataTableContext.RetryPolicy = RetryPolicies.Retry(Convert.ToInt32(ConfigurationManager.AppSettings["Retry"]), TimeSpan.FromSeconds(1));
        }

        public IEnumerable<Address> Select()
        {
            if (null == _dataTableContext || null == (_dataTableContext as AddressTableContext))
            {
                return null;
            }

            var results = from a in (_dataTableContext as AddressTableContext).AddressTable
                          select a;

            if (0 == (results as DataServiceQuery<Address>).ToArray<Address>().Count<Address>())
            {
                return null;
            }

            CloudTableQuery<Address> query = new CloudTableQuery<Address>(results as DataServiceQuery<Address>);
            IEnumerable<Address> queryResults = query.Execute();
            return queryResults;
        }

        public bool Delete(Address entity)
        {
            return base.Delete(entity as ICloudEntity);
        }
    }
}
