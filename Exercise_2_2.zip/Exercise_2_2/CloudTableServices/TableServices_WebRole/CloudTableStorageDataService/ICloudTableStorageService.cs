﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TableServices_WebRole.CloudTableStorageDataService
{
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStrorageDataEntity;
    using TableServices_WebRole.CloudTableStorageDataContext;

    public interface ICloudTableStorageService
    {
        bool Insert(ICloudEntity entity);
        bool Update(ICloudEntity entity);
        bool Delete(ICloudEntity entity);
        TableContext TabeContext();
    }
}
