﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TableServices_WebRole.CloudTableStorageDataContext
{
    using TableServices_WebRole.CloudTableStrorageDataEntity;
    public interface ITableContext
    {
        string TableName { get; set; }
        ICloudEntity QueryEntitiesByPartionKey(string partitionKey);
        ICloudEntity QueryEntitiesByRowKey(string rowKey);
    }
}
