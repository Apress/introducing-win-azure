﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TableServices_WebRole.CloudTableStorageDataContext
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStrorageDataEntity;

    abstract public class TableContext : TableServiceContext, ITableContext
    {
        public string TableName { get; set; }

        public TableContext(string baseAddress, StorageCredentials credentials)
            : base(baseAddress, credentials)
        {
        }

        abstract public ICloudEntity QueryEntitiesByPartionKey(string partitionKey);
        abstract public ICloudEntity QueryEntitiesByRowKey(string rowKey);
    }
}
