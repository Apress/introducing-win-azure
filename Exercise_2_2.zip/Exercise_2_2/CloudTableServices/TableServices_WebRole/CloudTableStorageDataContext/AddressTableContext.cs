﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace TableServices_WebRole.CloudTableStorageDataContext
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;
    using TableServices_WebRole.CloudTableStrorageDataEntity;

    public class AddressTableContext : TableContext
    {
        public AddressTableContext(string baseAddress, StorageCredentials credentials)
            : base(baseAddress, credentials)
        {
            TableName = ConfigurationManager.AppSettings["AddressTable"];
        }

        public IQueryable<Address> AddressTable
        {
            get { return CreateQuery<Address>(TableName); }
        }

        override public ICloudEntity QueryEntitiesByPartionKey(string partitionKey)
        {
            //return AddressTable.Where(a => a.GetPartitionKey() == partitionKey) as ICloudEntity;
            ICloudEntity entity = null;

            foreach (Address address in AddressTable)
            {
                if (address.PartitionKey == partitionKey)
                {
                    entity = address as ICloudEntity;
                    break;
                }
            }

            return entity;
        }

        override public ICloudEntity QueryEntitiesByRowKey(string rowKey)
        {
            //return AddressTable.Where(a => a.GetRowKey() == rowKey) as ICloudEntity;
            ICloudEntity entity = null;

            foreach (Address address in AddressTable)
            {
                if (address.RowKey == rowKey)
                {
                    entity = address as ICloudEntity;
                    break;
                }
            }

            return entity;
        }
    }
}
