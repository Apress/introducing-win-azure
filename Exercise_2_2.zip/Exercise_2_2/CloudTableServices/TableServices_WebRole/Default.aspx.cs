﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Data.Services.Client;

namespace TableServices_WebRole
{
    using TableServices_WebRole.CloudTableStorageDataService;
    using TableServices_WebRole.CloudTableStrorageDataEntity;
    using TableServices_WebRole.CloudTableStorageDataContext;

    public partial class Default : System.Web.UI.Page
    {
        private AddressTableService _addressTableServicve = null;
        private Address _previousEntityAddress = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsCallback)
            {
                _addressTableServicve = new AddressTableService();
            }
            else
            {
                _DataBinding();
            }
        }

        protected void btnAddAddress_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
               _UpdateTest();
                _ContinuationKeyPeek();
                _DataBinding();
            }

        }

        private void _UpdateTest()
        {
            const string PREVIOUS_ENTITY = "PREVIOUS_ENTITY";
            _previousEntityAddress = Session[PREVIOUS_ENTITY] as Address;

            if (null != _previousEntityAddress)
            {
                _addressTableServicve.Delete(_previousEntityAddress);
            }

            Address address = new Address(txtAddress1.Text.Trim(),
                                          "0",
                                          txtCity.Text.Trim(),
                                          (State)combState.SelectedIndex,
                                          txtZip.Text.Trim(),
                                          txtCounty.Text.Trim(),
                                          txtCountry.Text.Trim(),
                                          string.Empty,
                                          string.Empty);

            _addressTableServicve.Insert(address as ICloudEntity);

            Session.Add(PREVIOUS_ENTITY, address);

            for (int i = 1; i < 4; ++i)
            {
                Thread thread = new Thread(new ParameterizedThreadStart(_Update));
                thread.Start(new object[] { i, address } as object);
                thread.Join(100);
            }

            _DataBinding();
        }

        private void _Update(object parameters)
        {
            AddressTableService addressTableServicve = new AddressTableService();
            TableContext tableContext = _addressTableServicve.TabeContext();
            var currentEntity = from a
                                in tableContext.CreateQuery<Address>(tableContext.TableName)
                                where a.RowKey == ((parameters as object[])[1] as Address).RowKey
                                select a;
            if (null != currentEntity)
            {
                ICloudEntity currentAddress = currentEntity.FirstOrDefault<Address>() as ICloudEntity;
                int currentValue = int.Parse((currentAddress as Address).Address2.Trim());
                (currentAddress as Address).Address2 = Convert.ToString(currentValue + (int)((parameters as object[])[0] as object));
                addressTableServicve.Update(currentAddress);
            }
        }

        private void _DataBinding()
        {
            AddressView.DataBind();
        }

        private void _ContinuationKeyPeek()
        {
            AddressTableContext tableContext = _addressTableServicve.TabeContext() as AddressTableContext;
            ContinuationToken continuationToken = null;
            do
            {
                var topTenAddress= tableContext.CreateQuery<Address>(tableContext.TableName).Take(10);
                var query = topTenAddress as DataServiceQuery<Address>;

                if (continuationToken != null)
                {
                    query = query.AddQueryOption("NextPartitionKey", continuationToken.PartitionKey);
                    if (continuationToken.RowKey != null)
                    {
                        query = query.AddQueryOption("NextRowKey", continuationToken.RowKey);
                    }
                }

                var response = query.Execute() as QueryOperationResponse;

                if (response.Headers.ContainsKey("x-ms-continuation-NextPartitionKey"))
                {
                    continuationToken.PartitionKey = response.Headers["x-ms-continuation-NextPartitionKey"];
                    if (response.Headers.ContainsKey("x-ms-continuation-NextRowKey"))
                    {
                        continuationToken.RowKey = response.Headers["x-ms-continuation-NextRowKey"];
                    }
                }
                else
                {
                    continuationToken = null;
                }
            } while (continuationToken != null);
        }
    }

    public class ContinuationToken
    {
        public string PartitionKey { get; set; }

        public string RowKey { get; set; }
    }
}
