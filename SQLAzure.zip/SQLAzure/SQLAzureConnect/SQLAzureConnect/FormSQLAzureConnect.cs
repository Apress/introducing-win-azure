﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;

namespace SQLAzureConnect
{
    using SQLAzureConnect.Schema.SQLDatabaseAccess;
    using SQLAzureConnect.Schema.SQLParameter;

    public delegate void EventNotificationHandler(object source, EventArgs args);
    public delegate void EventBubblePreviewKeyDownHandler(object source, PreviewKeyDownEventArgs args);

    public partial class FormSQLAzureConnect : Form
    {
        const string QUERY_XMLFILE_FILTER = "SQL Azure Query Data Files|*.xml|All Files|*.*";
        private string _sqlAccessDataXmlPath = Environment.CurrentDirectory + @"\SQLAccessData.xml";
        public SQLDatabaseAccessRoot _sqlDataAccessRoot = null;

        public FormSQLAzureConnect()
        {
            InitializeComponent();

            _LoadSqlAccessDataXml(_sqlAccessDataXmlPath);
        }

        public string ConnectionString
        {
            get
            {
                if (this.radioButtonCloud.Checked)
                {
                   return string.Format("Server=tcp:{0}.ctp.database.windows.net;Database={1};User ID={2};Password={3};Trusted_Connection=False;",
                                            this.txtServer.Text.Trim(),
                                            this.txtDatabase.Text.Trim(),
                                            this.txtUserID.Text.Trim(),
                                            this.txtPassword.Text.Trim());
                }
                else
                {
                    if (this.checkBoxWindowsAuthentication.Checked)
                    {
                        return string.Format("Data Source={0};Initial Catalog={1};Integrated Security=True;",
                                               this.txtServer.Text.Trim(),
                                               this.txtDatabase.Text.Trim());
                    }
                    else
                    {
                        return string.Format("Data Source={0};Initial Catalog={1};Integrated Security=False;User ID={2};Password={3};",
                                    this.txtServer.Text.Trim(),
                                    this.txtDatabase.Text.Trim(),
                                    this.txtUserID.Text.Trim(),
                                    this.txtPassword.Text.Trim());
                    }
                }
            }
        }

        private string _TextSelected { get; set; }

        public void DisplayMessage(string message, bool error)
        {
            richTextBoxMessage.AppendText(message);
            richTextBoxMessage.ForeColor = error ? Color.Red : Color.Gold;
            richTextBoxMessage.ScrollToCaret();
            richTextBoxMessage.AppendText(Environment.NewLine);
        }

        public static bool IsPageExisted(string pageKey, TabControl tabControl)
        {
            bool existed = false;

            foreach (TabPage page in tabControl.TabPages)
            {
                if (page.Text == pageKey)
                {
                    existed = true;
                    break;
                }
            }

            return existed;
        }

        private void _UpdateUI()
        {
            if (null != _sqlDataAccessRoot)
            {
                this.txtServer.Text = _sqlDataAccessRoot.ServerConnection.ServerName;
                this.txtDatabase.Text = _sqlDataAccessRoot.ServerConnection.Database;
                this.txtUserID.Text = _sqlDataAccessRoot.ServerConnection.Login;
                this.txtPassword.Text = _sqlDataAccessRoot.ServerConnection.Password;

                for (int i = 0; i < _sqlDataAccessRoot.SqlDataService.Length; ++i)
                {
                    this._AddPage(_sqlDataAccessRoot.SqlDataService[i].Subject, ref _sqlDataAccessRoot.SqlDataService[i]);
                }
                this.tabControlServices.SelectedIndex = 0;
            }
        }

        private TabPage _AddPage(string pageKey,
                                 ref SQLDatabaseAccessRootSqlDataService sqlDatabaseAccessRoot)
        {
            TabPage page = null;
            if (IsPageExisted(pageKey, this.tabControlServices))
            {
                DisplayMessage(string.Format("The name <{0}> of service is already existed", pageKey), true);
                return null;
            }

            page = new TabPage(pageKey);
            page.ForeColor = Color.Navy;
            SQLDataServiceControl serviceCotnrol = new SQLDataServiceControl(ref sqlDatabaseAccessRoot, this);
            serviceCotnrol.eventSelectedTexChanged += (s, e) =>
            {
                this.btnExecute.Text = null == (e as SelectedTextArgs).ServiceControl?  "&Execute" : "&Execute Select";
                this.btnExecute.BackColor = null == (e as SelectedTextArgs).ServiceControl ? Color.WhiteSmoke : Color.Goldenrod;
                this._TextSelected = null == (e as SelectedTextArgs).ServiceControl ? null : ((e as SelectedTextArgs).ServiceControl as SQLDataServiceControl).SelectedText;
            };
            serviceCotnrol.eventBubblePreviewKeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.F5)
                {
                    this.btnExecute_Click(this, null);
                }
            };
            page.Controls.Add(serviceCotnrol);
            serviceCotnrol.Dock = DockStyle.Fill;
            this.tabControlServices.TabPages.Add(page);
            this.tabControlServices.SelectedTab = page;

            return page;
        }

        private void _LoadSqlAccessDataXml(string sqlAccessDataXmlPath)
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(_sqlAccessDataXmlPath);
                _sqlDataAccessRoot = (SQLDatabaseAccessRoot)SQLDataAcessHelper.XmlRetrive(typeof(SQLDatabaseAccessRoot), xmlDoc);
                _UpdateUI();
                this.radioButtonCloud.Select();
            }
            catch (Exception ex)
            {
                DisplayMessage(ex.Message, true);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            this._openFileDialog.Filter = QUERY_XMLFILE_FILTER;
            string xmlFilePath = _sqlAccessDataXmlPath;
            _openFileDialog.FileName = xmlFilePath;
            if (_openFileDialog.ShowDialog() == DialogResult.OK)
            {
                this.tabControlServices.TabPages.Clear();
                xmlFilePath = _openFileDialog.FileName;
                _LoadSqlAccessDataXml(xmlFilePath);
            }
            _sqlAccessDataXmlPath = xmlFilePath;
        }

        private void _DoDataExchange()
        {
            this._sqlDataAccessRoot.ServerConnection.ServerName = this.txtServer.Text.Trim();
            this._sqlDataAccessRoot.ServerConnection.Database = this.txtDatabase.Text.Trim();
            this._sqlDataAccessRoot.ServerConnection.Login = this.txtUserID.Text.Trim();
            //this._sqlDataAccessRoot.ServerConnection.Password = this.txtPassword.Text.Trim();
            
            for (int i = 0; i < this.tabControlServices.TabPages.Count; ++i)
            {
                (this.tabControlServices.TabPages[i].Controls[0] as SQLDataServiceControl).DoDataExchange();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this._saveFileDialog.Filter = QUERY_XMLFILE_FILTER;
            string xmlFilePath = _sqlAccessDataXmlPath;
            _saveFileDialog.FileName = xmlFilePath;
            if (_saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                xmlFilePath = _saveFileDialog.FileName;
                try
                {
                    this._DoDataExchange();

                    StringBuilder sb = SQLDataAcessHelper.XmlPersist(_sqlDataAccessRoot, typeof(SQLDatabaseAccessRoot));
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(sb.ToString());
                    xmlDoc.Save(xmlFilePath);
                }
                catch (Exception ex)
                {
                    DisplayMessage(ex.Message, true);
                }
            }
            _sqlAccessDataXmlPath = xmlFilePath;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            TabPage currentSelectedPage = this.tabControlServices.SelectedTab;
            string s = (currentSelectedPage.Controls[0] as SQLDataServiceControl).SelectedText;

            (currentSelectedPage.Controls[0] as SQLDataServiceControl).DoDataExchange();
            SQLDataAcessHelper dataAccessHelper = new SQLDataAcessHelper(this._sqlDataAccessRoot, this.ConnectionString);
            Object results = new object();

            StringBuilder sb = new StringBuilder();

            try
            {
                if (null == _TextSelected)
                {
                    sb.Append(dataAccessHelper.Excute(currentSelectedPage.Text, ref results));
                }
                else
                {
                    const string splitPattern = "GO";
                    string[] split = Regex.Split(_TextSelected.Replace("go", splitPattern).Replace("Go", splitPattern), splitPattern);
                    string strText = string.Empty;
                    for (int i = 0; i < split.Length; ++i)
                    {
                        strText = split[i].Trim().Trim('\t');
                        if (!(String.IsNullOrEmpty(strText) || strText == splitPattern))
                        {
                            sb.Append(dataAccessHelper.ExcuteSelected(split[i].Trim()));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.DisplayMessage(string.Format("--- SQL Execute failed, error : {0}{1}", Environment.NewLine, ex.Message), true);
                return;
            }

            this.DisplayMessage(sb.ToString(), false);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DisplayMessage(string.Empty, false);
            this.txtServiceName.Focus();
            string pageKey = this.txtServiceName.Text.Trim();
            if (string.Empty == pageKey)
            {
                DisplayMessage("Please enter a service name!", true);
                return;
            }

            SQLDatabaseAccessRootSqlDataService sqlService = new SQLDatabaseAccessRootSqlDataService();
            sqlService.Subject = pageKey;
            sqlService.Command = new SQLDatabaseAccessRootSqlDataServiceCommand();
            sqlService.Command.Text = string.Empty;
            sqlService.Command.Type = SQLDatabaseAccessRootSqlDataServiceCommandType.Query;

            this._AddPage(pageKey, ref sqlService);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DisplayMessage(string.Empty, false);
            if (string.Empty == this.txtServiceName.Text)
            {
                DisplayMessage("Please enter a service name!", true);
                return;
            }
            TabPage page = null;
            foreach (TabPage p in this.tabControlServices.TabPages)
            {
                if (p.Text == txtServiceName.Text.Trim())
                {
                    page = p;
                    break;
                }
            }

            if (null != page)
            {
                if( null != _sqlDataAccessRoot.SqlDataService)
                {
                    int serviceCount = this._sqlDataAccessRoot.SqlDataService.Length;
                    List<SQLDatabaseAccessRootSqlDataService> serviceList = new List<SQLDatabaseAccessRootSqlDataService>();
                    foreach( SQLDatabaseAccessRootSqlDataService service in this._sqlDataAccessRoot.SqlDataService)
                    {
                        if ( service.Subject != this.txtServiceName.Text)
                        {
                            serviceList.Add(service);
                        }
                    }
                    this._sqlDataAccessRoot.SqlDataService = new SQLDatabaseAccessRootSqlDataService[serviceList.Count];
                    if ( serviceList.Count > 0 )
                    {
                        serviceList.CopyTo(this._sqlDataAccessRoot.SqlDataService);
                    }
                    this.tabControlServices.TabPages.Remove(page);
                }
            }
            else 
            {
                this.DisplayMessage(string.Format("Can not find the service <{0}>", this.txtServiceName.Text), true);
            }
        }

        private void radioButtonCloud_CheckedChanged(object sender, EventArgs e)
        {
            this.checkBoxWindowsAuthentication.Checked = true;
            this.checkBoxWindowsAuthentication.Enabled = false;
            this.checkBoxWindowsAuthentication.Text = "Azure security";
            checkBoxWindowsAuthentication_CheckedChanged(this, null);
        }

        private void radioButtonLocal_CheckedChanged(object sender, EventArgs e)
        {
            this.checkBoxWindowsAuthentication.Enabled = true;
            this.checkBoxWindowsAuthentication.Checked = true;
            this.checkBoxWindowsAuthentication.Text = "Windows security";
            checkBoxWindowsAuthentication_CheckedChanged(this, null);
        }

        private void checkBoxWindowsAuthentication_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButtonCloud.Checked)
            {
                this.txtUserID.Enabled = this.txtPassword.Enabled = true;
            }
            else 
            {
                this.txtUserID.Enabled = this.txtPassword.Enabled = this.checkBoxWindowsAuthentication.Checked ? false : true;
            }
        }

        private void btnTestConnection_Click(object sender, EventArgs e)
        {
            DisplayMessage(string.Empty, false);
            DisplayMessage(string.Format("Connect to database <{0}> of SQL {1} server <{2}>....", 
                                            this.txtDatabase.Text,
                                            this.radioButtonCloud.Checked ? "Azure":string.Empty,
                                            this.txtServer.Text), false);
            SqlConnection sqlConnection = new SqlConnection();

            Cursor currentCursor = this.Cursor; 
            this.Cursor = Cursors.WaitCursor;

            try
            {
                sqlConnection.ConnectionString = this.ConnectionString;
                sqlConnection.Open();
                DisplayMessage("Connecting test success", false);
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                DisplayMessage(ex.Message, true);
            }
            finally
            {
                sqlConnection.Close();
                this.Cursor = currentCursor;
            }
        }

     }
}
