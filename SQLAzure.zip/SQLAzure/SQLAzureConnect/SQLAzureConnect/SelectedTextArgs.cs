﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SQLAzureConnect
{
    public class SelectedTextArgs : EventArgs
    {
        public SQLDataServiceControl ServiceControl { get; set; }

        public SelectedTextArgs(SQLDataServiceControl serviceControl)
        {
            ServiceControl = serviceControl;
        }
    }
}
