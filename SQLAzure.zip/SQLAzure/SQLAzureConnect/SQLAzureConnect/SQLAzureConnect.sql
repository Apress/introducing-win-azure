SELECT * FROM sys.databases 
GO

--select count(*) from UserTable
--select * from UserTable

--DROP TABLE [UserTable]
CREATE TABLE [dbo].[UserTable](
	[UserID] [int] IDENTITY(1,1)NOT NULL,
	[Password] [nvarchar](100) NULL,
	FirstName [nvarchar](100) NOT NULL,
	LastName [nvarchar](100) NOT NULL, 
	[Timestamp] [timestamp] NOT NULL
) 
GO
ALTER TABLE [UserTable]
ADD CONSTRAINT UserID_PK PRIMARY KEY (UserID)
GO

INSERT INTO UserTable
([Password],
 FirstName,
 LastName)
VALUES
('password',
  'Henry',
 'Li')INSERT INTO UserTable
 GO
 
 INSERT INTO UserTable
([Password],
 FirstName,
 LastName)
VALUES
('password',
  'Emma',
 'Li')INSERT INTO UserTable
 GO

([Password],
 FirstName,
 LastName)
VALUES
('password',
  'David',
 'Kruger')
GO

CREATE TABLE [dbo].[Address](
	AddressID [int] IDENTITY(1,1)NOT NULL,
	[UserID] [int] NOT NULL,
	Address1 [nvarchar](100) NULL,
	Address2 [nvarchar](100) NULL,
	City [nvarchar](100) NULL, 
	State [nvarchar](100) NULL,
	Zip [nvarchar](9) NULL,
	County [nvarchar](50) NULL,
	Email1 [nvarchar](100) NOT NULL,
	Email2 [nvarchar](100) NULL
) 
GO

ALTER TABLE [Address]
ADD CONSTRAINT AddressID_PK PRIMARY KEY (AddressID)
GO

INSERT INTO Address(
	UserID, 
	Address1, 
	City,
	[State],
	Zip,
	County,
	Email1,
	Email2
	)
VALUES(
	1,
	'192 NE 74th Ave',
	'Hillsboro',
	'OR',
	'97124',
	'Washiongton',
	'yinghong@softnetsolution.net',
	'henry@softnetsolution.net')
GO
INSERT INTO Address(
	UserID, 
	Address1, 
	City,
	[State],
	Zip,
	County,
	Email1,
	Email2
	)
VALUES(
	3,
	'1234 Colledge Pkwy',
	'Ft. Collions',
	'CO',
	'80523',
	'King',
	'david.kruger@colostate.edu',
	' ')
GO

INSERT INTO Address(
	UserID, 
	Address1, 
	City,
	[State],
	Zip,
	County,
	Email1,
	Email2
	)
VALUES(
	2,
	'192 NE 74th Ave',
	'Hillsboro',
	'OR',
	'97124',
	'Washoe',
	'emma0702@yahoo.com',
	' ') 
GO

CREATE PROCEDURE sp_Retrieve
AS
BEGIN
	select * from UserTable where FirstName like 'Henry%'
END
GO

CREATE PROCEDURE sp_BatchInsert
@rows int
AS
DECLARE @index int
SELECT @index = 1
WHILE (@index < @rows)
BEGIN
	INSERT INTO UserTable
	([Password],
	 FirstName,
	 LastName)
	VALUES
	('password',
	  'Henry' + CAST(@index as nvarchar),
	 'Li')
    SELECT @index = @index + 1
END
go

CREATE PROCEDURE sp_BatchUpdate
@rows int
AS
DECLARE @index int
SELECT @index = 1
WHILE (@index < @rows)
BEGIN
	UPDATE UserTable
	SET
	[Password] = 'passworduPDATE',
	 FirstName = 'Henry' + CAST(@index as nvarchar),
	 LastName = 'Li'
	 WHERE [UserID] = @index
    SELECT @index = @index + 1
END
go

CREATE PROCEDURE sp_BatchDelete
@rows int
AS
DECLARE @index int
SELECT @index = 1
WHILE (@index < @rows)
BEGIN
	DELETE UserTable
	WHERE [UserID] = @index
    SELECT @index = @index + 1
END
go


CREATE INDEX IX_UserTable_FirstName
ON [UserTable](FirstName)
go

ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_UserTable] FOREIGN KEY([UserID])
REFERENCES [dbo].[UserTable] ([UserID])
GO
ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_UserTable]
GO
--truncate table UserTable
DECLARE @NUMBER_OF_TEST_ROWS INT
SET @NUMBER_OF_TEST_ROWS = 100
EXEC BatchInsert @NUMBER_OF_TEST_ROWS
EXEC sp_Retrieve --select * from UserTable where FirstName like 'Henry%'
EXEC BatchUpdate @NUMBER_OF_TEST_ROWS
EXEC BatchDelete @NUMBER_OF_TEST_ROWS
 

SET SHOWPLAN_ALL ON
GO
select * from UserTable where FirstName like 'Henry%'
GO
SET SHOWPLAN_ALL OFF