﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SQLAzureConnect
{
    using SQLAzureConnect.Schema.SQLDatabaseAccess;
    using SQLAzureConnect.Schema.SQLParameter;

    public partial class SQLDataServiceControl : UserControl
    {
        public SQLDatabaseAccessRootSqlDataService _sqlDatabaseAccessService = null;
        private FormSQLAzureConnect _parentForm = null;
        private TabPage _currentSelectedPage = null;
        public string SelectedText { get { return this.richTextBoxCommandText.SelectedText.Trim(); } }

        public event EventNotificationHandler eventSelectedTexChanged;
        public event EventBubblePreviewKeyDownHandler eventBubblePreviewKeyDown;

        public SQLDataServiceControl()
        {
            InitializeComponent();
        }

        public SQLDataServiceControl(ref SQLDatabaseAccessRootSqlDataService sqlDatabaseAccessRoot,
                                     FormSQLAzureConnect parentForm)
        {
            InitializeComponent();
            this.bindingSourceService.DataSource = _sqlDatabaseAccessService = sqlDatabaseAccessRoot;
            _parentForm = parentForm;
            _UpdateUI();
            this.richTextBoxCommandText.PreviewKeyDown += new PreviewKeyDownEventHandler(richTextBoxCommandText_PreviewKeyDown);
        }

        public void DoDataExchange()
        {
            _sqlDatabaseAccessService.Subject = this.txtSubject.Text.Trim();
            _sqlDatabaseAccessService.Description = this.txtDescription.Text.Trim();
            _sqlDatabaseAccessService.Command.Text = this.richTextBoxCommandText.Text.Trim();

            if (this.radioButtonQuery.Checked)
            {
                _sqlDatabaseAccessService.Command.Type = SQLDatabaseAccessRootSqlDataServiceCommandType.Query;
            }
            else if (this.radioButtonStoredProcedure.Checked)
            {
                _sqlDatabaseAccessService.Command.Type = SQLDatabaseAccessRootSqlDataServiceCommandType.Storedprocedure;
            }

            foreach (TabPage page in this.tabParameter.TabPages)
            {
                (page.Controls[0] as ParameterControl).DoDataExchange();
            }
        }

        private void _UpdateUI()
        {
            if (null != _sqlDatabaseAccessService)
            {
                this.txtSubject.Text = _sqlDatabaseAccessService.Subject;
                this.txtDescription.Text = _sqlDatabaseAccessService.Description;

                switch (_sqlDatabaseAccessService.Command.Type)
                {
                    case SQLDatabaseAccessRootSqlDataServiceCommandType.Storedprocedure:
                        this.radioButtonStoredProcedure.Select();
                        break;
                    case SQLDatabaseAccessRootSqlDataServiceCommandType.Query:
                    default:
                        this.radioButtonQuery.Select();
                        break;
                }

                this.richTextBoxCommandText.Clear();
                this.richTextBoxCommandText.AppendText(_sqlDatabaseAccessService.Command.Text);
                if (null != _sqlDatabaseAccessService.Command && null != _sqlDatabaseAccessService.Command.SQLParameterRoot)
                {
                    for (int i = 0; i < _sqlDatabaseAccessService.Command.SQLParameterRoot.Length; ++i )
                    {
                        _AddPage(ref _sqlDatabaseAccessService.Command.SQLParameterRoot[i]);
                    }
                }
                if (this.tabParameter.TabPages.Count > 0)
                {
                    tabParameter.SelectedTab = this.tabParameter.TabPages[0];
                }
            }
        }

        
        private void tabParameter_SelectedIndexChanged(object sender, EventArgs e)
        {
            _currentSelectedPage = this.tabParameter.SelectedTab;
        }

        private void btnAddParameter_Click(object sender, EventArgs e)
        {
            if (null != _parentForm)
            {
                _parentForm.DisplayMessage(string.Empty, false);
            }

            this.txtParameter.Focus();

            if (string.Empty == this.txtParameter.Text)
            {
                if (null != _parentForm)
                {
                    _parentForm.DisplayMessage("Please enter parameter name!", true);
                }

                return;
            }
            SQLParameterRoot sqlParameterRoot = new SQLParameterRoot();
            sqlParameterRoot.Parameter = new SQLParameterRootParameter();
            sqlParameterRoot.Parameter.Name = this.txtParameter.Text.Trim();

            sqlParameterRoot.Parameter.Type = "INT";
            sqlParameterRoot.Parameter.Size = "4";
            TabPage page = _AddPage(ref sqlParameterRoot);
            if (null != page)
            {
                this.tabParameter.SelectedTab = page;
            }

            int parameterCount = 0;
            _sqlDatabaseAccessService.Command.SQLParameterRoot = new SQLParameterRoot[parameterCount + 1];
            
            if (null != _sqlDatabaseAccessService.Command.SQLParameterRoot)
            {
                parameterCount = _sqlDatabaseAccessService.Command.SQLParameterRoot.Length;
                List<SQLParameterRoot> currentParamterList = new List<SQLParameterRoot>(_sqlDatabaseAccessService.Command.SQLParameterRoot);
                currentParamterList.CopyTo(_sqlDatabaseAccessService.Command.SQLParameterRoot);
            }
            else
            {
                parameterCount = 1;
            }
            _sqlDatabaseAccessService.Command.SQLParameterRoot[parameterCount - 1] = sqlParameterRoot;
        }

        private TabPage _AddPage(ref SQLParameterRoot sqlParameterRoot)
        {
            TabPage page = null;
            if (null != sqlParameterRoot && null != sqlParameterRoot.Parameter)
            {
                if (String.IsNullOrEmpty(sqlParameterRoot.Parameter.Name))
                {
                    if (null != _parentForm)
                    {
                        _parentForm.DisplayMessage("Please enter parameter name to add", true);
                        return null;
                    }
                }

                if (FormSQLAzureConnect.IsPageExisted(sqlParameterRoot.Parameter.Name, this.tabParameter))
                {
                    if (null != _parentForm)
                    {
                        _parentForm.DisplayMessage(string.Format("The name <{0}> of parameter is already existed", sqlParameterRoot.Parameter.Name), true);
                    }
                    return null;
                }

                page = new TabPage(sqlParameterRoot.Parameter.Name);
                ParameterControl parameterControl = new ParameterControl(ref sqlParameterRoot, _parentForm);
                page.Controls.Add(parameterControl);
                parameterControl.Dock = DockStyle.Fill;
                this.tabParameter.TabPages.Add(page);
            }
            return page;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (null != _parentForm)
            {
                _parentForm.DisplayMessage(string.Empty, false);
            }

            this.txtParameter.Focus();

            if (string.Empty == this.txtParameter.Text)
            {
                if (null != _parentForm)
                {
                    _parentForm.DisplayMessage("Please enter parameter name for deleting", true);
                }

                return;
            }

            TabPage page = null;
            foreach (TabPage p in tabParameter.TabPages)
            {
                if (p.Text == txtParameter.Text.Trim())
                {
                    page = p;
                    break;
                }
            }

            if (null != page)
            {
                int parameterCount = _sqlDatabaseAccessService.Command.SQLParameterRoot.Length;
                if (null != _sqlDatabaseAccessService.Command.SQLParameterRoot && parameterCount > 0)
                {
                    List<SQLParameterRoot> paramterList = new List<SQLParameterRoot>();

                    foreach (SQLParameterRoot param in _sqlDatabaseAccessService.Command.SQLParameterRoot)
                    {
                        if (String.Compare(param.Parameter.Name, page.Text, true) != 0)
                        {
                            paramterList.Add(param);
                        }
                    }

                    _sqlDatabaseAccessService.Command.SQLParameterRoot = new SQLParameterRoot[paramterList.Count];
                    if (paramterList.Count > 0)
                    {
                        paramterList.CopyTo(_sqlDatabaseAccessService.Command.SQLParameterRoot);
                    }
                    this.tabParameter.TabPages.Remove(page);
                }
            }
            else if (null != this._parentForm)
            {
                this._parentForm.DisplayMessage(string.Format("Can not find the parameter <{0}>", txtParameter.Text), true);
            }
        }

        private void radioButtonQuery_CheckedChanged(object sender, EventArgs e)
        {
            this.groupParameter.Enabled = false;
        }

        private void radioButtonStoredProcedure_CheckedChanged(object sender, EventArgs e)
        {
            this.groupParameter.Enabled = true;
        }

        private void richTextBoxCommandText_MouseUp(object sender, MouseEventArgs e)
        {
            if (null != eventSelectedTexChanged)
            {
                try
                {
                    eventSelectedTexChanged(this, new SelectedTextArgs(String.IsNullOrEmpty(SelectedText)? null:this));
                }
                catch { }
            }
        }

        void richTextBoxCommandText_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (null != eventBubblePreviewKeyDown)
            {
                eventBubblePreviewKeyDown(this, e);
            }
        }

        private void SQLDataServiceControl_Leave(object sender, EventArgs e)
        {
            this.richTextBoxCommandText.Clear();
            this.richTextBoxCommandText.Text = _sqlDatabaseAccessService.Command.Text;
            richTextBoxCommandText_MouseUp(this, null);
        }

    }
}
