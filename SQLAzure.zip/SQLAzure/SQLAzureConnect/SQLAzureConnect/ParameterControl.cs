﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SQLAzureConnect
{
    using SQLAzureConnect.Schema.SQLParameter;

    public partial class ParameterControl : UserControl
    {
        private FormSQLAzureConnect _parentForm = null;
        public SQLParameterRoot _sqlParameter = null;

        public ParameterControl()
        {
            InitializeComponent();
        }

        public ParameterControl(ref SQLParameterRoot sqlParameter,
                                FormSQLAzureConnect parentForm) 
        {
            InitializeComponent();
            this.bindingSource.DataSource = _sqlParameter = sqlParameter;
            _parentForm = parentForm;
            _UpdateUI();
        }

        public void DoDataExchange()
        {
            _sqlParameter.Parameter.Value = this.txtValue.Text.Trim();
            _sqlParameter.Parameter.Size = this.txtSize.Text;
            _sqlParameter.Parameter.Type = this.comboBoxType.SelectedItem.ToString();
            if (radioButtonIn.Checked)
            {
                _sqlParameter.Parameter.Direction = SQLParameterRootParameterDirection.In;
            }
            else if (radioButtonOut.Checked)
            {
                _sqlParameter.Parameter.Direction = SQLParameterRootParameterDirection.Out;
            }
            else if (radioButtonInOut.Checked)
            {
                _sqlParameter.Parameter.Direction = SQLParameterRootParameterDirection.InOut;
            }
            else if (radioButtonReturn.Checked)
            {
                _sqlParameter.Parameter.Direction = SQLParameterRootParameterDirection.ReturnValue;
            }
        }

        private void _UpdateUI()
        {
            if (null != _sqlParameter)
            {
                this.txtValue.Text = _sqlParameter.Parameter.Value;
                this.txtSize.Text = _sqlParameter.Parameter.Size;
                this.comboBoxType.SelectedIndex = comboBoxType.Items.IndexOf(_sqlParameter.Parameter.Type);
                switch (_sqlParameter.Parameter.Direction)
                {
                    case SQLParameterRootParameterDirection.Out:
                        this.radioButtonOut.Select();
                        break;
                    case SQLParameterRootParameterDirection.InOut:
                        this.radioButtonInOut.Select();
                        break;
                    case SQLParameterRootParameterDirection.ReturnValue:
                        this.radioButtonReturn.Select();
                        break;
                    case SQLParameterRootParameterDirection.In:
                    default:
                        this.radioButtonIn.Select();
                        break;
                }
            }
        }

        private void ParameterControl_Leave(object sender, EventArgs e)
        {
            DoDataExchange();
        }
    }
}
