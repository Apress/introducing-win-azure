﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;
using System.Text.RegularExpressions;

namespace SQLAzureConnect
{
    using SQLAzureConnect.Schema.SQLDatabaseAccess;
    using SQLAzureConnect.Schema.SQLParameter;

    public class SQLDataAcessHelper
    {
        protected SQLDatabaseAccessRoot _sqlDatabaseAccessRoot = null;

        #region Constructors

        public SQLDataAcessHelper(SQLDatabaseAccessRoot sqlDatabaseAccessRoot)
        {
            _sqlDatabaseAccessRoot = sqlDatabaseAccessRoot;
        }

        public SQLDataAcessHelper(SQLDatabaseAccessRoot sqlDatabaseAccessRoot, string connectionString) : this(sqlDatabaseAccessRoot)
        {
            ConnectionString = connectionString;
        }

        #endregion

        #region Properties

        public string ConnectionString { get; set; }
        public string ConnectedDatabase
        {
            get
            {
                string database = string.Empty;
                string[] split = ConnectionString.StartsWith("Server")?
                     Regex.Split(ConnectionString, "Server=")
                    :Regex.Split(ConnectionString, "Data Source=");
                if (null != split && split.Length > 1)
                {
                    string strValue = split[split.Length - 1];
                    int indexEnd = strValue.IndexOf(';');
                    try
                    {
                        database = strValue.Substring(0, indexEnd);
                    }
                    catch { }
                }

                return database;
            }
        }

        #endregion

        #region Public Methods

        public StringBuilder Excute(string subject, ref Object results)
        {
            StringBuilder sb = null;
            if (null != _sqlDatabaseAccessRoot)
            {
                SQLDatabaseAccessRootSqlDataService dataService = this._sqlDatabaseAccessRoot.SqlDataService.FirstOrDefault<SQLDatabaseAccessRootSqlDataService>(x => x.Subject == subject);
                if (null != dataService)
                {
                    if (dataService.Command.Type == SQLDatabaseAccessRootSqlDataServiceCommandType.Query)
                    {
                        sb = _ExcuteQuery(dataService.Command.Text);
                    }
                    else if (dataService.Command.Type == SQLDatabaseAccessRootSqlDataServiceCommandType.Storedprocedure)
                    {
                        sb = _ExecuteStoredProcedure(dataService);
                    }
                }
            }
            else
            {
                throw new ApplicationException(string.Format("---SqlDatabaseService:Query, Subject = <{0}>, SqlDatabaseService is not initialized correctly.", subject));
            }

            return sb;
        }

        public StringBuilder ExcuteSelected(string selectedText)
        {
            return _ExcuteQuery(selectedText);
        }
        
        public bool CreateStoredProcedure(string storedProcedureName,
                                          string storedProcedureBody,
                                          SQLDatabaseAccessRootSqlDataServiceCommand serviceCommand)
        {
            bool success = false;
            StoredProcedure stroredProcedure = null;
            if (null != storedProcedureName
                && null != storedProcedureBody
                && null != serviceCommand
                && string.Empty != storedProcedureName
                && string.Empty != storedProcedureBody)
            {
                try
                {
                    SqlConnection _connection = new SqlConnection(ConnectionString);
                    if (null != _connection)
                    {
                        _connection.Open();

                        Server server = new Server(new ServerConnection(_connection));
                        Database db = server.Databases[ConnectedDatabase];
                        stroredProcedure = new StoredProcedure(db, storedProcedureName);
                        stroredProcedure.TextMode = false;
                        stroredProcedure.AnsiNullsStatus = false;
                        stroredProcedure.QuotedIdentifierStatus = false;

                        stroredProcedure.TextBody = storedProcedureBody;

                        if (null != serviceCommand)
                        {
                            this._PopulateStoredProcedureParameters(ref stroredProcedure,
                                                                    serviceCommand);
                        }
                        stroredProcedure.Create();
                        success = stroredProcedure == null ? false : true;
                    }
                }
                catch (Exception ex)
                {
                    string msg = string.Empty;
                    if (null != ex.InnerException)
                    {
                        msg = ex.InnerException.Message;
                        if (ex.InnerException.InnerException != null)
                        {
                            msg = ex.InnerException.InnerException.Message;
                            if (msg.Equals(string.Format("There is already an object named '{0}' in the database.", storedProcedureName)))
                            {
                                success = true;
                            }
                        }
                    }
                    else
                    {
                        msg = ex.Message;
                    }
                }
            }

            return success;
        }
        
        static public object XmlRetrive(Type type, XmlDocument xmlDoc)
        {
            object o = null;

            if (null != xmlDoc && null != xmlDoc.DocumentElement)
            {
                XmlSerializer serializer = new XmlSerializer(type);
                StringReader reader = new StringReader(xmlDoc.OuterXml);

                try
                {
                    o = serializer.Deserialize(reader);
                }
                catch (Exception e)
                {
                    System.Diagnostics.Trace.WriteLine(e.Message);
                    System.Diagnostics.Trace.WriteLine(e.StackTrace);
                    throw e;
                }
            }

            return o;
        }

        static public StringBuilder XmlPersist(object o, Type type)
        {
            XmlSerializer serializer = new XmlSerializer(type);
            StringBuilder sb = new StringBuilder();
            StringWriter writer = new StringWriter(sb);

            try
            {
                serializer.Serialize(writer, o);
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(e.Message);
                System.Diagnostics.Trace.WriteLine(e.StackTrace);
                throw e;
            }

            return writer.GetStringBuilder();
        }
        #endregion

        #region Private Methods

        protected StringBuilder _ExcuteQuery(string commandText)
        {
            int rowaffected = 0;
            DataTable datatable = new DataTable();
            StringBuilder sb = new StringBuilder();

            SQLDataAccessComponent dac = null;
            SqlCommand Command = null;

            try
            {
                dac = new SQLDataAccessComponent(this.ConnectionString);
                Command = new SqlCommand(commandText, new SqlConnection());
                dac.BeginTrans();
                rowaffected = dac.ExecuteDataTable(Command, ref datatable);
                dac.CommitTrans();
                if (datatable.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in datatable.Rows)
                    {
                        StringBuilder rowBuilder = new StringBuilder();
                        foreach (object obj in dataRow.ItemArray)
                        {
                            if (!(obj is DBNull || (obj is System.Byte[])))
                            {
                                rowBuilder.Append(string.Format("{0}  ", obj.ToString()));
                            }
                        }
                        sb.Append(string.Format("{0}{1}", rowBuilder.ToString(), Environment.NewLine));
                    }
                }
                sb.Append(string.Format("------ SQL excute success, row affected : {0} ------{1}", rowaffected, Environment.NewLine));
                sb.Append(Environment.NewLine);
            }
            catch (Exception ex)
            {
                throw new ApplicationException(string.Format("------ SQL excute failed, error message: {0}", ex.Message, Environment.NewLine));
            }
            finally
            {
                if (null != Command)
                {
                    Command.Dispose();
                }
                if (null != dac)
                {
                    dac.Dispose();
                }
            }

            return sb;
        }

        protected StringBuilder _ExecuteStoredProcedure(SQLDatabaseAccessRootSqlDataService dataService)
        {
            StringBuilder sb = new StringBuilder();
            int rowaffected = 0;
            SQLDataAccessComponent dac = null;
            SqlCommand Command = null;

            try
            {
                SQLDatabaseAccessRootSqlDataServiceCommand serviceCommand = dataService.Command;
                string storedProcedure = serviceCommand.Text;
                dac = new SQLDataAccessComponent(this.ConnectionString);
                Command = new SqlCommand(storedProcedure, new SqlConnection());
                Command.CommandType = CommandType.StoredProcedure;

                bool output = this._PopulateParameters(serviceCommand, ref Command);
                dac.BeginTrans();
                rowaffected = (int)dac.ExecuteNonQuery(Command);
                dac.CommitTrans();
                if (output)
                {
                    foreach (SqlParameter parameter in Command.Parameters)
                    {
                        if (parameter.Direction == ParameterDirection.Output)
                        {
                            sb.Append(parameter.Value.ToString());
                            sb.Append(Environment.NewLine);
                        }
                    }
                }
                sb.Append(string.Format("------ SQL excute success, row affected : {0} ------{1}", rowaffected, Environment.NewLine));
                sb.Append(Environment.NewLine);
            }
            finally
            {
                if (null != Command)
                {
                    Command.Dispose();
                }
                if (null != dac)
                {
                    dac.Dispose();
                }
            }

            return sb;
        }

        private bool _PopulateParameters(SQLDatabaseAccessRootSqlDataServiceCommand serviceCommand,
                                         ref SqlCommand Command)
        {
            bool output = false;
            string direction = string.Empty;

            try
            {
                Command.Parameters.Clear();
                foreach (SQLParameterRoot parameterRoot in serviceCommand.SQLParameterRoot)
                {
                    direction = parameterRoot.Parameter.Direction.ToString().Trim().ToUpper();
                    output |= direction == "OUT" || direction == "INOUT" ? true : false;
                    if (parameterRoot.Parameter.Type.ToUpper().StartsWith("NCHAR"))
                    {
                        int length = 0;
                        length = Convert.ToInt32(parameterRoot.Parameter.Size);
                        Command.Parameters.Add(string.Format("@{0}", parameterRoot.Parameter.Name),
                                                SqlDbType.NChar,
                                                length).Value = parameterRoot.Parameter.Value;
                    }
                    else
                        if (parameterRoot.Parameter.Type.ToUpper().StartsWith("VARCHAR"))
                        {
                            int length = Convert.ToInt32(parameterRoot.Parameter.Size);
                            Command.Parameters.Add(string.Format("@{0}", parameterRoot.Parameter.Name),
                                                    SqlDbType.VarChar,
                                                    length).Value = parameterRoot.Parameter.Value;
                        }
                        else
                            if (parameterRoot.Parameter.Type.ToUpper().StartsWith("NVARCHAR"))
                            {
                                int length = Convert.ToInt32(parameterRoot.Parameter.Size);
                                Command.Parameters.Add(string.Format("@{0}", parameterRoot.Parameter.Name),
                                                        SqlDbType.NVarChar,
                                                        length).Value = parameterRoot.Parameter.Value;
                            }
                            else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("NVARCHAR"))
                            {
                                Command.Parameters.AddWithValue(string.Format("@{0}", parameterRoot.Parameter.Name),
                                                                parameterRoot.Parameter.Value);
                            }
                            else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("INT"))
                            {
                                Command.Parameters.Add(string.Format("@{0}", parameterRoot.Parameter.Name),
                                                        SqlDbType.Int,
                                                        4).Value = Convert.ToInt32(parameterRoot.Parameter.Value);
                            }
                            else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("UNIQUE"))
                            {
                                Command.Parameters.Add(string.Format("@{0}", parameterRoot.Parameter.Name),
                                                        SqlDbType.UniqueIdentifier,
                                                        32).Value = new Guid(parameterRoot.Parameter.Value);
                            }
                            else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("XML"))
                            {
                                Command.Parameters.Add(string.Format("@{0}", parameterRoot.Parameter.Name),
                                                        SqlDbType.Xml,
                                                        0).Value = parameterRoot.Parameter.Value;
                            }
                            else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("TIMSTAMP"))
                            {
                                Command.Parameters.Add(string.Format("@{0}", parameterRoot.Parameter.Name),
                                                        SqlDbType.Timestamp,
                                                        0).Value = parameterRoot.Parameter.Value;
                            }
                            else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("DATETIME"))
                            {
                                DateTime dt = DateTime.Now;
                                if (parameterRoot.Parameter.Value != string.Empty)
                                {
                                    dt = DateTime.Parse(parameterRoot.Parameter.Value);
                                }
                                Command.Parameters.Add(string.Format("@{0}", parameterRoot.Parameter.Name),
                                                        SqlDbType.DateTime,
                                                        0).Value = dt;
                            }
                }
            }
            finally
            {
                if (null != Command)
                {
                    Command.Dispose();
                }
            }

            return output;
        }
        private bool _PopulateStoredProcedureParameters(ref StoredProcedure storedProcedure,
                                                        SQLDatabaseAccessRootSqlDataServiceCommand serviceCommand)
        {
            bool success = false;
            try
            {
                foreach (SQLParameterRoot parameterRoot in serviceCommand.SQLParameterRoot)
                {
                    StoredProcedureParameter param = null;
                    if (parameterRoot.Parameter.Type.ToUpper().StartsWith("NCHAR"))
                    {
                        param = new StoredProcedureParameter(storedProcedure,
                                                             string.Format("@{0}", parameterRoot.Parameter.Name),
                                                             DataType.NVarCharMax);
                    }
                    else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("VARCHAR"))
                    {
                        param = new StoredProcedureParameter(storedProcedure,
                                                             string.Format("@{0}", parameterRoot.Parameter.Name),
                                                             DataType.VarCharMax);
                    }
                    else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("NVARCHAR"))
                    {
                        param = new StoredProcedureParameter(storedProcedure,
                                                             string.Format("@{0}", parameterRoot.Parameter.Name),
                                                             DataType.NVarCharMax);
                    }
                    else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("INT"))
                    {
                        param = new StoredProcedureParameter(storedProcedure,
                                                             string.Format("@{0}", parameterRoot.Parameter.Name),
                                                             DataType.Int);
                    }
                    else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("UNIQUE"))
                    {
                        param = new StoredProcedureParameter(storedProcedure,
                                                                 string.Format("@{0}", parameterRoot.Parameter.Name),
                                                                 DataType.UniqueIdentifier);
                    }
                    else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("XML"))
                    {
                        param = new StoredProcedureParameter(storedProcedure,
                                                                  string.Format("@{0}", parameterRoot.Parameter.Name),
                                                                  DataType.NVarCharMax);
                    }
                    else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("TIMSTAMP"))
                    {
                        param = new StoredProcedureParameter(storedProcedure,
                                                                 string.Format("@{0}", parameterRoot.Parameter.Name),
                                                                 DataType.Timestamp);
                    }
                    else if (parameterRoot.Parameter.Type.ToUpper().StartsWith("DATETIME"))
                    {
                        DateTime dt = DateTime.Now;
                        if (parameterRoot.Parameter.Value != string.Empty)
                        {
                            dt = DateTime.Parse(parameterRoot.Parameter.Value);
                        }
                        param = new StoredProcedureParameter(storedProcedure,
                                                                    string.Format("@{0}", parameterRoot.Parameter.Name),
                                                                    DataType.DateTime);
                    }

                    if (null != parameterRoot.Parameter)
                    {
                        storedProcedure.Parameters.Add(param);
                    }
                }

                success = true;
            }
            catch (Exception ex)
            {
                string msg = string.Empty;
                if (null != ex.InnerException)
                {
                    msg = ex.InnerException.Message;
                }
                else
                {
                    msg = ex.Message;
                }
            }

            return success;
        }
        #endregion
    }
}
