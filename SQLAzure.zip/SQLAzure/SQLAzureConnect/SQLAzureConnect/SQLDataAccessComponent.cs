﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Collections;
using System.ComponentModel;
using System.Text;

namespace SQLAzureConnect
{
    public class SQLDataAccessComponent : IDisposable
    {
        #region Private Fields

        static protected SqlConnection _connection = null;
        private const Int32 COMMAND_TIMEOUT = 60;
        private SqlTransaction _transaction;
        protected string _SQL_CONNECTION_STRING = string.Empty;

        #endregion

        #region Constructors/Destructors

        /// <summary>
        /// Default Contstructor
        /// </summary>
        public SQLDataAccessComponent()
        {
            _transaction = null;
            _connection = new SqlConnection(_SQL_CONNECTION_STRING);
        }

        public SQLDataAccessComponent(String connectionString)
        {
            _transaction = null;
            _connection = new SqlConnection(connectionString);
            _SQL_CONNECTION_STRING = connectionString;

        }

        public void Dispose()
        {
            CloseConn();
            _transaction = null;
            _connection = null;
        }


        #endregion

        #region Public Properties

        public bool IsInTransaction
        {
            get
            {
                return _transaction != null;
            }
        }

        #endregion

        #region Private Methods

        private void OpenConn()
        {
            Dispose();

            if (_connection == null)
            {
                _connection = new SqlConnection(_SQL_CONNECTION_STRING);
            }

            _connection.Open();

            TimeSpan timeOutSetting = new TimeSpan(0, 0, 2);//2 sec
            DateTime connectingStart = DateTime.Now;
            int timeout = 0;
            while (_connection.State == ConnectionState.Connecting && timeout <= 1)
            {
                DateTime timeNow = DateTime.Now;
                TimeSpan timespanElapsed = new TimeSpan(timeNow.Hour - connectingStart.Hour,
                                                        timeNow.Minute - connectingStart.Minute,
                                                        timeNow.Second - connectingStart.Second);
                timeout = TimeSpan.Compare(timespanElapsed, timeOutSetting);
            }
        }

        private void CloseConn()
        {
            lock (_connection)
            {
                while (null != _connection && _connection.State != ConnectionState.Broken
                      && _connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
            }
        }

        #endregion

        #region Public Methods

        public void BeginTrans()
        {
            if (_connection.State != ConnectionState.Closed && _connection.State != ConnectionState.Broken)
            {
                CloseConn();
            }
            OpenConn();
            _transaction = _connection.BeginTransaction();
        }

        public void CommitTrans()
        {
            if (null != _transaction)
            {
                _transaction.Commit();
            }
            CloseConn();
            _transaction = null;
        }

        public void RollBackTrans()
        {
            if (null != _transaction)
            {
                _transaction.Rollback();
            }
            CloseConn();
            _transaction = null;
        }

        public SqlDataReader GetDataReader(SqlCommand command)
        {
            try
            {
                OpenConn();
                command.Connection = _connection;
                command.Transaction = _transaction;
                command.CommandTimeout = COMMAND_TIMEOUT;

                return command.ExecuteReader(CommandBehavior.CloseConnection);

            }
            finally
            {
                if (_transaction != null)
                {
                    RollBackTrans();
                }
                command.Dispose();
            }
        }

        public Object ExecuteNonQuery(SqlCommand command)
        {

            OpenConn();
            command.Connection = _connection;
            command.Transaction = _transaction;
            command.CommandTimeout = COMMAND_TIMEOUT;

            try
            {
                int rowsAffected = command.ExecuteNonQuery();

                return (command.Parameters.Contains("@ReturnValue")) ? Convert.ToInt32(command.Parameters["@ReturnValue"].Value) : rowsAffected;

            }
            finally
            {
                if (_transaction != null)
                {
                    RollBackTrans();
                }
                command.Dispose();
            }
        }

        public string ExecuteScalar(SqlCommand command)
        {
            try
            {
                OpenConn();
                command.Connection = _connection;
                command.Transaction = _transaction;
                command.CommandTimeout = COMMAND_TIMEOUT;
                return command.ExecuteScalar().ToString();
            }
            finally
            {
                if (_transaction != null)
                {
                    RollBackTrans();
                }
                command.Dispose();
            }
        }

        public DataSet ExecuteDataSet(SqlCommand command)
        {
            DataSet oDataSet = new DataSet();
            try
            {
                SqlDataAdapter da;
                oDataSet.Locale = CultureInfo.InvariantCulture;

                OpenConn();
                command.Connection = _connection;
                command.Transaction = _transaction;
                command.CommandTimeout = COMMAND_TIMEOUT;

                da = new SqlDataAdapter(command);

                da.Fill(oDataSet);
            }
            finally
            {
                command.Dispose();
            }
            return oDataSet;
        }

        public int ExecuteDataTable(SqlCommand command, ref DataTable datatable)
        {
            int rowEffected = 0;
            try
            {
                SqlDataAdapter da;
                datatable.Locale = CultureInfo.InvariantCulture;

                OpenConn();
                command.Connection = _connection;
                command.Transaction = _transaction;
                command.CommandTimeout = COMMAND_TIMEOUT;

                da = new SqlDataAdapter(command);
                rowEffected = da.Fill(datatable);
            }
            finally
            {
                command.Dispose();
            }
            return rowEffected;
        }

        #endregion


    }
}
