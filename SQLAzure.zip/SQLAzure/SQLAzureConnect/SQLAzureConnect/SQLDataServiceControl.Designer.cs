﻿namespace SQLAzureConnect
{
    partial class SQLDataServiceControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SQLDataServiceControl));
            this.label2 = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.richTextBoxCommandText = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupParameter = new System.Windows.Forms.GroupBox();
            this.lblNewParameter = new System.Windows.Forms.Label();
            this.txtParameter = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAddParameter = new System.Windows.Forms.Button();
            this.tabParameter = new System.Windows.Forms.TabControl();
            this.radioButtonQuery = new System.Windows.Forms.RadioButton();
            this.radioButtonStoredProcedure = new System.Windows.Forms.RadioButton();
            this.bindingSourceService = new System.Windows.Forms.BindingSource(this.components);
            this.groupParameter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceService)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(5, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Discription : ";
            // 
            // txtDescription
            // 
            this.txtDescription.BackColor = System.Drawing.Color.DimGray;
            this.txtDescription.ForeColor = System.Drawing.Color.Silver;
            this.txtDescription.Location = new System.Drawing.Point(69, 31);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(362, 20);
            this.txtDescription.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(5, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Subject : ";
            // 
            // txtSubject
            // 
            this.txtSubject.BackColor = System.Drawing.Color.Black;
            this.txtSubject.ForeColor = System.Drawing.Color.Gold;
            this.txtSubject.Location = new System.Drawing.Point(69, 5);
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(143, 20);
            this.txtSubject.TabIndex = 4;
            this.txtSubject.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // richTextBoxCommandText
            // 
            this.richTextBoxCommandText.AutoWordSelection = true;
            this.richTextBoxCommandText.BackColor = System.Drawing.Color.Black;
            this.richTextBoxCommandText.ForeColor = System.Drawing.Color.Gold;
            this.richTextBoxCommandText.Location = new System.Drawing.Point(7, 55);
            this.richTextBoxCommandText.Name = "richTextBoxCommandText";
            this.richTextBoxCommandText.Size = new System.Drawing.Size(424, 54);
            this.richTextBoxCommandText.TabIndex = 8;
            this.richTextBoxCommandText.Text = "";
            this.richTextBoxCommandText.MouseUp += new System.Windows.Forms.MouseEventHandler(this.richTextBoxCommandText_MouseUp);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(225, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Type : ";
            // 
            // groupParameter
            // 
            this.groupParameter.Controls.Add(this.lblNewParameter);
            this.groupParameter.Controls.Add(this.txtParameter);
            this.groupParameter.Controls.Add(this.btnDelete);
            this.groupParameter.Controls.Add(this.btnAddParameter);
            this.groupParameter.Controls.Add(this.tabParameter);
            this.groupParameter.ForeColor = System.Drawing.Color.Navy;
            this.groupParameter.Location = new System.Drawing.Point(3, 108);
            this.groupParameter.Name = "groupParameter";
            this.groupParameter.Size = new System.Drawing.Size(430, 159);
            this.groupParameter.TabIndex = 1;
            this.groupParameter.TabStop = false;
            this.groupParameter.Text = "Parameters";
            // 
            // lblNewParameter
            // 
            this.lblNewParameter.AutoSize = true;
            this.lblNewParameter.ForeColor = System.Drawing.Color.Navy;
            this.lblNewParameter.Location = new System.Drawing.Point(2, 130);
            this.lblNewParameter.Name = "lblNewParameter";
            this.lblNewParameter.Size = new System.Drawing.Size(92, 13);
            this.lblNewParameter.TabIndex = 7;
            this.lblNewParameter.Text = "Parameter Name: ";
            // 
            // txtParameter
            // 
            this.txtParameter.BackColor = System.Drawing.Color.Black;
            this.txtParameter.ForeColor = System.Drawing.Color.Gold;
            this.txtParameter.Location = new System.Drawing.Point(96, 127);
            this.txtParameter.Name = "txtParameter";
            this.txtParameter.Size = new System.Drawing.Size(166, 20);
            this.txtParameter.TabIndex = 6;
            this.txtParameter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(349, 121);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 34);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAddParameter
            // 
            this.btnAddParameter.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnAddParameter.Image = ((System.Drawing.Image)(resources.GetObject("btnAddParameter.Image")));
            this.btnAddParameter.Location = new System.Drawing.Point(268, 121);
            this.btnAddParameter.Name = "btnAddParameter";
            this.btnAddParameter.Size = new System.Drawing.Size(75, 34);
            this.btnAddParameter.TabIndex = 1;
            this.btnAddParameter.Text = "&Add Param";
            this.btnAddParameter.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAddParameter.UseVisualStyleBackColor = false;
            this.btnAddParameter.Click += new System.EventHandler(this.btnAddParameter_Click);
            // 
            // tabParameter
            // 
            this.tabParameter.Location = new System.Drawing.Point(5, 18);
            this.tabParameter.Name = "tabParameter";
            this.tabParameter.SelectedIndex = 0;
            this.tabParameter.Size = new System.Drawing.Size(423, 96);
            this.tabParameter.TabIndex = 0;
            this.tabParameter.SelectedIndexChanged += new System.EventHandler(this.tabParameter_SelectedIndexChanged);
            // 
            // radioButtonQuery
            // 
            this.radioButtonQuery.AutoSize = true;
            this.radioButtonQuery.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonQuery.ForeColor = System.Drawing.Color.Navy;
            this.radioButtonQuery.Location = new System.Drawing.Point(265, 7);
            this.radioButtonQuery.Name = "radioButtonQuery";
            this.radioButtonQuery.Size = new System.Drawing.Size(53, 17);
            this.radioButtonQuery.TabIndex = 10;
            this.radioButtonQuery.TabStop = true;
            this.radioButtonQuery.Text = "Query";
            this.radioButtonQuery.UseVisualStyleBackColor = false;
            this.radioButtonQuery.CheckedChanged += new System.EventHandler(this.radioButtonQuery_CheckedChanged);
            // 
            // radioButtonStoredProcedure
            // 
            this.radioButtonStoredProcedure.AutoSize = true;
            this.radioButtonStoredProcedure.ForeColor = System.Drawing.Color.Navy;
            this.radioButtonStoredProcedure.Location = new System.Drawing.Point(327, 7);
            this.radioButtonStoredProcedure.Name = "radioButtonStoredProcedure";
            this.radioButtonStoredProcedure.Size = new System.Drawing.Size(104, 17);
            this.radioButtonStoredProcedure.TabIndex = 11;
            this.radioButtonStoredProcedure.TabStop = true;
            this.radioButtonStoredProcedure.Text = "Storedprocedure";
            this.radioButtonStoredProcedure.UseVisualStyleBackColor = true;
            this.radioButtonStoredProcedure.CheckedChanged += new System.EventHandler(this.radioButtonStoredProcedure_CheckedChanged);
            // 
            // bindingSourceService
            // 
            this.bindingSourceService.DataSource = typeof(SQLAzureConnect.Schema.SQLDatabaseAccess.SQLDatabaseAccessRootSqlDataService);
            // 
            // SQLDataServiceControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this.radioButtonStoredProcedure);
            this.Controls.Add(this.radioButtonQuery);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.richTextBoxCommandText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSubject);
            this.Controls.Add(this.groupParameter);
            this.Name = "SQLDataServiceControl";
            this.Size = new System.Drawing.Size(436, 265);
            this.Leave += new System.EventHandler(this.SQLDataServiceControl_Leave);
            this.groupParameter.ResumeLayout(false);
            this.groupParameter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceService)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.RichTextBox richTextBoxCommandText;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupParameter;
        private System.Windows.Forms.TabControl tabParameter;
        private System.Windows.Forms.RadioButton radioButtonQuery;
        private System.Windows.Forms.RadioButton radioButtonStoredProcedure;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAddParameter;
        private System.Windows.Forms.Label lblNewParameter;
        private System.Windows.Forms.TextBox txtParameter;
        private System.Windows.Forms.BindingSource bindingSourceService;
    }
}
