﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace SQLAzureConnect
{
    using SQLAzureConnect.Login;
    //using SQLAzureConnect.QueryData;
    using SQLAzureConnect.Schema.SQLDatabaseAccess;

    public partial class FormSQLAzureConnect : Form
    {
        //private SQLAzureConnect _connectLogin = null;
        //private SQLAzureQueryCollection _queryData = null;
        private SqlConnection _SQLConnection = null;
        private string _connectionConfigXmlPath = Environment.CurrentDirectory + @"\Login.xml";
        private string _queryDataXmlPath = Environment.CurrentDirectory + @"\SQLAzureQueryData.xml";
        const string LOGIN_XMLFILE_FILTER = "SQL Azure Connection Config Files|*.xml|All Files|*.*";
        const string QUERY_XMLFILE_FILTER = "SQL Azure Query Data Files|*.xml|All Files|*.*";

        private string _sqlAccessDataXmlPath = Environment.CurrentDirectory + @"\SQLAccessData.xml";
        private SQLDatabaseAccessRoot _sqlDataAccessRoot = null;

        public FormSQLAzureConnect()
        {
            InitializeComponent();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(_sqlAccessDataXmlPath);
            _sqlDataAccessRoot = (SQLDatabaseAccessRoot)XmlRetrive(typeof(SQLDatabaseAccessRoot), xmlDoc);

            _LoadSQLXml();
        }

        private void _Display(string message, bool error)
        {
            this.richTextBoxMessage.Clear();
            richTextBoxMessage.AppendText(message);
            richTextBoxMessage.ForeColor = error ? Color.Red : Color.Yellow;
        }

        private void _ConnectToSQLAzure()
        {
            if (null != _SQLConnection && _SQLConnection.State != ConnectionState.Closed)
            {
                _SQLConnection.Close();
            }

            _SQLConnection = new SqlConnection();

            try
            {
                //_SQLConnection.ConnectionString = string.Format("Server=tcp:{0}.ctp.database.windows.net;Database={1};User ID={2};Password={3};Trusted_Connection=False;",
                //                                                this.txtServer.Text.Trim(),
                //                                                this.txtDatabase.Text.Trim(),
                //                                                this.txtUserID.Text.Trim(),
                //                                                this.txtPassword.Text.Trim());

                _SQLConnection.ConnectionString = "Data Source=SSPDX02\\SQLEXPRESS;Initial Catalog=SQLAzure;Integrated Security=True"; 
                _SQLConnection.Open();
                _Display("Connect to SQL Azure server", false);
            }
            catch (Exception ex)
            {
                _Display(ex.Message, true);
            }
        }
        
        private void _LoadSQLXml()
        {
            this.txtServer.Text = _sqlDataAccessRoot.ServerConnection.ServerName;
            this.txtDatabase.Text = _sqlDataAccessRoot.ServerConnection.Database;
            this.txtUserID.Text = _sqlDataAccessRoot.ServerConnection.Login;
            this.txtPassword.Text = _sqlDataAccessRoot.ServerConnection.Password;

            _UpdateQueryDataUI(0);
        }

        private void _UpdateQueryDataUI(int selectedIndex)
        {
            this.richTextBoxQuery.Clear();
            this.comboBoxQueryData.Items.Clear();

            foreach (SQLDatabaseAccessRootSqlDataService service in _sqlDataAccessRoot.SqlDataService)
            {
                this.comboBoxQueryData.Items.Add(service.Subject);
            }
            this.comboBoxQueryData.SelectedIndex = selectedIndex;
        }

        public object XmlRetrive(Type type, XmlDocument xmlDoc)
        {
            object o = null;

            if (null != xmlDoc && null != xmlDoc.DocumentElement)
            {
                XmlSerializer serializer = new XmlSerializer(type);
                StringReader reader = new StringReader(xmlDoc.OuterXml);

                try
                {
                    o = serializer.Deserialize(reader);
                }
                catch (Exception e)
                {
                    System.Diagnostics.Trace.WriteLine(e.Message);
                    System.Diagnostics.Trace.WriteLine(e.StackTrace);
                    throw e;
                }
            }

            return o;
        }

        public StringBuilder XmlPersist(object o, Type type)
        {
            XmlSerializer serializer = new XmlSerializer(type);
            StringBuilder sb = new StringBuilder();
            StringWriter writer = new StringWriter(sb);

            try
            {
                serializer.Serialize(writer, o);
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(e.Message);
                System.Diagnostics.Trace.WriteLine(e.StackTrace);
                throw e;
            }

            return writer.GetStringBuilder();
        }

        private void btnOpenConnectionConfig_Click(object sender, EventArgs e)
        {
            this._openFileDialog.Filter = LOGIN_XMLFILE_FILTER;
            string xmlFilePath = _connectionConfigXmlPath;
            _openFileDialog.FileName = xmlFilePath;
            if (_openFileDialog.ShowDialog() == DialogResult.OK)
            {
                xmlFilePath = _openFileDialog.FileName;
                //_LoadSQLAzureConnectionXml(xmlFilePath);
            }
            _connectionConfigXmlPath = xmlFilePath;
        }

        private void btnSaveConnectionCinfig_Click(object sender, EventArgs e)
        {
            //this._saveFileDialog.Filter = LOGIN_XMLFILE_FILTER;
            //string xmlFilePath = _connectionConfigXmlPath;
            //_openFileDialog.FileName = xmlFilePath;
            //if (_saveFileDialog.ShowDialog() == DialogResult.OK)
            //{
            //    xmlFilePath = _saveFileDialog.FileName;
            //    _connectLogin.Item.Server.Name =  this.txtServer.Text.Trim();
            //    _connectLogin.Item.Database.Nme = this.txtDatabase.Text.Trim();
            //    _connectLogin.Item.Login.Name = this.txtUserID.Text.Trim();
            //    _connectLogin.Item.Login.Password = this.txtPassword.Text.Trim();

            //    try
            //    {
            //        StringBuilder sb = XmlPersist(_connectLogin, typeof(SQLAzureConnect));
            //        XmlDocument xmlDoc = new XmlDocument();
            //        xmlDoc.LoadXml(sb.ToString());
            //        xmlDoc.Save(xmlFilePath);
            //    }
            //    catch (Exception ex)
            //    {
            //        _Display(ex.Message, true);
            //    }
            //}
            //_connectionConfigXmlPath = xmlFilePath;
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            this._openFileDialog.Filter = QUERY_XMLFILE_FILTER;
            string xmlFilePath = _queryDataXmlPath;
            _openFileDialog.FileName = xmlFilePath;
            if (_openFileDialog.ShowDialog() == DialogResult.OK)
            {
                xmlFilePath = _openFileDialog.FileName;
                //_LoadSQLAzureQueryDataXml(xmlFilePath);
            }
            _queryDataXmlPath = xmlFilePath;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //this._saveFileDialog.Filter = QUERY_XMLFILE_FILTER;
            //string xmlFilePath = _queryDataXmlPath;
            //_saveFileDialog.FileName = xmlFilePath;
            //if (_saveFileDialog.ShowDialog() == DialogResult.OK)
            //{
            //    xmlFilePath = _saveFileDialog.FileName;
            //    try
            //    {
            //        StringBuilder sb = XmlPersist(_connectLogin, typeof(SQLAzureConnect));
            //        XmlDocument xmlDoc = new XmlDocument();
            //        xmlDoc.LoadXml(sb.ToString());
            //        xmlDoc.Save(xmlFilePath);
            //    }
            //    catch (Exception ex)
            //    {
            //        _Display(ex.Message, true);
            //    }
            //}
            //_queryDataXmlPath = xmlFilePath;
        }

        private void btnTestConnection_Click(object sender, EventArgs e)
        {
            _ConnectToSQLAzure();
        }

        private void comboBoxQueryData_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.richTextBoxQuery.Clear();
            //SQLAzureQueryCollectionSQLAzureQuery query = _queryData.SQLAzureQuery.FirstOrDefault<SQLAzureQueryCollectionSQLAzureQuery>(x => x.Key == this.comboBoxQueryData.SelectedItem.ToString()) as SQLAzureQueryCollectionSQLAzureQuery;
            //this.richTextBoxQuery.AppendText(query.Value);
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            if (null == _SQLConnection)
            {
                this._ConnectToSQLAzure();
            }
            string commandText = this.richTextBoxQuery.Text.Trim();
            commandText = "select count(*) from UserTable";// "select * from UserTable where FirstName like 'Henry%'";
            SqlCommand cmd = new SqlCommand(commandText, _SQLConnection);

            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.SelectCommand.CommandType = CommandType.Text;// StoredProcedure;

                DataTable queryResultDataTable = new DataTable();
                int rowEffected = adapter.Fill(queryResultDataTable);
                StringBuilder sb = new StringBuilder();
                sb.Append(string.Format("------ SQL excute success, row effected : {0} ------{1}", rowEffected, Environment.NewLine));
                sb.Append(Environment.NewLine);
                if (queryResultDataTable.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in queryResultDataTable.Rows)
                    {
                        StringBuilder rowBuilder = new StringBuilder();
                        foreach (object obj in dataRow.ItemArray)
                        {
                            if (!(obj is DBNull||(obj is System.Byte[])))
                            {
                                rowBuilder.Append(string.Format("{0}  ", obj.ToString()));
                            }
                        }
                       sb.Append(string.Format("{0}{1}",rowBuilder.ToString(), Environment.NewLine));
                    }
                }
                _Display(sb.ToString(), false);
            }
            catch (Exception ex)
            {
                _Display(ex.Message, true);
            }

        }
    }
}
