﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace AzureForDotNetDeveloperWCFserviceLibrary
{
    [ServiceContract]
    public interface IUserRegisterService
    {
        [OperationContract]
        void AddUser(User user);

        [OperationContract]
        List<User> GetUserList();
    }

    [DataContract]
    public class User
    {
        [DataMember]
        public string FirstName;

        [DataMember]
        public string LastName;

        [DataMember]
        public DateTime TimeRegistered;

        [DataMember]
        public string Password;
    }
}
