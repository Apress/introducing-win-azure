﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace AzureForDotNetDeveloperWCFserviceLibrary
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class UserRegisterService : IUserRegisterService
    {
        List<User> userList = new List<User>();

        #region IUserRegisterService Members

        public void AddUser(User user)
        {
            userList.Add(user);
        }

        public List<User> GetUserList()
        {
            return userList;
        }

        #endregion
    }
}
