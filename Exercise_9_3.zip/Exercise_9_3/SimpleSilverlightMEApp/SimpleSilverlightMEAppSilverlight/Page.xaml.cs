﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.IO;
using System.Text;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.LiveFX.Client;
using System.ComponentModel;

namespace SimpleSilverlightMEAppSilverlight
{
    public partial class Page : UserControl
    {
        private MeshApplicationService meshApp;

        public Page()
        {
            InitializeComponent();

            meshApp = Application.Current.GetMeshApplicationService();
            // once mesh contents are loaded we get callback
            meshApp.LoadCompleted += new EventHandler(meshAppLoaded);
            meshApp.LoadAsync(null);
        }

        // Called when application loads
        void meshAppLoaded(object sender, EventArgs e)
        {
            _textBox.Text = _textBox.Text + "Mesh callback loaded";
            MeshApplicationService meshApp = Application.Current.GetMeshApplicationService();
            _Render(meshApp);
        }

        void _Render(MeshApplicationService meshApp)
        {
            LiveOperatingEnvironment endpoint = meshApp.LiveOperatingEnvironment;
            StringWriter msg = new StringWriter();
            Mesh mesh = endpoint.Mesh;

            msg.WriteLine(Environment.NewLine);
            msg.WriteLine("{0}({1})", mesh.ProvisionedUser.Name, mesh.ProvisionedUser.Email);

            msg.WriteLine("MeshObjects (granted access):");
            foreach (MeshObject mo in mesh.MeshObjects.Entries)
            {
                msg.WriteLine(mo.Resource.Title);
            }

            msg.WriteLine("Devices:");
            foreach (MeshDevice md in mesh.Devices.Entries)
            {
                msg.WriteLine(md.Resource.Title);
            }

            msg.WriteLine("Application Instance Members:");
            foreach (Member member in meshApp.Members.Entries)
            {
                msg.WriteLine(member.Resource.Title);
            }

            _textBox.Text = msg.GetStringBuilder().ToString();

            //LogoFDOT.Source =  new BitmapImage( new Uri@"http://www.dot.state.fl.us/images/banner.jpg");
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
