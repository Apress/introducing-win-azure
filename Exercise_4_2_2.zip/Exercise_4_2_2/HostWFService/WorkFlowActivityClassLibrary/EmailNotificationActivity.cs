﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;
using System.Workflow.Activities;
using System.Net.Mail;
using System.Diagnostics;

namespace ActivityClassLibrary
{
    public class EmailNotificationActivity : Activity
    {
        public string To { get; set; }
        public string From { get; set; }
        public string Subject { get; set; }
        public string MessageBody { get; set; }

        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Host = "smtp.1and1.com";
            smtpClient.EnableSsl = false;
            smtpClient.UseDefaultCredentials = true;
            MailMessage message = new MailMessage(From,
                                                  To,
                                                  Subject,
                                                  MessageBody);
            try
            {
                Trace.WriteLine(string.Format("---{0}:Execute, send notification to :{1}", this.ToString(), To));
                smtpClient.Send(message);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(string.Format("---{0}:Execute, exception caught:{1}", this.ToString(), ex.Message));
            }

            return (ActivityExecutionStatus)ActivityExecutionResult.Succeeded;
        }
    }
}
